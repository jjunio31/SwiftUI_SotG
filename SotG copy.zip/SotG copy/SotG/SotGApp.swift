//
//  SotGApp.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//

import SwiftUI

@main
struct SotGApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, SotgProvider.shared.container.viewContext)
        }
    }
}
