//
//  VehiclesPickerView.swift
//  SotG
//
//  Created by Administrator on 22/1/2023.
//

import SwiftUI
import CoreData

struct VehiclesPickerView: View {
    @Binding var vehicle:String
    
    @FetchRequest(fetchRequest: Vehicles.allFetchRequest())
    var vehicleList: FetchedResults<Vehicles>
    
    init(_ binding:Binding<String?>){
        
        print("VehiclesPickerView init \(binding.wrappedValue ?? "nil")")
        _vehicle = Binding(binding,"")
        
       
    }
    var body: some View {
        HStack {
            Text("Vehicle: ")
            let _ = print("vehicle: \(vehicle)")
            //TextField("ok",text: $resolution)
            Picker("Vehicle", selection: $vehicle) {
                ForEach(0 ..< vehicleList.count, id: \.self) { index in
                    let value = self.vehicleList[index].svcRegoNo ?? ""
                    //let _ = print("tag: \(index) \(value)")
                    Text(value).tag(value)
                }
            }
        }
       
    }
}
extension Vehicles {
    // ❇️ The @FetchRequest property wrapper in the ContentView will call this function
    static func allFetchRequest() -> NSFetchRequest<Vehicles> {
        let request: NSFetchRequest<Vehicles> = Vehicles.fetchRequest()
        //as! NSFetchRequest<MeaResolution>
        
        // ❇️ The @FetchRequest property wrapper in the ContentView requires a sort descriptor
        request.sortDescriptors = [NSSortDescriptor(key: "svcEngineer", ascending: true)]
          
        return request
    }
}/*struct VehiclesPickerView_Previews: PreviewProvider {
    @State var units = ""
    static var previews: some View {
        UnitsPickerView()
    }
}*/
