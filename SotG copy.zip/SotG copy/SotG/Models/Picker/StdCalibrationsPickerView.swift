//
//  StdCalibrationsPickerView.swift
//  SotG
//
//  Created by Administrator on 22/1/2023.
//

import SwiftUI
import CoreData

struct StdCalibrationsPickerView: View {
    @Binding var calibration: String
    
    @FetchRequest(fetchRequest: MeaStdCalibrations.allFetchRequest())
    var calibrationList: FetchedResults<MeaStdCalibrations>
    
    init(_ binding:Binding<String?>){
        
        print("StdCalibrationsView init \(binding.wrappedValue ?? "nil")")
        _calibration = Binding(binding,"")
        
       
    }
    var body: some View {
        HStack {
            Text("Calibration: ")
            let _ = print("calibration: \(calibration)")
            //TextField("ok",text: $resolution)
            Picker("Calibration", selection: $calibration) {
                ForEach(0 ..< calibrationList.count, id: \.self) { index in
                    let value = self.calibrationList[index].meaStdCalibration ?? ""
                    //let _ = print("tag: \(index) \(value)")
                    Text(value).tag(value)
                }
            }
        }
       
    }
}
extension MeaStdCalibrations {
    // ❇️ The @FetchRequest property wrapper in the ContentView will call this function
    static func allFetchRequest() -> NSFetchRequest<MeaStdCalibrations> {
        let request: NSFetchRequest<MeaStdCalibrations> = MeaStdCalibrations.fetchRequest()
        //as! NSFetchRequest<MeaResolution>
        
        // ❇️ The @FetchRequest property wrapper in the ContentView requires a sort descriptor
        request.sortDescriptors = [NSSortDescriptor(key: "meaStdCalibration", ascending: true)]
          
        return request
    }
}/*struct StdCalibrationsPickerView_Previews: PreviewProvider {
    @State var units = ""
    static var previews: some View {
        StdCalibrations()
    }
}*/
