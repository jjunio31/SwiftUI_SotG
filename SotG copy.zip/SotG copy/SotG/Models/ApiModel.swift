//
//  ApiModel.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import Foundation


struct  AuthData :Codable {
    
    var status: String
    var error: String?
    
    var meaAuthCode: String?
    
    var mea_eng_name: String?
    
}
struct  ApiData:Codable {
    //var id = UUID()
    var success: Bool
    var message: String
   
    var authData: AuthData?
    
}


protocol HasDictionaryValue {
    var dictionaryValue: [String: Any] { get }
    
}

func GetNiceDate<Key>(dateFormat:String, values:KeyedDecodingContainer<Key>,
                 forKey key: KeyedDecodingContainer<Key>.Key) -> Date where Key : CodingKey {
    
    var ret = Date();
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = dateFormat // "dd-MMM-yyyy"
    let string = try? values.decode(String.self, forKey: key)
    if let string = string {
        if let tmpRet = dateFormatter.date(from: string)
        {
            ret = tmpRet
            //let meaLastDate = dateFormatter.date(from: mMeaLastDue)
        }
    }
    return ret;
}
func GetNiceInt32<Key>(values:KeyedDecodingContainer<Key>,
                 forKey key: KeyedDecodingContainer<Key>.Key) -> Int32 where Key : CodingKey {
    
    var ret:Int32 = 0;
    
    let number = try? values.decode(Int32.self, forKey: key)
    if let number = number {
        ret = number
    }
    return ret;
}
func GetNiceString<Key>(values:KeyedDecodingContainer<Key>,
                 forKey key: KeyedDecodingContainer<Key>.Key) -> String where Key : CodingKey {
    
    var ret:String = "";
    
    let string = try? values.decode(String.self, forKey: key)
    if let string = string {
        ret = string
    }
    return ret;
}
func GetNiceBool<Key>(values:KeyedDecodingContainer<Key>,
                 forKey key: KeyedDecodingContainer<Key>.Key) -> Bool where Key : CodingKey {
    
    var ret:Bool = false;
    
    let bool = try? values.decode(Bool.self, forKey: key)
    if let bool = bool {
        ret = bool
    }
    return ret;
}
func GetNiceFloat<Key>(values:KeyedDecodingContainer<Key>,
                 forKey key: KeyedDecodingContainer<Key>.Key) -> Float where Key : CodingKey {
    
    var ret:Float = 0;
    
    let float = try? values.decode(Float.self, forKey: key)
    if let float = float {
        ret = float
    }
    return ret;
}





struct FileData :Decodable {
    //var description = "FileData"
    
    var Calls: [CallsCodeable]?
    var EngSched: [EngSchedCodeable]?
    var CallNotes: [CallNoteCodeable]?
    //var CallTimes: [CallTimesCodeable]
    var Customers: [CustomerCodeable]?
    var MeaDevices: [MeaDeviceCodeable]?
    var MeaTrade: [MeaTradeCodeable]?
    var MeaForklift: [MeaForkliftCodeable]?
    var MeaHopper: [MeaHopperCodeable]?
    var MeaMetalDetector: [MeaMetalDetectorCodeable]?
    var MeaMisc: [MeaMiscCodeable]?
    var MeaPhTester: [MeaPhTesterCodeable]?
    var MeaTemperature: [MeaTemperatureCodeable]?
    var MeaTestMasses: [MeaTestMassesCodeable]?
    var MeaWeighbridge: [WeighbridgeCodeable]?
    var MeaResolutions: [MeaResolutionsCodeable]?
    var MeaStdCalibrations: [MeaStdCalibrationsCodeable]?
    var MeaStdRemarks: [MeaStdRemarksCodeable]?
    var MeaUnits: [MeaUnitsCodeable]?
    var MeaWeighbridgeQns: [WeighbridgeQnCodeable]?
    var Vehicles: [VehiclesCodeable]?
    var MeaBaseMakes: [MeaBaseMakeCodeable]?
   
    
    
}

struct  ApiData2 :Decodable {
    //var id = UUID()
    var metadata: MetaData
    //var fileData: FileData
    
    
}
struct  ApiData3 :Decodable {
    //var id = UUID()
    //var metadata: MetaData
    var fileData: FileData
    
    
}
struct ManualsData :Decodable {
    //var description = "FileData"
    
    var manuals: [ManualsCodeable]
    var manualFolders: [ManualFoldersCodeable]
    
    
    
}
struct  ApiDataManuals :Decodable {
    //var id = UUID()
    var data: ManualsData
    //var fileData: FileData
    
    
}
struct MetaData :Codable {
    var success: Bool
    var message: String
    var error: [String]
    //var lines:[String]=[""]
    //var description = "MetaData"
    
}


