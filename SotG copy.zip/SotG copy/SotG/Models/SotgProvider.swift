//
//  SotgProvider.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//
import CoreData
import OSLog

class SotgProvider {
    let logger = Logger(subsystem: "au.com.awe.SotG", category: "persistence")
   
    
    static let shared = SotgProvider()
    private var notificationToken: NSObjectProtocol?
    private init()
    {
        notificationToken = NotificationCenter.default.addObserver(forName: .NSPersistentStoreRemoteChange, object: nil, queue: nil) { note in
            self.logger.debug("Received a persistent store remote change notification.")
            Task {
                await self.fetchPersistentHistory()
            }
        }
    }
    deinit {
        if let observer = notificationToken {
            NotificationCenter.default.removeObserver(observer)
        }
    }
    private var lastToken: NSPersistentHistoryToken?
    
    /// A persistent container to set up the Core Data stack.
    lazy var container: NSPersistentContainer = {
        /// - Tag: persistentContainer
        let container = NSPersistentContainer(name: "SotgModel2")
        
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve a persistent store description.")
        }
        
        //if inMemory {
        //  description.url = URL(fileURLWithPath: "/dev/null")
        //}
        
        // Enable persistent store remote change notifications
        /// - Tag: persistentStoreRemoteChange
        description.setOption(true as NSNumber,
                              forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        // Enable persistent history tracking
        /// - Tag: persistentHistoryTracking
        description.setOption(true as NSNumber,
                              forKey: NSPersistentHistoryTrackingKey)
        
        container.loadPersistentStores { storeDescription, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        
        // This sample refreshes UI by consuming store changes via persistent history tracking.
        /// - Tag: viewContextMergeParentChanges
        container.viewContext.automaticallyMergesChangesFromParent = false
        container.viewContext.name = "viewContext"
        /// - Tag: viewContextMergePolicy
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        container.viewContext.undoManager = nil
        container.viewContext.shouldDeleteInaccessibleFaults = true
        return container
    }()
    private func newTaskContext() -> NSManagedObjectContext {
        // Create a private queue context.
        /// - Tag: newBackgroundContext
        let taskContext = container.newBackgroundContext()
        taskContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        // Set unused undoManager to nil for macOS (it is nil by default on iOS)
        // to reduce resource requirements.
        taskContext.undoManager = nil
        return taskContext
    }
    func fetchPersistentHistory() async {
        do {
            try await fetchPersistentHistoryTransactionsAndChanges()
        } catch {
            logger.debug("\(error.localizedDescription)")
        }
    }
    private func fetchPersistentHistoryTransactionsAndChanges() async throws {
        let taskContext = newTaskContext()
        taskContext.name = "persistentHistoryContext"
        logger.debug("Start fetching persistent history changes from the store...")
        
        try await taskContext.perform {
            // Execute the persistent history change since the last transaction.
            /// - Tag: fetchHistory
            let changeRequest = NSPersistentHistoryChangeRequest.fetchHistory(after: self.lastToken)
            let historyResult = try taskContext.execute(changeRequest) as? NSPersistentHistoryResult
            if let history = historyResult?.result as? [NSPersistentHistoryTransaction],
               !history.isEmpty {
                self.mergePersistentHistoryChanges(from: history)
                return
            }
            
            self.logger.debug("No persistent history transactions found.")
            throw SotgCatchError.persistentHistoryChangeError
        }
        
        logger.debug("Finished merging history changes.")
    }
    
    private func mergePersistentHistoryChanges(from history: [NSPersistentHistoryTransaction]) {
        self.logger.debug("Received \(history.count) persistent history transactions.")
        // Update view context with objectIDs from history change request.
        /// - Tag: mergeChanges
        let viewContext = container.viewContext
        viewContext.perform {
            for transaction in history {
                viewContext.mergeChanges(fromContextDidSave: transaction.objectIDNotification())
                self.lastToken = transaction.token
            }
        }
    }
    
    /* *****************************************************************************************************
     *
     * DeleteAll
     *
     * *****************************************************************************************************/
    
    func DeleteAllManuals() async throws    {
        try await DeleteOne(entityName: "Manuals")
        try await DeleteOne(entityName: "ManualFolders")
    
       
    }
    /* *****************************************************************************************************
     *
     * DeleteAll
     *
     * *****************************************************************************************************/
    
    func DeleteAll() async throws    {
        try await DeleteOne(entityName: "CallNote")
        try await DeleteOne(entityName: "Call")
        try await DeleteOne(entityName: "Customer")
        try await DeleteOne(entityName: "EngSched")
        try await DeleteOne(entityName: "MeaDevice")
        try await DeleteOne(entityName: "MeaTrade")
        try await DeleteOne(entityName: "MeaForklift")
        try await DeleteOne(entityName: "MeaHopper")
        
        try await DeleteOne(entityName: "MeaMisc")
        
        try await DeleteOne(entityName: "MeaTemperature")
        try await DeleteOne(entityName: "MeaTestMasses")
        try await DeleteOne(entityName: "MeaWeighbridge")
      
        try await DeleteOne(entityName: "MeaPhTester")
        try await DeleteOne(entityName: "MeaResolution")
        try await DeleteOne(entityName: "MeaMetal")
        try await DeleteOne(entityName: "MeaStdCalibrations")
        try await DeleteOne(entityName: "MeaStdRemarks")
        try await DeleteOne(entityName: "MeaUnits")
        try await DeleteOne(entityName: "MeaWeighbridgeQns")
      
        try await DeleteOne(entityName: "Vehicles")
      
        try await DeleteOne(entityName: "MeaBaseMakes")
      
       
      
      
       
    }
    
    /******************************************************************************************************
     *
     * getCall
     *
     ****************************************************************************************************/
    func GetCall(callNo:String,context: NSManagedObjectContext) ->Call?  {
        
        
        var ret : Call? =  nil
        //var engCode = ""
        let request: NSFetchRequest<Call> = Call.fetchRequest()
        //request.fetchLimit = 1
        request.sortDescriptors = []
        request.predicate = NSPredicate(format: "callNo = %@",
                                        callNo
                                        )
        do {
            let records = try context.fetch(request)
            
            
            records.forEach { call in
                
                ret = call
                
                
            }
            
        } catch {
            print(error.localizedDescription)
            
        }
        
        
        
        //setting = ret
        return ret
        
    }
    /******************************************************************************************************
     *
     * getDevice
     *
     ****************************************************************************************************/
    func GetDevice(meaDeviceId:Int32,context: NSManagedObjectContext) ->MeaDevice?  {
        print("Get Device \(meaDeviceId)")
        
        var ret : MeaDevice? =  nil
        //var engCode = ""
        let request: NSFetchRequest<MeaDevice> = MeaDevice.fetchRequest()
        //request.fetchLimit = 1
        let id:Int = Int(meaDeviceId)
        request.sortDescriptors = []
        request.predicate = NSPredicate(format: "meaDeviceId == %i",
                                        id
                                        )
        do {
            let records = try context.fetch(request)
            
            
            records.forEach { device in
                
                ret = device
                
                
            }
            
        } catch {
            print(error.localizedDescription)
            
        }
        
        
        
        //setting = ret
        return ret
        
    }
        
    func DeleteOne(entityName:String) async throws {
        // Create Fetch Request
        let taskContext = newTaskContext()
        taskContext.name = "deleteContext"
        taskContext.transactionAuthor = "DeleteOne"
        try await taskContext.perform {
            print("About to get fetchrequest \(entityName)")
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
            print("About to get batchDeleteRequest \(entityName)")
                    // Create Batch Delete Request
            let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
            
            print("About to get exec batchDeleteRequest \(entityName)")
            do {
               try taskContext.execute(batchDeleteRequest)
                print("Done exec batchDeleteRequest \(entityName)")
                return
            } catch {
                self.logger.debug("Failed to execute batch delete request. \(entityName)")
                throw SotgCatchError.batchDeleteError
            }
            
            //let deleteRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
            //if let fetchResult = try? taskContext.execute(batchDeleteRequest),
              // let batchDeleteResult = fetchResult as? NSBatchInsertResult,
               //let success = batchDeleteResult.result as? Bool, success {
                //return
           // }
           
            
           
        }
        
    }
    /****************************************************************************************************************
     *
     * importGeneric
     *
     * **************************************************************************************************************/
    func importGeneric(entity: NSEntityDescription,  propertiesList: [HasDictionaryValue]) async throws    {                     //from propertiesList: [CallsCodeable]) async throws    {
        guard !propertiesList.isEmpty else { return }
        
        let taskContext = newTaskContext()
        // Add name and author to identify source of persistent history changes.
        taskContext.name = "importContext"
        taskContext.transactionAuthor = "importEngSched"
        
        /// - Tag: performAndWait
        try await taskContext.perform {
            /// Execute the batch insert.
            /// - Tag: batchInsertRequest
            
            let batchInsertRequest = self.batchInsertRequest(entity: entity,
                                                                propertyList:propertiesList)
            if let fetchResult = try? taskContext.execute(batchInsertRequest),
               let batchInsertResult = fetchResult as? NSBatchInsertResult,
               let success = batchInsertResult.result as? Bool, success {
                return
            }
            self.logger.debug("Failed to execute batch insert request.")
            throw SotgCatchError.batchInsertError
        }
        
        logger.debug("Successfully inserted data.")
    }
    
    private func batchInsertRequest(entity: NSEntityDescription,  propertyList: [HasDictionaryValue]) -> NSBatchInsertRequest {
        var index = 0
        let total = propertyList.count
        
        // Provide one dictionary at a time when the closure is called.
        
        let batchInsertRequest = NSBatchInsertRequest(entity: entity,
                                                      dictionaryHandler: { dictionary in
            guard index < total else { return true }
            print("newBatchInsertCallsRequest propertiesList (index) \(index) \(propertyList[index].dictionaryValue)")
            dictionary.addEntries(from: propertyList[index].dictionaryValue)
            //
            index += 1
            return false
        })
        
        return batchInsertRequest
    }
    
    
}




