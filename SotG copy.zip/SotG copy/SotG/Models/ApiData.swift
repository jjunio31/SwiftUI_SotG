//
//  ApiData.swift
//  SotG
//
//  Created by Barry Hunter on 2/1/2023.
//

import CoreData
import OSLog

/// Stores an array of decoded DataProperties for later use in
/// creating or updating Data instances.
struct ApiDataJSON: Decodable {
    
    private enum RootCodingKeys: String, CodingKey {
        case fileData
        case metadata
        
    }
    
    private enum ApiDataCodingKeys: String, CodingKey {
        case CallNotes
        case Calls
        case EngSched
        case Customers
    }
    
    
    private(set) var engSchedPropertiesList = [EngSchedProperties]()
    private(set) var callPropertiesList = [CallProperties]()
    

    init(from decoder: Decoder) throws {
        let rootContainer = try decoder.container(keyedBy: RootCodingKeys.self)
        print("rootContainer ok");
        if let metadata = try? rootContainer.decode(MetDataProperties.self, forKey: .metadata) {
            print("metadata.success \(metadata.success)")
            print("metadata.message \(metadata.message)")
            print("metadata.error \(metadata.error)")
        }
        
        if let dataContainer = try? rootContainer.decode(ApiDataProperties.self, forKey: .fileData) {
            // var dataContainer = try rootContainer.nestedContainer(keyedBy: ApiDataCodingKeys.self)
            //nestedUnkeyedContainer(forKey: .fileData)
            /*while !dataContainer.isAtEnd {
                print("dataContainer ok - loop");
                let apiContainer = try dataContainer.nestedContainer(keyedBy: ApiDataCodingKeys.self)
                if let calls = try? apiContainer.decode(CallProperties.self, forKey: .Calls) {
                    print("rootContainer ok - Calls");
                    callPropertiesList.append(calls)
                }
                if let engSched = try? apiContainer.decode(EngSchedProperties.self, forKey: .EngSched) {
                    engSchedPropertiesList.append(engSched)
                }
             */
            //}
        }
        print("callPropertiesList.count \(callPropertiesList.count)")
        print("engSchedPropertiesList.count \(engSchedPropertiesList.count)")
        //print("rootContainer \(rootContainer.success)")
        //let success = try rootContainer.nestedUnkeyedContainer(forKey: .success)
        //let message = try rootContainer.nestedUnkeyedContainer(forKey: .message)
        //let filedata = try rootContainer.nestedContainer(keyedBy: FileDataKeys.self)
        //let calls = try filedata.nestedUnkeyedContainer(forKey: .calls)
        //decoder.container(keyedBy: RootCodingKeys.self)
        //var dataContainer = try rootContainer.nestedUnkeyedContainer(forKey: .sotgApi)
        
        /*while !featuresContainer.isAtEnd {
            let propertiesContainer = try featuresContainer.nestedContainer(keyedBy: FeatureCodingKeys.self)
            
            // Decodes a single quake from the data, and appends it to the array, ignoring invalid data.
            if let properties = try? propertiesContainer.decode(EngSchedProperties.self, forKey: .properties) {
                engSchedPropertiesList.append(properties)
            }
        }
         */
    }
}

/// A struct for decoding JSON with the following structure:
///
/// {
///    "features": [
///          {
///       "properties": {
///         "mag":1.9,
///         "place":"21km ENE of Honaunau-Napoopoo, Hawaii",
///         "time":1539187727610,"updated":1539187924350,
///         "code":"70643082"
///       }
///     }
///   ]
/// }
///
///
/// Stores an array of decoded QuakeProperties for later use in
/// creating or updating Quake instances.
struct EngSchedJSON: Decodable {
    
    private enum RootCodingKeys: String, CodingKey {
        case features
    }
    
    private enum FeatureCodingKeys: String, CodingKey {
        case properties
    }
    
    private(set) var engSchedPropertiesList = [EngSchedProperties]()

    init(from decoder: Decoder) throws {
        let rootContainer = try decoder.container(keyedBy: RootCodingKeys.self)
        var featuresContainer = try rootContainer.nestedUnkeyedContainer(forKey: .features)
        
        while !featuresContainer.isAtEnd {
            let propertiesContainer = try featuresContainer.nestedContainer(keyedBy: FeatureCodingKeys.self)
            
            // Decodes a single quake from the data, and appends it to the array, ignoring invalid data.
            if let properties = try? propertiesContainer.decode(EngSchedProperties.self, forKey: .properties) {
                engSchedPropertiesList.append(properties)
            }
        }
    }
}
struct  CallProperties: Decodable {
    
    // MARK: Codable
    
    private enum CodingKeys: String, CodingKey {
        case callNo
        case callServiceCentre
        case callStatus
        
    }
    let callNo:Int32
    let callServiceCentre:String
    let callStatus:String
    
    var dictionaryValue: [String: Any] {
        [
            "callNo": callNo,
            "callServiceCentre": callServiceCentre,
            "callStatus": callStatus,
           
        ]
    }
}
struct  MetDataProperties: Decodable {
    
    // MARK: Codable
    
    private enum CodingKeys: String, CodingKey {
        case message
        case success
        case error
        
    }
    let success:Bool
    let error:String
    let message:String
}
struct ApiDataProperties: Decodable {
    
    // MARK: Codable
    
    private enum CodingKeys: String, CodingKey {
        case Calls
        case EngSched
        
        
    }
    let Calls:String
    let EngSched:String
    
}
struct  EngSchedProperties: Decodable {

    // MARK: Codable
    
    private enum CodingKeys: String, CodingKey {
        case callNo
        case engCode
        
    }
    
    
    let callNo: Int32   // 1.9
    let engCode: String      // "21km ENE of Honaunau-Napoopoo, Hawaii"
    
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        let rawCallNo = try? values.decode(Int32.self, forKey: .callNo)
        let rawEngCode = try? values.decode(String.self, forKey: .engCode)
        
        
        // Ignore earthquakes with missing data.
        guard let callNo = rawCallNo,
              let engCode = rawEngCode
              
        else {
            let values = "rawCallNo = \(rawCallNo?.description ?? "nil"), "
            + "engCode = \(rawEngCode?.description ?? "nil")"
           

            let logger = Logger(subsystem: "com.awe.sotg.EngSched", category: "parsing")
            logger.debug("Ignored: \(values)")

            throw SotgCatchError.missingData(data: values)
        }
        
        self.callNo = callNo
        self.engCode = engCode
       
    }
    
    // The keys must have the same name as the attributes of the Quake entity.
    var dictionaryValue: [String: Any] {
        [
            "callNo": callNo,
            "engCode": engCode,
           
        ]
    }
}
