//
//  MeaPhTesterCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaPhTesterCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaPhTester
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32:Key
/// meaReportNo:String:Key
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaIsFirstCalibration:Bool
/// meaIsPreCalibration:Bool
/// meaIsRecalibrated:Bool
/// meaNominalReading1:String
/// meaNominalReading2:String
/// meaNominalReading3:String
/// meaNominalReading4:String
/// meaNominalReading5:String
/// meaNominalReading6:String
/// meaNominalReading7:String
/// meaNominalReading8:String
/// meaPrecalibration1:String
/// meaPrecalibration2:String
/// meaPrecalibration3:String
/// meaPrecalibration4:String
/// meaPrecalibration5:String
/// meaPrecalibration6:String
/// meaPrecalibration7:String
/// meaPrecalibration8:String
/// meaFinalReading1:String
/// meaFinalReading2:String
/// meaFinalReading3:String
/// meaFinalReading4:String
/// meaFinalReading5:String
/// meaFinalReading6:String
/// meaFinalReading7:String
/// meaFinalReading8:String
/// meaRepeatNomA:String
/// meaRepeatA1:String
/// meaRepeatA2:String
/// meaRepeatA3:String
/// meaRepeatNomB:String
/// meaRepeatB1:String
/// meaRepeatB2:String
/// meaRepeatB3:String
/// meaCalibrationMassesUsed:String
/// meaRemarks1:String
/// meaRemarks2:String
/// meaRemarks3:String
/// meaRemarks4:String
/// meaRemarks5:String
/// meaTester:String
/// meaDate:Date
/// meaTemperature:Float
/// meaRecalInterval:Int32
/// meaChanged:String
/// meaAuthorised:String
/// meaAuthorisedBy:String
///
    private enum CodingKeys: String, CodingKey {
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaIsFirstCalibration
        case meaIsPreCalibration
        case meaIsRecalibrated
        case meaNominalReading1
        case meaNominalReading2
        case meaNominalReading3
        case meaNominalReading4
        case meaNominalReading5
        case meaNominalReading6
        case meaNominalReading7
        case meaNominalReading8
        case meaPrecalibration1
        case meaPrecalibration2
        case meaPrecalibration3
        case meaPrecalibration4
        case meaPrecalibration5
        case meaPrecalibration6
        case meaPrecalibration7
        case meaPrecalibration8
        case meaFinalReading1
        case meaFinalReading2
        case meaFinalReading3
        case meaFinalReading4
        case meaFinalReading5
        case meaFinalReading6
        case meaFinalReading7
        case meaFinalReading8
        case meaRepeatNomA
        case meaRepeatA1
        case meaRepeatA2
        case meaRepeatA3
        case meaRepeatNomB
        case meaRepeatB1
        case meaRepeatB2
        case meaRepeatB3
        case meaCalibrationMassesUsed
        case meaRemarks1
        case meaRemarks2
        case meaRemarks3
        case meaRemarks4
        case meaRemarks5
        case meaTester
        case meaDate
        case meaTemperature
        case meaRecalInterval
        case meaChanged
        case meaAuthorised
        case meaAuthorisedBy
    }

    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaIsFirstCalibration:Bool
    let meaIsPreCalibration:Bool
    let meaIsRecalibrated:Bool
    let meaNominalReading1:String
    let meaNominalReading2:String
    let meaNominalReading3:String
    let meaNominalReading4:String
    let meaNominalReading5:String
    let meaNominalReading6:String
    let meaNominalReading7:String
    let meaNominalReading8:String
    let meaPrecalibration1:String
    let meaPrecalibration2:String
    let meaPrecalibration3:String
    let meaPrecalibration4:String
    let meaPrecalibration5:String
    let meaPrecalibration6:String
    let meaPrecalibration7:String
    let meaPrecalibration8:String
    let meaFinalReading1:String
    let meaFinalReading2:String
    let meaFinalReading3:String
    let meaFinalReading4:String
    let meaFinalReading5:String
    let meaFinalReading6:String
    let meaFinalReading7:String
    let meaFinalReading8:String
    let meaRepeatNomA:String
    let meaRepeatA1:String
    let meaRepeatA2:String
    let meaRepeatA3:String
    let meaRepeatNomB:String
    let meaRepeatB1:String
    let meaRepeatB2:String
    let meaRepeatB3:String
    let meaCalibrationMassesUsed:String
    let meaRemarks1:String
    let meaRemarks2:String
    let meaRemarks3:String
    let meaRemarks4:String
    let meaRemarks5:String
    let meaTester:String
    let meaDate:Date
    let meaTemperature:Float
    let meaRecalInterval:Int32
    let meaChanged:String
    let meaAuthorised:String
    let meaAuthorisedBy:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaReportNo = try? values.decode(String.self, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaIsFirstCalibration = GetNiceBool(values:values, forKey: .meaIsFirstCalibration)
        let meaIsPreCalibration = GetNiceBool(values:values, forKey: .meaIsPreCalibration)
        let meaIsRecalibrated = GetNiceBool(values:values, forKey: .meaIsRecalibrated)
        let meaNominalReading1 = GetNiceString(values:values, forKey: .meaNominalReading1)
        let meaNominalReading2 = GetNiceString(values:values, forKey: .meaNominalReading2)
        let meaNominalReading3 = GetNiceString(values:values, forKey: .meaNominalReading3)
        let meaNominalReading4 = GetNiceString(values:values, forKey: .meaNominalReading4)
        let meaNominalReading5 = GetNiceString(values:values, forKey: .meaNominalReading5)
        let meaNominalReading6 = GetNiceString(values:values, forKey: .meaNominalReading6)
        let meaNominalReading7 = GetNiceString(values:values, forKey: .meaNominalReading7)
        let meaNominalReading8 = GetNiceString(values:values, forKey: .meaNominalReading8)
        let meaPrecalibration1 = GetNiceString(values:values, forKey: .meaPrecalibration1)
        let meaPrecalibration2 = GetNiceString(values:values, forKey: .meaPrecalibration2)
        let meaPrecalibration3 = GetNiceString(values:values, forKey: .meaPrecalibration3)
        let meaPrecalibration4 = GetNiceString(values:values, forKey: .meaPrecalibration4)
        let meaPrecalibration5 = GetNiceString(values:values, forKey: .meaPrecalibration5)
        let meaPrecalibration6 = GetNiceString(values:values, forKey: .meaPrecalibration6)
        let meaPrecalibration7 = GetNiceString(values:values, forKey: .meaPrecalibration7)
        let meaPrecalibration8 = GetNiceString(values:values, forKey: .meaPrecalibration8)
        let meaFinalReading1 = GetNiceString(values:values, forKey: .meaFinalReading1)
        let meaFinalReading2 = GetNiceString(values:values, forKey: .meaFinalReading2)
        let meaFinalReading3 = GetNiceString(values:values, forKey: .meaFinalReading3)
        let meaFinalReading4 = GetNiceString(values:values, forKey: .meaFinalReading4)
        let meaFinalReading5 = GetNiceString(values:values, forKey: .meaFinalReading5)
        let meaFinalReading6 = GetNiceString(values:values, forKey: .meaFinalReading6)
        let meaFinalReading7 = GetNiceString(values:values, forKey: .meaFinalReading7)
        let meaFinalReading8 = GetNiceString(values:values, forKey: .meaFinalReading8)
        let meaRepeatNomA = GetNiceString(values:values, forKey: .meaRepeatNomA)
        let meaRepeatA1 = GetNiceString(values:values, forKey: .meaRepeatA1)
        let meaRepeatA2 = GetNiceString(values:values, forKey: .meaRepeatA2)
        let meaRepeatA3 = GetNiceString(values:values, forKey: .meaRepeatA3)
        let meaRepeatNomB = GetNiceString(values:values, forKey: .meaRepeatNomB)
        let meaRepeatB1 = GetNiceString(values:values, forKey: .meaRepeatB1)
        let meaRepeatB2 = GetNiceString(values:values, forKey: .meaRepeatB2)
        let meaRepeatB3 = GetNiceString(values:values, forKey: .meaRepeatB3)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaRemarks1 = GetNiceString(values:values, forKey: .meaRemarks1)
        let meaRemarks2 = GetNiceString(values:values, forKey: .meaRemarks2)
        let meaRemarks3 = GetNiceString(values:values, forKey: .meaRemarks3)
        let meaRemarks4 = GetNiceString(values:values, forKey: .meaRemarks4)
        let meaRemarks5 = GetNiceString(values:values, forKey: .meaRemarks5)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaTemperature = GetNiceFloat(values:values, forKey: .meaTemperature)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaChanged = GetNiceString(values:values, forKey: .meaChanged)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)

    guard
        let meaCalibrationId = rawMeaCalibrationId,
        let meaDeviceId = rawMeaDeviceId,
        let meaReportNo = rawMeaReportNo
     else {
         var strValues = "Error Importing Table: MeaPhTester"
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        strValues += "\nmeaReportNo = \(rawMeaReportNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaIsFirstCalibration = meaIsFirstCalibration
        self.meaIsPreCalibration = meaIsPreCalibration
        self.meaIsRecalibrated = meaIsRecalibrated
        self.meaNominalReading1 = meaNominalReading1
        self.meaNominalReading2 = meaNominalReading2
        self.meaNominalReading3 = meaNominalReading3
        self.meaNominalReading4 = meaNominalReading4
        self.meaNominalReading5 = meaNominalReading5
        self.meaNominalReading6 = meaNominalReading6
        self.meaNominalReading7 = meaNominalReading7
        self.meaNominalReading8 = meaNominalReading8
        self.meaPrecalibration1 = meaPrecalibration1
        self.meaPrecalibration2 = meaPrecalibration2
        self.meaPrecalibration3 = meaPrecalibration3
        self.meaPrecalibration4 = meaPrecalibration4
        self.meaPrecalibration5 = meaPrecalibration5
        self.meaPrecalibration6 = meaPrecalibration6
        self.meaPrecalibration7 = meaPrecalibration7
        self.meaPrecalibration8 = meaPrecalibration8
        self.meaFinalReading1 = meaFinalReading1
        self.meaFinalReading2 = meaFinalReading2
        self.meaFinalReading3 = meaFinalReading3
        self.meaFinalReading4 = meaFinalReading4
        self.meaFinalReading5 = meaFinalReading5
        self.meaFinalReading6 = meaFinalReading6
        self.meaFinalReading7 = meaFinalReading7
        self.meaFinalReading8 = meaFinalReading8
        self.meaRepeatNomA = meaRepeatNomA
        self.meaRepeatA1 = meaRepeatA1
        self.meaRepeatA2 = meaRepeatA2
        self.meaRepeatA3 = meaRepeatA3
        self.meaRepeatNomB = meaRepeatNomB
        self.meaRepeatB1 = meaRepeatB1
        self.meaRepeatB2 = meaRepeatB2
        self.meaRepeatB3 = meaRepeatB3
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaRemarks1 = meaRemarks1
        self.meaRemarks2 = meaRemarks2
        self.meaRemarks3 = meaRemarks3
        self.meaRemarks4 = meaRemarks4
        self.meaRemarks5 = meaRemarks5
        self.meaTester = meaTester
        self.meaDate = meaDate
        self.meaTemperature = meaTemperature
        self.meaRecalInterval = meaRecalInterval
        self.meaChanged = meaChanged
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
    }

    var dictionaryValue: [String: Any] {
    [
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaIsFirstCalibration" : meaIsFirstCalibration,
        "meaIsPreCalibration" : meaIsPreCalibration,
        "meaIsRecalibrated" : meaIsRecalibrated,
        "meaNominalReading1" : meaNominalReading1,
        "meaNominalReading2" : meaNominalReading2,
        "meaNominalReading3" : meaNominalReading3,
        "meaNominalReading4" : meaNominalReading4,
        "meaNominalReading5" : meaNominalReading5,
        "meaNominalReading6" : meaNominalReading6,
        "meaNominalReading7" : meaNominalReading7,
        "meaNominalReading8" : meaNominalReading8,
        "meaPrecalibration1" : meaPrecalibration1,
        "meaPrecalibration2" : meaPrecalibration2,
        "meaPrecalibration3" : meaPrecalibration3,
        "meaPrecalibration4" : meaPrecalibration4,
        "meaPrecalibration5" : meaPrecalibration5,
        "meaPrecalibration6" : meaPrecalibration6,
        "meaPrecalibration7" : meaPrecalibration7,
        "meaPrecalibration8" : meaPrecalibration8,
        "meaFinalReading1" : meaFinalReading1,
        "meaFinalReading2" : meaFinalReading2,
        "meaFinalReading3" : meaFinalReading3,
        "meaFinalReading4" : meaFinalReading4,
        "meaFinalReading5" : meaFinalReading5,
        "meaFinalReading6" : meaFinalReading6,
        "meaFinalReading7" : meaFinalReading7,
        "meaFinalReading8" : meaFinalReading8,
        "meaRepeatNomA" : meaRepeatNomA,
        "meaRepeatA1" : meaRepeatA1,
        "meaRepeatA2" : meaRepeatA2,
        "meaRepeatA3" : meaRepeatA3,
        "meaRepeatNomB" : meaRepeatNomB,
        "meaRepeatB1" : meaRepeatB1,
        "meaRepeatB2" : meaRepeatB2,
        "meaRepeatB3" : meaRepeatB3,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaRemarks1" : meaRemarks1,
        "meaRemarks2" : meaRemarks2,
        "meaRemarks3" : meaRemarks3,
        "meaRemarks4" : meaRemarks4,
        "meaRemarks5" : meaRemarks5,
        "meaTester" : meaTester,
        "meaDate" : meaDate,
        "meaTemperature" : meaTemperature,
        "meaRecalInterval" : meaRecalInterval,
        "meaChanged" : meaChanged,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        ]
    }
}
