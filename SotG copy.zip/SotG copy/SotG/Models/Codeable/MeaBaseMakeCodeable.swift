//
//  MeaBaseMakeCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaBaseMakeCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaBaseMake
/// meaBaseMake:String:Key
///
    private enum CodingKeys: String, CodingKey {
        case meaBaseMake
    }

    let meaBaseMake:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaBaseMake = try? values.decode(String.self, forKey: .meaBaseMake)

    guard
        let meaBaseMake = rawMeaBaseMake
     else {
         var strValues = "Error Importing Table: MeaBaseMake"
        strValues += "\nmeaBaseMake = \(rawMeaBaseMake?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaBaseMake = meaBaseMake
    }

    var dictionaryValue: [String: Any] {
    [
        "meaBaseMake" : meaBaseMake,
        ]
    }
}
