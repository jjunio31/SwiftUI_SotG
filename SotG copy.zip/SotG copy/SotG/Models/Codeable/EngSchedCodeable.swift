//
//  EngSchedCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct EngSchedCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:EngSched
/// callNo:Int32:Key
/// engCode:String:Key
/// dateToAttend:Date
/// dateString:String
/// timeString:String
///
    private enum CodingKeys: String, CodingKey {
        case callNo
        case engCode
        case dateToAttend
        case dateString
        case timeString
    }

    let callNo:Int32
    let engCode:String
    let dateToAttend:Date
    let dateString:String
    let timeString:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawCallNo = try? values.decode(Int32.self, forKey: .callNo)
        let rawEngCode = try? values.decode(String.self, forKey: .engCode)
        let dateToAttend = GetNiceDate(dateFormat: "yyyy-MM-dd HH:mm:ss",values:values, forKey: .dateToAttend)
        let dateString = GetNiceString(values:values, forKey: .dateString)
        let timeString = GetNiceString(values:values, forKey: .timeString)

    guard
        let callNo = rawCallNo,
        let engCode = rawEngCode
     else {
         var strValues = "Error Importing Table: EngSched"
        strValues += "\ncallNo = \(rawCallNo?.description ?? "nil") "
        strValues += "\nengCode = \(rawEngCode?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.callNo = callNo
        self.engCode = engCode
        self.dateToAttend = dateToAttend
        self.dateString = dateString
        self.timeString = timeString
    }

    var dictionaryValue: [String: Any] {
    [
        "callNo" : callNo,
        "engCode" : engCode,
        "dateToAttend" : dateToAttend,
        "dateString" : dateString,
        "timeString" : timeString,
        ]
    }
}
