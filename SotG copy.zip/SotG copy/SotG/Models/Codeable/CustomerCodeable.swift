//
//  CustomerCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct CustomerCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:Customer
/// accountcode:String:Key
/// shortname:String
/// address:String
/// phone:String
/// debNotes:String
///
    private enum CodingKeys: String, CodingKey {
        case accountcode
        case shortname
        case address
        case phone
        case debNotes
    }

    let accountcode:String
    let shortname:String
    let address:String
    let phone:String
    let debNotes:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        let rawAccountcode = try? values.decode(String.self, forKey: .accountcode)
        let rawShortname = try? values.decode(String.self, forKey: .shortname)
        let rawAddress = try? values.decode(String.self, forKey: .address)
        let rawPhone = try? values.decode(String.self, forKey: .phone)
        let rawDebNotes = try? values.decode(String.self, forKey: .debNotes)

    guard
        let accountcode = rawAccountcode,
        let shortname = rawShortname,
        let address = rawAddress,
        let phone = rawPhone,
        let debNotes = rawDebNotes
     else {
         var values = "Error Importing Table: Customer"
        values += "\naccountcode = \(rawAccountcode?.description ?? "nil") "
        if rawShortname == nil {values += "\nshortname is nil "}
        if rawAddress == nil {values += "\naddress is nil "}
        if rawPhone == nil {values += "\nphone is nil "}
        if rawDebNotes == nil {values += "\ndebNotes is nil "}

        print("Ignored: \(values)")
        throw SotgCatchError.missingData(data: values)
    }

        self.accountcode = accountcode
        self.shortname = shortname
        self.address = address
        self.phone = phone
        self.debNotes = debNotes
    }

    var dictionaryValue: [String: Any] {
    [
        "accountcode" : accountcode,
        "shortname" : shortname,
        "address" : address,
        "phone" : phone,
        "debNotes" : debNotes,
        ]
    }
}
