//
//  VehiclesCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct VehiclesCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:Vehicles
/// svcRegoNo:String:Key
/// svcEngineer:String
/// svcOdometer:Int32
/// svcServiceDue:Int32
/// svcStockCode:String
/// svcStockCode2:String
///
    private enum CodingKeys: String, CodingKey {
        case svcRegoNo
        case svcEngineer
        case svcOdometer
        case svcServiceDue
        case svcStockCode
        case svcStockCode2
    }

    let svcRegoNo:String
    let svcEngineer:String
    let svcOdometer:Int32
    let svcServiceDue:Int32
    let svcStockCode:String
    let svcStockCode2:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawSvcRegoNo = try? values.decode(String.self, forKey: .svcRegoNo)
        let svcEngineer = GetNiceString(values:values, forKey: .svcEngineer)
        let svcOdometer = GetNiceInt32(values:values, forKey: .svcOdometer)
        let svcServiceDue = GetNiceInt32(values:values, forKey: .svcServiceDue)
        let svcStockCode = GetNiceString(values:values, forKey: .svcStockCode)
        let svcStockCode2 = GetNiceString(values:values, forKey: .svcStockCode2)

    guard
        let svcRegoNo = rawSvcRegoNo
     else {
         var strValues = "Error Importing Table: Vehicles"
        strValues += "\nsvcRegoNo = \(rawSvcRegoNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.svcRegoNo = svcRegoNo
        self.svcEngineer = svcEngineer
        self.svcOdometer = svcOdometer
        self.svcServiceDue = svcServiceDue
        self.svcStockCode = svcStockCode
        self.svcStockCode2 = svcStockCode2
    }

    var dictionaryValue: [String: Any] {
    [
        "svcRegoNo" : svcRegoNo,
        "svcEngineer" : svcEngineer,
        "svcOdometer" : svcOdometer,
        "svcServiceDue" : svcServiceDue,
        "svcStockCode" : svcStockCode,
        "svcStockCode2" : svcStockCode2,
        ]
    }
}
