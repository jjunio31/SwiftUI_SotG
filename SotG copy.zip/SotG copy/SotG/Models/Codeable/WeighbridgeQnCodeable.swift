//
//  WeighbridgeQnCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct WeighbridgeQnCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:WeighbridgeQn
/// meaQuestionId:Int32:Key
/// meaWeighbrQuestion:String:Key
/// meaQuestionActive:String
///
    private enum CodingKeys: String, CodingKey {
        case meaQuestionId
        case meaWeighbrQuestion
        case meaQuestionActive
    }

    let meaQuestionId:Int32
    let meaWeighbrQuestion:String
    let meaQuestionActive:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaQuestionId = try? values.decode(Int32.self, forKey: .meaQuestionId)
        let rawMeaWeighbrQuestion = try? values.decode(String.self, forKey: .meaWeighbrQuestion)
        let meaQuestionActive = GetNiceString(values:values, forKey: .meaQuestionActive)

    guard
        let meaQuestionId = rawMeaQuestionId,
        let meaWeighbrQuestion = rawMeaWeighbrQuestion
     else {
         var strValues = "Error Importing Table: WeighbridgeQn"
        strValues += "\nmeaQuestionId = \(rawMeaQuestionId?.description ?? "nil") "
        strValues += "\nmeaWeighbrQuestion = \(rawMeaWeighbrQuestion?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaQuestionId = meaQuestionId
        self.meaWeighbrQuestion = meaWeighbrQuestion
        self.meaQuestionActive = meaQuestionActive
    }

    var dictionaryValue: [String: Any] {
    [
        "meaQuestionId" : meaQuestionId,
        "meaWeighbrQuestion" : meaWeighbrQuestion,
        "meaQuestionActive" : meaQuestionActive,
        ]
    }
}
