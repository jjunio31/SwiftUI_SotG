//
//  ManualFoldersCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct ManualFoldersCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:ManualFolders
/// name:String:Key
/// count:Int32
///
    private enum CodingKeys: String, CodingKey {
        case name
        case count
    }

    let name:String
    let count:Int32

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        let rawName = try? values.decode(String.self, forKey: .name)
        let rawCount = try? values.decode(Int32.self, forKey: .count)

    guard
        let name = rawName,
        let count = rawCount
     else {
         var strValues = "Error Importing Table: ManualFolders"
        strValues += "\nname = \(rawName?.description ?? "nil") "
        if rawCount == nil {strValues += "\ncount is nil "}

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.name = name
        self.count = count
    }

    var dictionaryValue: [String: Any] {
    [
        "name" : name,
        "count" : count,
        ]
    }
}
