//
//  MeaTemperatureCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation

struct MeaTemperatureCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaTemperature
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32:Key
/// meaReportNo:String:Key
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaIsFirstCalibration:Bool
/// meaIsPreCalibration:Bool
/// meaIsRecalibrated:Bool
/// meaCalibrationMassesUsed:String
/// meaRemarks1:String
/// meaRemarks2:String
/// meaRemarks3:String
/// meaRemarks4:String
/// meaRemarks5:String
/// meaTester:String
/// meaDate:Date
/// meaTemperature:Float
/// meaRecalInterval:Int32
/// meaNominalSet1:String
/// meaNominalSet2:String
/// meaNominalSet3:String
/// meaNominalSet4:String
/// meaNominalSet5:String
/// meaNominalSet6:String
/// meaNominalSet7:String
/// meaNominalSet8:String
/// meaNominalReading1:String
/// meaNominalReading2:String
/// meaNominalReading3:String
/// meaNominalReading4:String
/// meaNominalReading5:String
/// meaNominalReading6:String
/// meaNominalReading7:String
/// meaNominalReading8:String
/// meaPrecalDisplay1:String
/// meaPrecalDisplay2:String
/// meaPrecalDisplay3:String
/// meaPrecalDisplay4:String
/// meaPrecalDisplay5:String
/// meaPrecalDisplay6:String
/// meaPrecalDisplay7:String
/// meaPrecalDisplay8:String
/// meaPrecalCorrection1:String
/// meaPrecalCorrection2:String
/// meaPrecalCorrection3:String
/// meaPrecalCorrection4:String
/// meaPrecalCorrection5:String
/// meaPrecalCorrection6:String
/// meaPrecalCorrection7:String
/// meaPrecalCorrection8:String
/// meaFinalDisplay1:String
/// meaFinalDisplay2:String
/// meaFinalDisplay3:String
/// meaFinalDisplay4:String
/// meaFinalDisplay5:String
/// meaFinalDisplay6:String
/// meaFinalDisplay7:String
/// meaFinalDisplay8:String
/// meaFinalCorrection1:String
/// meaFinalCorrection2:String
/// meaFinalCorrection3:String
/// meaFinalCorrection4:String
/// meaFinalCorrection5:String
/// meaFinalCorrection6:String
/// meaFinalCorrection7:String
/// meaFinalCorrection8:String
/// meaNominalA:String
/// meaNominalB:String
/// meaNominalsA1:String
/// meaNominalsA2:String
/// meaNominalsA3:String
/// meaNominalsB1:String
/// meaNominalsB2:String
/// meaNominalsB3:String
/// meaChanged:String
/// meaAuthorised:String
/// meaAuthorisedBy:String
///
    private enum CodingKeys: String, CodingKey {
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaIsFirstCalibration
        case meaIsPreCalibration
        case meaIsRecalibrated
        case meaCalibrationMassesUsed
        case meaRemarks1
        case meaRemarks2
        case meaRemarks3
        case meaRemarks4
        case meaRemarks5
        case meaTester
        case meaDate
        case meaTemperature
        case meaRecalInterval
        case meaNominalSet1
        case meaNominalSet2
        case meaNominalSet3
        case meaNominalSet4
        case meaNominalSet5
        case meaNominalSet6
        case meaNominalSet7
        case meaNominalSet8
        case meaNominalReading1
        case meaNominalReading2
        case meaNominalReading3
        case meaNominalReading4
        case meaNominalReading5
        case meaNominalReading6
        case meaNominalReading7
        case meaNominalReading8
        case meaPrecalDisplay1
        case meaPrecalDisplay2
        case meaPrecalDisplay3
        case meaPrecalDisplay4
        case meaPrecalDisplay5
        case meaPrecalDisplay6
        case meaPrecalDisplay7
        case meaPrecalDisplay8
        case meaPrecalCorrection1
        case meaPrecalCorrection2
        case meaPrecalCorrection3
        case meaPrecalCorrection4
        case meaPrecalCorrection5
        case meaPrecalCorrection6
        case meaPrecalCorrection7
        case meaPrecalCorrection8
        case meaFinalDisplay1
        case meaFinalDisplay2
        case meaFinalDisplay3
        case meaFinalDisplay4
        case meaFinalDisplay5
        case meaFinalDisplay6
        case meaFinalDisplay7
        case meaFinalDisplay8
        case meaFinalCorrection1
        case meaFinalCorrection2
        case meaFinalCorrection3
        case meaFinalCorrection4
        case meaFinalCorrection5
        case meaFinalCorrection6
        case meaFinalCorrection7
        case meaFinalCorrection8
        case meaNominalA
        case meaNominalB
        case meaNominalsA1
        case meaNominalsA2
        case meaNominalsA3
        case meaNominalsB1
        case meaNominalsB2
        case meaNominalsB3
        case meaChanged
        case meaAuthorised
        case meaAuthorisedBy
    }

    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaIsFirstCalibration:Bool
    let meaIsPreCalibration:Bool
    let meaIsRecalibrated:Bool
    let meaCalibrationMassesUsed:String
    let meaRemarks1:String
    let meaRemarks2:String
    let meaRemarks3:String
    let meaRemarks4:String
    let meaRemarks5:String
    let meaTester:String
    let meaDate:Date
    let meaTemperature:Float
    let meaRecalInterval:Int32
    let meaNominalSet1:String
    let meaNominalSet2:String
    let meaNominalSet3:String
    let meaNominalSet4:String
    let meaNominalSet5:String
    let meaNominalSet6:String
    let meaNominalSet7:String
    let meaNominalSet8:String
    let meaNominalReading1:String
    let meaNominalReading2:String
    let meaNominalReading3:String
    let meaNominalReading4:String
    let meaNominalReading5:String
    let meaNominalReading6:String
    let meaNominalReading7:String
    let meaNominalReading8:String
    let meaPrecalDisplay1:String
    let meaPrecalDisplay2:String
    let meaPrecalDisplay3:String
    let meaPrecalDisplay4:String
    let meaPrecalDisplay5:String
    let meaPrecalDisplay6:String
    let meaPrecalDisplay7:String
    let meaPrecalDisplay8:String
    let meaPrecalCorrection1:String
    let meaPrecalCorrection2:String
    let meaPrecalCorrection3:String
    let meaPrecalCorrection4:String
    let meaPrecalCorrection5:String
    let meaPrecalCorrection6:String
    let meaPrecalCorrection7:String
    let meaPrecalCorrection8:String
    let meaFinalDisplay1:String
    let meaFinalDisplay2:String
    let meaFinalDisplay3:String
    let meaFinalDisplay4:String
    let meaFinalDisplay5:String
    let meaFinalDisplay6:String
    let meaFinalDisplay7:String
    let meaFinalDisplay8:String
    let meaFinalCorrection1:String
    let meaFinalCorrection2:String
    let meaFinalCorrection3:String
    let meaFinalCorrection4:String
    let meaFinalCorrection5:String
    let meaFinalCorrection6:String
    let meaFinalCorrection7:String
    let meaFinalCorrection8:String
    let meaNominalA:String
    let meaNominalB:String
    let meaNominalsA1:String
    let meaNominalsA2:String
    let meaNominalsA3:String
    let meaNominalsB1:String
    let meaNominalsB2:String
    let meaNominalsB3:String
    let meaChanged:String
    let meaAuthorised:String
    let meaAuthorisedBy:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaReportNo = try? values.decode(String.self, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaIsFirstCalibration = GetNiceBool(values:values, forKey: .meaIsFirstCalibration)
        let meaIsPreCalibration = GetNiceBool(values:values, forKey: .meaIsPreCalibration)
        let meaIsRecalibrated = GetNiceBool(values:values, forKey: .meaIsRecalibrated)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaRemarks1 = GetNiceString(values:values, forKey: .meaRemarks1)
        let meaRemarks2 = GetNiceString(values:values, forKey: .meaRemarks2)
        let meaRemarks3 = GetNiceString(values:values, forKey: .meaRemarks3)
        let meaRemarks4 = GetNiceString(values:values, forKey: .meaRemarks4)
        let meaRemarks5 = GetNiceString(values:values, forKey: .meaRemarks5)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaTemperature = GetNiceFloat(values:values, forKey: .meaTemperature)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaNominalSet1 = GetNiceString(values:values, forKey: .meaNominalSet1)
        let meaNominalSet2 = GetNiceString(values:values, forKey: .meaNominalSet2)
        let meaNominalSet3 = GetNiceString(values:values, forKey: .meaNominalSet3)
        let meaNominalSet4 = GetNiceString(values:values, forKey: .meaNominalSet4)
        let meaNominalSet5 = GetNiceString(values:values, forKey: .meaNominalSet5)
        let meaNominalSet6 = GetNiceString(values:values, forKey: .meaNominalSet6)
        let meaNominalSet7 = GetNiceString(values:values, forKey: .meaNominalSet7)
        let meaNominalSet8 = GetNiceString(values:values, forKey: .meaNominalSet8)
        let meaNominalReading1 = GetNiceString(values:values, forKey: .meaNominalReading1)
        let meaNominalReading2 = GetNiceString(values:values, forKey: .meaNominalReading2)
        let meaNominalReading3 = GetNiceString(values:values, forKey: .meaNominalReading3)
        let meaNominalReading4 = GetNiceString(values:values, forKey: .meaNominalReading4)
        let meaNominalReading5 = GetNiceString(values:values, forKey: .meaNominalReading5)
        let meaNominalReading6 = GetNiceString(values:values, forKey: .meaNominalReading6)
        let meaNominalReading7 = GetNiceString(values:values, forKey: .meaNominalReading7)
        let meaNominalReading8 = GetNiceString(values:values, forKey: .meaNominalReading8)
        let meaPrecalDisplay1 = GetNiceString(values:values, forKey: .meaPrecalDisplay1)
        let meaPrecalDisplay2 = GetNiceString(values:values, forKey: .meaPrecalDisplay2)
        let meaPrecalDisplay3 = GetNiceString(values:values, forKey: .meaPrecalDisplay3)
        let meaPrecalDisplay4 = GetNiceString(values:values, forKey: .meaPrecalDisplay4)
        let meaPrecalDisplay5 = GetNiceString(values:values, forKey: .meaPrecalDisplay5)
        let meaPrecalDisplay6 = GetNiceString(values:values, forKey: .meaPrecalDisplay6)
        let meaPrecalDisplay7 = GetNiceString(values:values, forKey: .meaPrecalDisplay7)
        let meaPrecalDisplay8 = GetNiceString(values:values, forKey: .meaPrecalDisplay8)
        let meaPrecalCorrection1 = GetNiceString(values:values, forKey: .meaPrecalCorrection1)
        let meaPrecalCorrection2 = GetNiceString(values:values, forKey: .meaPrecalCorrection2)
        let meaPrecalCorrection3 = GetNiceString(values:values, forKey: .meaPrecalCorrection3)
        let meaPrecalCorrection4 = GetNiceString(values:values, forKey: .meaPrecalCorrection4)
        let meaPrecalCorrection5 = GetNiceString(values:values, forKey: .meaPrecalCorrection5)
        let meaPrecalCorrection6 = GetNiceString(values:values, forKey: .meaPrecalCorrection6)
        let meaPrecalCorrection7 = GetNiceString(values:values, forKey: .meaPrecalCorrection7)
        let meaPrecalCorrection8 = GetNiceString(values:values, forKey: .meaPrecalCorrection8)
        let meaFinalDisplay1 = GetNiceString(values:values, forKey: .meaFinalDisplay1)
        let meaFinalDisplay2 = GetNiceString(values:values, forKey: .meaFinalDisplay2)
        let meaFinalDisplay3 = GetNiceString(values:values, forKey: .meaFinalDisplay3)
        let meaFinalDisplay4 = GetNiceString(values:values, forKey: .meaFinalDisplay4)
        let meaFinalDisplay5 = GetNiceString(values:values, forKey: .meaFinalDisplay5)
        let meaFinalDisplay6 = GetNiceString(values:values, forKey: .meaFinalDisplay6)
        let meaFinalDisplay7 = GetNiceString(values:values, forKey: .meaFinalDisplay7)
        let meaFinalDisplay8 = GetNiceString(values:values, forKey: .meaFinalDisplay8)
        let meaFinalCorrection1 = GetNiceString(values:values, forKey: .meaFinalCorrection1)
        let meaFinalCorrection2 = GetNiceString(values:values, forKey: .meaFinalCorrection2)
        let meaFinalCorrection3 = GetNiceString(values:values, forKey: .meaFinalCorrection3)
        let meaFinalCorrection4 = GetNiceString(values:values, forKey: .meaFinalCorrection4)
        let meaFinalCorrection5 = GetNiceString(values:values, forKey: .meaFinalCorrection5)
        let meaFinalCorrection6 = GetNiceString(values:values, forKey: .meaFinalCorrection6)
        let meaFinalCorrection7 = GetNiceString(values:values, forKey: .meaFinalCorrection7)
        let meaFinalCorrection8 = GetNiceString(values:values, forKey: .meaFinalCorrection8)
        let meaNominalA = GetNiceString(values:values, forKey: .meaNominalA)
        let meaNominalB = GetNiceString(values:values, forKey: .meaNominalB)
        let meaNominalsA1 = GetNiceString(values:values, forKey: .meaNominalsA1)
        let meaNominalsA2 = GetNiceString(values:values, forKey: .meaNominalsA2)
        let meaNominalsA3 = GetNiceString(values:values, forKey: .meaNominalsA3)
        let meaNominalsB1 = GetNiceString(values:values, forKey: .meaNominalsB1)
        let meaNominalsB2 = GetNiceString(values:values, forKey: .meaNominalsB2)
        let meaNominalsB3 = GetNiceString(values:values, forKey: .meaNominalsB3)
        let meaChanged = GetNiceString(values:values, forKey: .meaChanged)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)

    guard
        let meaCalibrationId = rawMeaCalibrationId,
        let meaDeviceId = rawMeaDeviceId,
        let meaReportNo = rawMeaReportNo
     else {
         var strValues = "Error Importing Table: MeaTemperature"
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        strValues += "\nmeaReportNo = \(rawMeaReportNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaIsFirstCalibration = meaIsFirstCalibration
        self.meaIsPreCalibration = meaIsPreCalibration
        self.meaIsRecalibrated = meaIsRecalibrated
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaRemarks1 = meaRemarks1
        self.meaRemarks2 = meaRemarks2
        self.meaRemarks3 = meaRemarks3
        self.meaRemarks4 = meaRemarks4
        self.meaRemarks5 = meaRemarks5
        self.meaTester = meaTester
        self.meaDate = meaDate
        self.meaTemperature = meaTemperature
        self.meaRecalInterval = meaRecalInterval
        self.meaNominalSet1 = meaNominalSet1
        self.meaNominalSet2 = meaNominalSet2
        self.meaNominalSet3 = meaNominalSet3
        self.meaNominalSet4 = meaNominalSet4
        self.meaNominalSet5 = meaNominalSet5
        self.meaNominalSet6 = meaNominalSet6
        self.meaNominalSet7 = meaNominalSet7
        self.meaNominalSet8 = meaNominalSet8
        self.meaNominalReading1 = meaNominalReading1
        self.meaNominalReading2 = meaNominalReading2
        self.meaNominalReading3 = meaNominalReading3
        self.meaNominalReading4 = meaNominalReading4
        self.meaNominalReading5 = meaNominalReading5
        self.meaNominalReading6 = meaNominalReading6
        self.meaNominalReading7 = meaNominalReading7
        self.meaNominalReading8 = meaNominalReading8
        self.meaPrecalDisplay1 = meaPrecalDisplay1
        self.meaPrecalDisplay2 = meaPrecalDisplay2
        self.meaPrecalDisplay3 = meaPrecalDisplay3
        self.meaPrecalDisplay4 = meaPrecalDisplay4
        self.meaPrecalDisplay5 = meaPrecalDisplay5
        self.meaPrecalDisplay6 = meaPrecalDisplay6
        self.meaPrecalDisplay7 = meaPrecalDisplay7
        self.meaPrecalDisplay8 = meaPrecalDisplay8
        self.meaPrecalCorrection1 = meaPrecalCorrection1
        self.meaPrecalCorrection2 = meaPrecalCorrection2
        self.meaPrecalCorrection3 = meaPrecalCorrection3
        self.meaPrecalCorrection4 = meaPrecalCorrection4
        self.meaPrecalCorrection5 = meaPrecalCorrection5
        self.meaPrecalCorrection6 = meaPrecalCorrection6
        self.meaPrecalCorrection7 = meaPrecalCorrection7
        self.meaPrecalCorrection8 = meaPrecalCorrection8
        self.meaFinalDisplay1 = meaFinalDisplay1
        self.meaFinalDisplay2 = meaFinalDisplay2
        self.meaFinalDisplay3 = meaFinalDisplay3
        self.meaFinalDisplay4 = meaFinalDisplay4
        self.meaFinalDisplay5 = meaFinalDisplay5
        self.meaFinalDisplay6 = meaFinalDisplay6
        self.meaFinalDisplay7 = meaFinalDisplay7
        self.meaFinalDisplay8 = meaFinalDisplay8
        self.meaFinalCorrection1 = meaFinalCorrection1
        self.meaFinalCorrection2 = meaFinalCorrection2
        self.meaFinalCorrection3 = meaFinalCorrection3
        self.meaFinalCorrection4 = meaFinalCorrection4
        self.meaFinalCorrection5 = meaFinalCorrection5
        self.meaFinalCorrection6 = meaFinalCorrection6
        self.meaFinalCorrection7 = meaFinalCorrection7
        self.meaFinalCorrection8 = meaFinalCorrection8
        self.meaNominalA = meaNominalA
        self.meaNominalB = meaNominalB
        self.meaNominalsA1 = meaNominalsA1
        self.meaNominalsA2 = meaNominalsA2
        self.meaNominalsA3 = meaNominalsA3
        self.meaNominalsB1 = meaNominalsB1
        self.meaNominalsB2 = meaNominalsB2
        self.meaNominalsB3 = meaNominalsB3
        self.meaChanged = meaChanged
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
    }

    var dictionaryValue: [String: Any] {
    [
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaIsFirstCalibration" : meaIsFirstCalibration,
        "meaIsPreCalibration" : meaIsPreCalibration,
        "meaIsRecalibrated" : meaIsRecalibrated,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaRemarks1" : meaRemarks1,
        "meaRemarks2" : meaRemarks2,
        "meaRemarks3" : meaRemarks3,
        "meaRemarks4" : meaRemarks4,
        "meaRemarks5" : meaRemarks5,
        "meaTester" : meaTester,
        "meaDate" : meaDate,
        "meaTemperature" : meaTemperature,
        "meaRecalInterval" : meaRecalInterval,
        "meaNominalSet1" : meaNominalSet1,
        "meaNominalSet2" : meaNominalSet2,
        "meaNominalSet3" : meaNominalSet3,
        "meaNominalSet4" : meaNominalSet4,
        "meaNominalSet5" : meaNominalSet5,
        "meaNominalSet6" : meaNominalSet6,
        "meaNominalSet7" : meaNominalSet7,
        "meaNominalSet8" : meaNominalSet8,
        "meaNominalReading1" : meaNominalReading1,
        "meaNominalReading2" : meaNominalReading2,
        "meaNominalReading3" : meaNominalReading3,
        "meaNominalReading4" : meaNominalReading4,
        "meaNominalReading5" : meaNominalReading5,
        "meaNominalReading6" : meaNominalReading6,
        "meaNominalReading7" : meaNominalReading7,
        "meaNominalReading8" : meaNominalReading8,
        "meaPrecalDisplay1" : meaPrecalDisplay1,
        "meaPrecalDisplay2" : meaPrecalDisplay2,
        "meaPrecalDisplay3" : meaPrecalDisplay3,
        "meaPrecalDisplay4" : meaPrecalDisplay4,
        "meaPrecalDisplay5" : meaPrecalDisplay5,
        "meaPrecalDisplay6" : meaPrecalDisplay6,
        "meaPrecalDisplay7" : meaPrecalDisplay7,
        "meaPrecalDisplay8" : meaPrecalDisplay8,
        "meaPrecalCorrection1" : meaPrecalCorrection1,
        "meaPrecalCorrection2" : meaPrecalCorrection2,
        "meaPrecalCorrection3" : meaPrecalCorrection3,
        "meaPrecalCorrection4" : meaPrecalCorrection4,
        "meaPrecalCorrection5" : meaPrecalCorrection5,
        "meaPrecalCorrection6" : meaPrecalCorrection6,
        "meaPrecalCorrection7" : meaPrecalCorrection7,
        "meaPrecalCorrection8" : meaPrecalCorrection8,
        "meaFinalDisplay1" : meaFinalDisplay1,
        "meaFinalDisplay2" : meaFinalDisplay2,
        "meaFinalDisplay3" : meaFinalDisplay3,
        "meaFinalDisplay4" : meaFinalDisplay4,
        "meaFinalDisplay5" : meaFinalDisplay5,
        "meaFinalDisplay6" : meaFinalDisplay6,
        "meaFinalDisplay7" : meaFinalDisplay7,
        "meaFinalDisplay8" : meaFinalDisplay8,
        "meaFinalCorrection1" : meaFinalCorrection1,
        "meaFinalCorrection2" : meaFinalCorrection2,
        "meaFinalCorrection3" : meaFinalCorrection3,
        "meaFinalCorrection4" : meaFinalCorrection4,
        "meaFinalCorrection5" : meaFinalCorrection5,
        "meaFinalCorrection6" : meaFinalCorrection6,
        "meaFinalCorrection7" : meaFinalCorrection7,
        "meaFinalCorrection8" : meaFinalCorrection8,
        "meaNominalA" : meaNominalA,
        "meaNominalB" : meaNominalB,
        "meaNominalsA1" : meaNominalsA1,
        "meaNominalsA2" : meaNominalsA2,
        "meaNominalsA3" : meaNominalsA3,
        "meaNominalsB1" : meaNominalsB1,
        "meaNominalsB2" : meaNominalsB2,
        "meaNominalsB3" : meaNominalsB3,
        "meaChanged" : meaChanged,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        ]
    }
}
