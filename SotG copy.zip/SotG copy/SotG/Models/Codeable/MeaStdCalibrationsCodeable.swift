//
//  MeaStdCalibrationsCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaStdCalibrationsCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaStdCalibrations
/// meaStdCalibration:String:Key
/// meaType:String
///
    private enum CodingKeys: String, CodingKey {
        case meaStdCalibration
        case meaType
    }

    let meaStdCalibration:String
    let meaType:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaStdCalibration = try? values.decode(String.self, forKey: .meaStdCalibration)
        let meaType = GetNiceString(values:values, forKey: .meaType)

    guard
        let meaStdCalibration = rawMeaStdCalibration
     else {
         var strValues = "Error Importing Table: MeaStdCalibrations"
        strValues += "\nmeaStdCalibration = \(rawMeaStdCalibration?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaStdCalibration = meaStdCalibration
        self.meaType = meaType
    }

    var dictionaryValue: [String: Any] {
    [
        "meaStdCalibration" : meaStdCalibration,
        "meaType" : meaType,
        ]
    }
}
