//
//  MeaStdRemarksCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaStdRemarksCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaStdRemarks
/// meaRemark:String:Key
/// meaType:String:Key
///
    private enum CodingKeys: String, CodingKey {
        case meaRemark
        case meaType
    }

    let meaRemark:String
    let meaType:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaRemark = try? values.decode(String.self, forKey: .meaRemark)
        let rawMeaType = try? values.decode(String.self, forKey: .meaType)

    guard
        let meaRemark = rawMeaRemark,
        let meaType = rawMeaType
     else {
         var strValues = "Error Importing Table: MeaStdRemarks"
        strValues += "\nmeaRemark = \(rawMeaRemark?.description ?? "nil") "
        strValues += "\nmeaType = \(rawMeaType?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaRemark = meaRemark
        self.meaType = meaType
    }

    var dictionaryValue: [String: Any] {
    [
        "meaRemark" : meaRemark,
        "meaType" : meaType,
        ]
    }
}
