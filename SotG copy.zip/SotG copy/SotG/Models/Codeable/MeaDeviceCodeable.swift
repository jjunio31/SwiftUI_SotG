//
//  MeaDeviceCodeable.swift
//  SotG
//
//  Created by Administrator on 19/1/2023.
//

import Foundation


struct MeaDeviceCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaDevice
/// meaDeviceId:Int32:Key
/// meaAccount:String
/// meaReportNo:String
/// meaLastReportSubNo:Int32
/// meaType:String
/// meaPlantNo:String
/// meaOn:String
/// meaBaseType:String
/// meaBaseMake:String
/// meaBaseModel:String
/// meaBaseCapacity:String
/// meaBaseSerialNo:String
/// meaBaseNscNo:String
/// meaLoadCellSerialNos:String
/// meaInstrument:String
/// meaInstrumentMake:String
/// meaInstrumentModel:String
/// meaInstrumentCapacity1:String
/// meaInstrumentCapacity2:String
/// meaInstrumentCapacity3:String
/// meaInstrumentResolution1:String
/// meaInstrumentResolution2:String
/// meaInstrumentResolution3:String
/// meaInstrumentSerialNo:String
/// meaInstrumentRange:String
/// meaInstrumentNscNo:String
/// meaInstumentUnits:String
/// meaInstumentMaxTestWeight:Int32
/// meaCalibrationType:String
/// meaExaminedAt:String
/// meaAddress:String
/// meaNextDue:Date
/// meaLastDate:Date
/// meaRecalInterval:Int32
/// meaArchive:Bool
/// meaLoadcellMake:String
/// meaLoadcellModel:String
/// meaLoadcellNmi:String
/// meaNoOfLoadcells:Int32
/// meaInstrumentClass:String
/// meaMillivoltOutput:Float
/// meaLoadcellCapacity:String
/// meaJobCallNo:Int32
/// meaWeighbridge:Bool
///
    private enum CodingKeys: String, CodingKey {
        case meaDeviceId
        case meaAccount
        case meaReportNo
        case meaLastReportSubNo
        case meaType
        case meaPlantNo
        case meaOn
        case meaBaseType
        case meaBaseMake
        case meaBaseModel
        case meaBaseCapacity
        case meaBaseSerialNo
        case meaBaseNscNo
        case meaLoadCellSerialNos
        case meaInstrument
        case meaInstrumentMake
        case meaInstrumentModel
        case meaInstrumentCapacity1
        case meaInstrumentCapacity2
        case meaInstrumentCapacity3
        case meaInstrumentResolution1
        case meaInstrumentResolution2
        case meaInstrumentResolution3
        case meaInstrumentSerialNo
        case meaInstrumentRange
        case meaInstrumentNscNo
        case meaInstumentUnits
        case meaInstumentMaxTestWeight
        case meaCalibrationType
        case meaExaminedAt
        case meaAddress
        case meaNextDue
        case meaLastDate
        case meaRecalInterval
        case meaArchive
        case meaLoadcellMake
        case meaLoadcellModel
        case meaLoadcellNmi
        case meaNoOfLoadcells
        case meaInstrumentClass
        case meaMillivoltOutput
        case meaLoadcellCapacity
        case meaJobCallNo
        case meaWeighbridge
    }

    let meaDeviceId:Int32
    let meaAccount:String
    let meaReportNo:String
    let meaLastReportSubNo:Int32
    let meaType:String
    let meaPlantNo:String
    let meaOn:String
    let meaBaseType:String
    let meaBaseMake:String
    let meaBaseModel:String
    let meaBaseCapacity:String
    let meaBaseSerialNo:String
    let meaBaseNscNo:String
    let meaLoadCellSerialNos:String
    let meaInstrument:String
    let meaInstrumentMake:String
    let meaInstrumentModel:String
    let meaInstrumentCapacity1:String
    let meaInstrumentCapacity2:String
    let meaInstrumentCapacity3:String
    let meaInstrumentResolution1:String
    let meaInstrumentResolution2:String
    let meaInstrumentResolution3:String
    let meaInstrumentSerialNo:String
    let meaInstrumentRange:String
    let meaInstrumentNscNo:String
    let meaInstumentUnits:String
    let meaInstumentMaxTestWeight:Int32
    let meaCalibrationType:String
    let meaExaminedAt:String
    let meaAddress:String
    let meaNextDue:Date
    let meaLastDate:Date
    let meaRecalInterval:Int32
    let meaArchive:Bool
    let meaLoadcellMake:String
    let meaLoadcellModel:String
    let meaLoadcellNmi:String
    let meaNoOfLoadcells:Int32
    let meaInstrumentClass:String
    let meaMillivoltOutput:Float
    let meaLoadcellCapacity:String
    let meaJobCallNo:Int32
    let meaWeighbridge:Bool

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaAccount = try? values.decode(String.self, forKey: .meaAccount)
        let meaReportNo = GetNiceString(values:values, forKey: .meaReportNo)
        let meaLastReportSubNo = GetNiceInt32(values:values, forKey: .meaLastReportSubNo)
        let rawMeaType = try? values.decode(String.self, forKey: .meaType)
        let meaPlantNo = GetNiceString(values:values, forKey: .meaPlantNo)
        let meaOn = GetNiceString(values:values, forKey: .meaOn)
        let meaBaseType = GetNiceString(values:values, forKey: .meaBaseType)
        let meaBaseMake = GetNiceString(values:values, forKey: .meaBaseMake)
        let meaBaseModel = GetNiceString(values:values, forKey: .meaBaseModel)
        let meaBaseCapacity = GetNiceString(values:values, forKey: .meaBaseCapacity)
        let meaBaseSerialNo = GetNiceString(values:values, forKey: .meaBaseSerialNo)
        let meaBaseNscNo = GetNiceString(values:values, forKey: .meaBaseNscNo)
        let meaLoadCellSerialNos = GetNiceString(values:values, forKey: .meaLoadCellSerialNos)
        let meaInstrument = GetNiceString(values:values, forKey: .meaInstrument)
        let meaInstrumentMake = GetNiceString(values:values, forKey: .meaInstrumentMake)
        let meaInstrumentModel = GetNiceString(values:values, forKey: .meaInstrumentModel)
        let meaInstrumentCapacity1 = GetNiceString(values:values, forKey: .meaInstrumentCapacity1)
        let meaInstrumentCapacity2 = GetNiceString(values:values, forKey: .meaInstrumentCapacity2)
        let meaInstrumentCapacity3 = GetNiceString(values:values, forKey: .meaInstrumentCapacity3)
        let meaInstrumentResolution1 = GetNiceString(values:values, forKey: .meaInstrumentResolution1)
        let meaInstrumentResolution2 = GetNiceString(values:values, forKey: .meaInstrumentResolution2)
        let meaInstrumentResolution3 = GetNiceString(values:values, forKey: .meaInstrumentResolution3)
        let meaInstrumentSerialNo = GetNiceString(values:values, forKey: .meaInstrumentSerialNo)
        let meaInstrumentRange = GetNiceString(values:values, forKey: .meaInstrumentRange)
        let meaInstrumentNscNo = GetNiceString(values:values, forKey: .meaInstrumentNscNo)
        let meaInstumentUnits = GetNiceString(values:values, forKey: .meaInstumentUnits)
        let meaInstumentMaxTestWeight = GetNiceInt32(values:values, forKey: .meaInstumentMaxTestWeight)
        let meaCalibrationType = GetNiceString(values:values, forKey: .meaCalibrationType)
        let meaExaminedAt = GetNiceString(values:values, forKey: .meaExaminedAt)
        let meaAddress = GetNiceString(values:values, forKey: .meaAddress)
        let meaNextDue = GetNiceDate(dateFormat: "",values:values, forKey: .meaNextDue)
        let meaLastDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaLastDate)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaArchive = GetNiceBool(values:values, forKey: .meaArchive)
        let meaLoadcellMake = GetNiceString(values:values, forKey: .meaLoadcellMake)
        let meaLoadcellModel = GetNiceString(values:values, forKey: .meaLoadcellModel)
        let meaLoadcellNmi = GetNiceString(values:values, forKey: .meaLoadcellNmi)
        let meaNoOfLoadcells = GetNiceInt32(values:values, forKey: .meaNoOfLoadcells)
        let meaInstrumentClass = GetNiceString(values:values, forKey: .meaInstrumentClass)
        let meaMillivoltOutput = GetNiceFloat(values:values, forKey: .meaMillivoltOutput)
        let meaLoadcellCapacity = GetNiceString(values:values, forKey: .meaLoadcellCapacity)
        let meaJobCallNo = GetNiceInt32(values:values, forKey: .meaJobCallNo)
        let meaWeighbridge = GetNiceBool(values:values, forKey: .meaWeighbridge)

    guard
        let meaDeviceId = rawMeaDeviceId,
        let meaAccount = rawMeaAccount,
        let meaType = rawMeaType
     else {
         var strValues = "Error Importing Table: MeaDevice"
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        if rawMeaAccount == nil {strValues += "\nmeaAccount is nil "}
        if rawMeaType == nil {strValues += "\nmeaType is nil "}

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaDeviceId = meaDeviceId
        self.meaAccount = meaAccount
        self.meaReportNo = meaReportNo
        self.meaLastReportSubNo = meaLastReportSubNo
        self.meaType = meaType
        self.meaPlantNo = meaPlantNo
        self.meaOn = meaOn
        self.meaBaseType = meaBaseType
        self.meaBaseMake = meaBaseMake
        self.meaBaseModel = meaBaseModel
        self.meaBaseCapacity = meaBaseCapacity
        self.meaBaseSerialNo = meaBaseSerialNo
        self.meaBaseNscNo = meaBaseNscNo
        self.meaLoadCellSerialNos = meaLoadCellSerialNos
        self.meaInstrument = meaInstrument
        self.meaInstrumentMake = meaInstrumentMake
        self.meaInstrumentModel = meaInstrumentModel
        self.meaInstrumentCapacity1 = meaInstrumentCapacity1
        self.meaInstrumentCapacity2 = meaInstrumentCapacity2
        self.meaInstrumentCapacity3 = meaInstrumentCapacity3
        self.meaInstrumentResolution1 = meaInstrumentResolution1
        self.meaInstrumentResolution2 = meaInstrumentResolution2
        self.meaInstrumentResolution3 = meaInstrumentResolution3
        self.meaInstrumentSerialNo = meaInstrumentSerialNo
        self.meaInstrumentRange = meaInstrumentRange
        self.meaInstrumentNscNo = meaInstrumentNscNo
        self.meaInstumentUnits = meaInstumentUnits
        self.meaInstumentMaxTestWeight = meaInstumentMaxTestWeight
        self.meaCalibrationType = meaCalibrationType
        self.meaExaminedAt = meaExaminedAt
        self.meaAddress = meaAddress
        self.meaNextDue = meaNextDue
        self.meaLastDate = meaLastDate
        self.meaRecalInterval = meaRecalInterval
        self.meaArchive = meaArchive
        self.meaLoadcellMake = meaLoadcellMake
        self.meaLoadcellModel = meaLoadcellModel
        self.meaLoadcellNmi = meaLoadcellNmi
        self.meaNoOfLoadcells = meaNoOfLoadcells
        self.meaInstrumentClass = meaInstrumentClass
        self.meaMillivoltOutput = meaMillivoltOutput
        self.meaLoadcellCapacity = meaLoadcellCapacity
        self.meaJobCallNo = meaJobCallNo
        self.meaWeighbridge = meaWeighbridge
    }

    var dictionaryValue: [String: Any] {
    [
        "meaDeviceId" : meaDeviceId,
        "meaAccount" : meaAccount,
        "meaReportNo" : meaReportNo,
        "meaLastReportSubNo" : meaLastReportSubNo,
        "meaType" : meaType,
        "meaPlantNo" : meaPlantNo,
        "meaOn" : meaOn,
        "meaBaseType" : meaBaseType,
        "meaBaseMake" : meaBaseMake,
        "meaBaseModel" : meaBaseModel,
        "meaBaseCapacity" : meaBaseCapacity,
        "meaBaseSerialNo" : meaBaseSerialNo,
        "meaBaseNscNo" : meaBaseNscNo,
        "meaLoadCellSerialNos" : meaLoadCellSerialNos,
        "meaInstrument" : meaInstrument,
        "meaInstrumentMake" : meaInstrumentMake,
        "meaInstrumentModel" : meaInstrumentModel,
        "meaInstrumentCapacity1" : meaInstrumentCapacity1,
        "meaInstrumentCapacity2" : meaInstrumentCapacity2,
        "meaInstrumentCapacity3" : meaInstrumentCapacity3,
        "meaInstrumentResolution1" : meaInstrumentResolution1,
        "meaInstrumentResolution2" : meaInstrumentResolution2,
        "meaInstrumentResolution3" : meaInstrumentResolution3,
        "meaInstrumentSerialNo" : meaInstrumentSerialNo,
        "meaInstrumentRange" : meaInstrumentRange,
        "meaInstrumentNscNo" : meaInstrumentNscNo,
        "meaInstumentUnits" : meaInstumentUnits,
        "meaInstumentMaxTestWeight" : meaInstumentMaxTestWeight,
        "meaCalibrationType" : meaCalibrationType,
        "meaExaminedAt" : meaExaminedAt,
        "meaAddress" : meaAddress,
        "meaNextDue" : meaNextDue,
        "meaLastDate" : meaLastDate,
        "meaRecalInterval" : meaRecalInterval,
        "meaArchive" : meaArchive,
        "meaLoadcellMake" : meaLoadcellMake,
        "meaLoadcellModel" : meaLoadcellModel,
        "meaLoadcellNmi" : meaLoadcellNmi,
        "meaNoOfLoadcells" : meaNoOfLoadcells,
        "meaInstrumentClass" : meaInstrumentClass,
        "meaMillivoltOutput" : meaMillivoltOutput,
        "meaLoadcellCapacity" : meaLoadcellCapacity,
        "meaJobCallNo" : meaJobCallNo,
        "meaWeighbridge" : meaWeighbridge,
        ]
    }
}
