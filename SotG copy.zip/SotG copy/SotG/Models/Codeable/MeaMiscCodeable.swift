//
//  MeaMiscCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaMiscCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaMisc
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32:Key
/// meaReportNo:String:Key
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaTradeApproved:Bool
/// meaManditoryMarkings:Bool
/// meaLevelIndicatingDev:Bool
/// meaCleanAndServicable:Bool
/// meaAdequateProtection:Bool
/// meaNoObstructions:Bool
/// meaClearView:Bool
/// meaNoDamage:Bool
/// meaArmWorking:Bool
/// meaCalibrationMassesUsed:String
/// meaRemarks1:String
/// meaRemarks2:String
/// meaRemarks3:String
/// meaRemarks4:String
/// meaRemarks5:String
/// meaTester:String
/// meaDate:Date
/// meaTemperature:Float
/// meaRecalInterval:Int32
/// meaOperatingInTollerance:Bool
/// meaChanged:String
/// meaAuthorised:String
/// meaAuthorisedBy:String
///
    private enum CodingKeys: String, CodingKey {
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaTradeApproved
        case meaManditoryMarkings
        case meaLevelIndicatingDev
        case meaCleanAndServicable
        case meaAdequateProtection
        case meaNoObstructions
        case meaClearView
        case meaNoDamage
        case meaArmWorking
        case meaCalibrationMassesUsed
        case meaRemarks1
        case meaRemarks2
        case meaRemarks3
        case meaRemarks4
        case meaRemarks5
        case meaTester
        case meaDate
        case meaTemperature
        case meaRecalInterval
        case meaOperatingInTollerance
        case meaChanged
        case meaAuthorised
        case meaAuthorisedBy
    }

    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaTradeApproved:Bool
    let meaManditoryMarkings:Bool
    let meaLevelIndicatingDev:Bool
    let meaCleanAndServicable:Bool
    let meaAdequateProtection:Bool
    let meaNoObstructions:Bool
    let meaClearView:Bool
    let meaNoDamage:Bool
    let meaArmWorking:Bool
    let meaCalibrationMassesUsed:String
    let meaRemarks1:String
    let meaRemarks2:String
    let meaRemarks3:String
    let meaRemarks4:String
    let meaRemarks5:String
    let meaTester:String
    let meaDate:Date
    let meaTemperature:Float
    let meaRecalInterval:Int32
    let meaOperatingInTollerance:Bool
    let meaChanged:String
    let meaAuthorised:String
    let meaAuthorisedBy:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaReportNo = try? values.decode(String.self, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaTradeApproved = GetNiceBool(values:values, forKey: .meaTradeApproved)
        let meaManditoryMarkings = GetNiceBool(values:values, forKey: .meaManditoryMarkings)
        let meaLevelIndicatingDev = GetNiceBool(values:values, forKey: .meaLevelIndicatingDev)
        let meaCleanAndServicable = GetNiceBool(values:values, forKey: .meaCleanAndServicable)
        let meaAdequateProtection = GetNiceBool(values:values, forKey: .meaAdequateProtection)
        let meaNoObstructions = GetNiceBool(values:values, forKey: .meaNoObstructions)
        let meaClearView = GetNiceBool(values:values, forKey: .meaClearView)
        let meaNoDamage = GetNiceBool(values:values, forKey: .meaNoDamage)
        let meaArmWorking = GetNiceBool(values:values, forKey: .meaArmWorking)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaRemarks1 = GetNiceString(values:values, forKey: .meaRemarks1)
        let meaRemarks2 = GetNiceString(values:values, forKey: .meaRemarks2)
        let meaRemarks3 = GetNiceString(values:values, forKey: .meaRemarks3)
        let meaRemarks4 = GetNiceString(values:values, forKey: .meaRemarks4)
        let meaRemarks5 = GetNiceString(values:values, forKey: .meaRemarks5)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaTemperature = GetNiceFloat(values:values, forKey: .meaTemperature)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaOperatingInTollerance = GetNiceBool(values:values, forKey: .meaOperatingInTollerance)
        let meaChanged = GetNiceString(values:values, forKey: .meaChanged)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)

    guard
        let meaCalibrationId = rawMeaCalibrationId,
        let meaDeviceId = rawMeaDeviceId,
        let meaReportNo = rawMeaReportNo
     else {
         var strValues = "Error Importing Table: MeaMisc"
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        strValues += "\nmeaReportNo = \(rawMeaReportNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaTradeApproved = meaTradeApproved
        self.meaManditoryMarkings = meaManditoryMarkings
        self.meaLevelIndicatingDev = meaLevelIndicatingDev
        self.meaCleanAndServicable = meaCleanAndServicable
        self.meaAdequateProtection = meaAdequateProtection
        self.meaNoObstructions = meaNoObstructions
        self.meaClearView = meaClearView
        self.meaNoDamage = meaNoDamage
        self.meaArmWorking = meaArmWorking
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaRemarks1 = meaRemarks1
        self.meaRemarks2 = meaRemarks2
        self.meaRemarks3 = meaRemarks3
        self.meaRemarks4 = meaRemarks4
        self.meaRemarks5 = meaRemarks5
        self.meaTester = meaTester
        self.meaDate = meaDate
        self.meaTemperature = meaTemperature
        self.meaRecalInterval = meaRecalInterval
        self.meaOperatingInTollerance = meaOperatingInTollerance
        self.meaChanged = meaChanged
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
    }

    var dictionaryValue: [String: Any] {
    [
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaTradeApproved" : meaTradeApproved,
        "meaManditoryMarkings" : meaManditoryMarkings,
        "meaLevelIndicatingDev" : meaLevelIndicatingDev,
        "meaCleanAndServicable" : meaCleanAndServicable,
        "meaAdequateProtection" : meaAdequateProtection,
        "meaNoObstructions" : meaNoObstructions,
        "meaClearView" : meaClearView,
        "meaNoDamage" : meaNoDamage,
        "meaArmWorking" : meaArmWorking,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaRemarks1" : meaRemarks1,
        "meaRemarks2" : meaRemarks2,
        "meaRemarks3" : meaRemarks3,
        "meaRemarks4" : meaRemarks4,
        "meaRemarks5" : meaRemarks5,
        "meaTester" : meaTester,
        "meaDate" : meaDate,
        "meaTemperature" : meaTemperature,
        "meaRecalInterval" : meaRecalInterval,
        "meaOperatingInTollerance" : meaOperatingInTollerance,
        "meaChanged" : meaChanged,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        ]
    }
}
