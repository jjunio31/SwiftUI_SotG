//
//  Lib.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//

import SwiftUI
enum CallStatusEnum :String {
    case Accepted = "Accepted"
    case Rejected = "Rejected"
    case Open = "Open"
}

struct StdTxt : View {
        
    let value:String
    init(_ text:String){
        self.value = text
    }
    var body: some View {
        Text(value)
            .frame(height: 30)
            .font(.system(size:16))
        
    }
}

//jj test
struct pickerLabel : View {
        
    let val:String
    init(_ text:String){
        self.val = text
    }
    var body: some View {
        Text(val)
            .frame(width: 110, height: 30, alignment: .leading)
            .padding(.leading, 15)
            .background(Color.gray)
            .cornerRadius(5)
    }
}

    

//jj test

struct StdButton: View {
    var onPress: () -> Void
    var text:String
    var body: some View {
        
        
        Button(action: {self.onPress()} ) {
            StdTxt(text)
                .frame(width:200, height: 50)
                .background(Color.gray)
                
                .cornerRadius(10)
        }
    }
}
struct StdButtonSmall: View {
    var onPress: () -> Void
    var text:String
    var body: some View {
        
        
        Button(action: {self.onPress()} ) {
            Text(text)
                .frame(width:100)
                .background(Color.gray)
                .font(.system(size:15, weight: .bold))
                .cornerRadius(5)
        }
    }
}
/*struct TextDate: View {
    var date:Date
    let dateFormatter = DateFormatter()
    init(_ date:Date){
        dateFormatter.dateFormat = "HH:mm dd-MMM-yyyy"
        self.date = date
    }
     var body: some View {
        Text((dateFormatter.string(from: date)))
            .frame(height: 50)
            .background(Color.white)
            .font(.system(size:20, weight: .bold))
            .cornerRadius(10)
    }
}*/
struct StdDateLabel: View {
    var label:String
    
    let dateText:StdDate
    
    init(_ label:String, date:Date?,format:String){
        self.label = label
   
        self.dateText = StdDate(date, format)
    }
    init(_ label:String, date:Date?){
        self.label = label
        
        self.dateText = StdDate(date)
        
    }
    var body: some View {
        HStack {
            
            StdTxt(label)
            .frame(width: 110, alignment: .leading)
            .padding(.leading, 15)
            .background(Color.gray)
            .cornerRadius(5)
            
            dateText
                .frame(maxWidth: .infinity, alignment: .leading)
             
        }
    }
}
/*
 struct TextDateOnly: View {
     //var date:Date?
     let value:String
     
     init(_ date:Date?){
         let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "dd-MMM-yyyy"
         if let date = date {
             self.value = dateFormatter.string(from: date)
         }
         else {
             self.value = "nil date"
         }
     }
     var body: some View {
         StdTxt(value)
     }
 }
 */
struct StdDateOnly: View {
    
    let date:Date?
    let format:String = "dd-MMM-yyyy"
    init(_ date:Date?){
        self.date = date
        
    }
    
    var body: some View {
        StdDateFormatted(date,format)
    }
     
}
struct StdTimeOnly: View {
    
    let date:Date?
    let format:String = "HH:mm"
    init(_ date:Date?){
        self.date = date
        
    }
    
    var body: some View {
        StdDateFormatted(date,format)
    }
     
}
struct StdDate: View {
    
    let date:Date?
    let format:String
    init(_ date:Date?,_ format:String){
        self.date = date
        self.format = format
    }
    init(_ date:Date?){
        self.date = date
        self.format = "HH:mm dd-MMM-yyyy"
        
    }
    
    var body: some View {
        StdDateFormatted(date,format)
    }
     
}
struct StdDateFormatted: View {
    
    let value:String
    init(_ date:Date?,_ format:String){
        //var format = "HH:mm dd-MMM-yyyy"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if let date = date {
            self.value = dateFormatter.string(from: date)
        } else {
            self.value = "Nil"
        }
        
    }
   
    var body: some View {
        StdTxt(value)
    }
     
}
/*struct StdDates: View {
    //var date:Date?
    let dateFormatter = DateFormatter()
    let value:String
    init(_ date:Date?){
        dateFormatter.dateFormat = "HH:mm dd-MMM-yyyy"
        if let date = date {
            self.value = dateFormatter.string(from: date)
        } else {
            self.value = "Nil"
        }
    }
    var body: some View {
        StdTxt(value)
           
    }
}*/
struct ShowMenuImage: View {
    let menuChoice:MenuChoice
    //let call:Call? = nil
    var body: some View {
        //let m=MenuChoice(menuItem: menuItem)
        let uiimage = UIImage(named: menuChoice.getImageName())
        //UIImage(named:"currentcall")
        if let uiimage = uiimage {
            //let imageView = UIImageView(image: uiimage)
            Image(uiImage: uiimage)
                .resizable()
                .frame(width: 32.0, height: 32.0)
                
        }
        Text("\(menuChoice.menuItem.rawValue)")
    }

}

extension Binding {
    init(_ source: Binding<Value?>, _ defaultValue: Value) {
        // Ensure a non-nil value in `source`.
        if source.wrappedValue == nil {
            source.wrappedValue = defaultValue
        }
        // Unsafe unwrap because *we* know it's non-nil now.
        self.init(source)!
    }
}


// TextField("Capacity", text: Binding($device.meaBaseCapacity,""))
struct StdTextField: View {
    var label:String
    @Binding var value:String
    init(_ label:String, _ binding:Binding<String>){
        self.label = label
        self._value = binding
    }
    init(_ label:String, _ binding:Binding<String?>){
        self.label = label
        
        _value = Binding(binding,"")
        
       
    }
    var body: some View {
        
        HStack {
            
            StdTxt(label)
                .frame(width: 110, alignment: .leading)
                .padding(.leading, 15)
                .background(Color.gray)
                .cornerRadius(5)
               
            TextField(label,text: $value)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(5)
                .border(Color.gray)
                
        }
    }
}
struct StdTextLabel: View {
    var label:String
    var value:String
    init(_ label:String, i:Int32?){
        self.label = label
        self.value = "\(i ?? 0)"
    }
    init(_ label:String, i:Int32){
        self.label = label
        self.value = "\(i)"
    }
    init(_ label:String, text:String?){
        self.label = label
        self.value = text ?? ""
    }
    init(_ label:String, text:String){
        self.label = label
        self.value = text
    }
    var body: some View {
        //var stdTxtLabel = label
        //var stdTxtValue = value
        //let label_value  = "\(stdTxtLabel) :  \(stdTxtValue)"
        
        HStack {
            
            //List{
               // Text(label_value)
            //}
            
            StdTxt(label)
                .frame(width: 110, alignment: .leading)
                .padding(.leading, 15)
                .background(Color.gray)
                .cornerRadius(5)
            
            
            
            StdTxt(value)
                //.cornerRadius(10)
                //.frame(width:150, alignment: .leading)
                .frame(maxWidth: .infinity, alignment: .leading)
                //.padding()
             
            
        }
    }
}

struct StdTexts: View {
    
    var value:String
    init( i:Int32?){
       
        self.value = "\(i ?? 0)"
    }
    init( i:Int32){
        
        self.value = "\(i)"
    }
    init( text:String?){
        
        self.value = text ?? ""
    }
    init( text:String){
        
        self.value = text
    }
    var body: some View {
        
        StdTxt(value)
    }
}

/*
struct StdDescription_: View {
    
    var value:String
    init( i:Int32?){
        
        self.value = "\(i ?? 0)"
    }
    init( i:Int32){
        
        self.value = "\(i)"
    }
    init( text:String?){
        
        self.value = text ?? ""
    }
    init( text:String){
       
        self.value = text
    }
    var body: some View {
        
        
           
            Text(value)
            
                .frame(width:300, height: 30)
                //.background(Color.white)
                .font(.system(size:16))
                //.cornerRadius(10)
            
        
    }
}

struct StdDescriptions_: View {
    var value:String
    init(i:Int32?){
        self.value = "\(i ?? 0)"
    }
    init(i:Int32){
        self.value = "\(i)"
    }
    init(text:String?){
        self.value = text ?? ""
    }
    init(text:String){
        self.value = text
    }
    var body: some View {
        
        HStack {
            Text(value)
            
                .frame(width:300, height: 30)
                //.background(Color.white)
                .font(.system(size:16))
                //.cornerRadius(10)
            
        }
    }
}*/

struct Heading: View
{
    var msg:String
    var body: some View{
        Text(msg)
            .font(.largeTitle)
    }
}
struct BackgroundView: View {
    var body: some View{
        let uiimage = UIImage(named:"AWE_Image_Normal.png")
        if let uiimage = uiimage {
            //let imageView = UIImageView(image: uiimage)
            
            LinearGradient(colors: [Color.blue,Color.white], startPoint: .topLeading, endPoint: .bottomTrailing)
                .background(
                    Image(uiImage:  uiimage)
                        .resizable()
                                           // .aspectRatio(geometry.size, contentMode: .fill)
                                            .edgesIgnoringSafeArea(.all)
                )
                .edgesIgnoringSafeArea(.all)
        }
    }
}


struct StdButton_Previews: PreviewProvider {
    static var previews: some View {
        let onPress: () -> Void = {
            
        }
        StdButton(onPress: onPress, text: "Button")
    }
}


struct MenuChoice :Hashable , Equatable {
   //@Binding
    var call:Call?
   // var manualFolder:String?
    var manualFolder: ManualFolders?
    var manual:Manuals?
    var device:MeaDevice?
   var menuItem:MenuItem
    

    enum MenuItem  : String  {
        
        case login = "Login"
        case loginSu = "LoginSu"
        case showMenu = "Menu"
        case callCurrent = "Current Call"
        case callList = "Call List"
        
        case sync = "Sync"
        case manualFolders = "ManualFolders"
        case manualList = "Manual List"
        case manualDetail = "ManualDetail"
        case camera = "Camera"
        case callMenu = "Call Menu"
        case callAccept = "Accept/reject Call"
        
        case reports = "Report List"
        case callDetails = "Call Details"
        case times = "Times"
        case reportDetails = "Report Details"
        case reportEdit = "Report Edit"
        
        case notes = "Notes"
        
    }
    func getImageName() -> String{
        switch(menuItem){
        case .callCurrent:
            return "currentcall.png"
        case .callList:
            return "viewcalls.png"
        case .manualList:
            return ""
        
        case .manualFolders:
            return "manual.png"
        case .sync:
            return "sync.png"
        case .camera:
            return "Camera2.png"
        case .callDetails:
            
           return ""
        case .login:
            return ""
        case .showMenu:
            return ""
        case .loginSu:
            return ""
        case .callMenu:
            return ""
        case .reports:
            return "OneTon_Small.png"
        case .times:
            return ""
        case .notes:
            return ""
        case .callAccept:
            return ""
        case .manualDetail:
            return ""
        case .reportDetails:
            return ""
        case .reportEdit:
            return ""
        }
        
    }
    
}
