//
//  CallReportsList.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import SwiftUI
import CoreData

struct CallReportsList: View {
    @State var call:Call
    
    var body: some View {
        Text("Call Reports")
    }
}

/*struct CallReportsList_Previews: PreviewProvider {
    static var previews: some View {
        CallReportsList()
    }
}*/
