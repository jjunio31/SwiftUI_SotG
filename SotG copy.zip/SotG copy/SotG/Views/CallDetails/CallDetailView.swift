//
//  CallDetailView.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import SwiftUI
import CoreData

struct CallDetailView: View {
    @State var call:Call
    let server:String
    var authCode:String
    @Binding var error:SotgCatchError?
    @Binding var hasError :Bool
    // @Binding var refresh:UUID
    @Binding var path:[MenuChoice]
    
    @Environment(\.managedObjectContext) var managedObjectContext
    
    var body: some View {
        VStack{
            StdButton(onPress: onPress, text: "Open")
            List {
                StdTextLabel("Call No", text: call.callNo)
                StdTextLabel("Customer", text: call.shortname)
                StdTextLabel("Address", text: call.callAddress)
                StdDateLabel("Required", date: call.callDateTimeRequired)
                StdTextLabel("Accepted?", text: call.callExtraStatus)
                
            }
            
                
        }.navigationTitle("Call Detail View")
        
        
    }

 
    
    
    
    
    
    func onPress() {
        //print("****************** onPress ")
        let callNo = call.callNo
        let callExtraStatus = CallStatusEnum.Open.rawValue
        call.callExtraStatus = callExtraStatus
        do {
            try managedObjectContext.save()
            
            let parameters  = "\(callNo)|\(callExtraStatus)"
            //print("****************** onPress parameters \(parameters)")
            try ApiCalls(server: server).postRequest(api: "post-call-extra", authCode: authCode, parameters: parameters)
            
            var newPath = path
            newPath.removeLast(2)
            
            //newPath.append(MenuChoice(call: call,menuItem: .callMenu))
            path = newPath
            
        } catch {
            self.hasError = true
            let error = error as? SotgCatchError ?? .unexpectedError(error: error)
            self.error = error
           
            
            
            print(error.localizedDescription)
        }
    }
}

/*struct CallDetailView_Previews: PreviewProvider {
    static var previews: some View {
        CallDetailView()
    }
}*/
