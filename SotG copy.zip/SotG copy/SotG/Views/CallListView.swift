//
//  CallListView.swift
//  SotG
//
//  Created by Barry Hunter on 1/1/2023.
//

import SwiftUI
import CoreData

struct CallListView: View {

    @State var filterKey:String = "callNo"
    @State var filterValue:String = ""
    
    var sotgProvider: SotgProvider = .shared
    
    var body: some View {
        VStack {
           
            HStack {
                Text("Filter \(filterKey)")
                TextField("Filter", text:$filterValue)
                
            }
            Spacer()
            
            CallListFilteredView(filterKey: filterKey, filterValue: filterValue)
            
            
            
        }
        //.alert(isPresented: $hasError, error: error) { }
        .navigationTitle("Call List")
    }
    
    

}
