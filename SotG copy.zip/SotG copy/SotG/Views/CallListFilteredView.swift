//
//  CallListFilteredView.swift
//  SotG
//
//  Created by Barry Hunter on 1/1/2023.
//

import SwiftUI
import CoreData

struct CallListFilteredView: View {
    @FetchRequest var callList: FetchedResults<Call>
    
    //var filterKey:String = "callNo"
    //@State var filterValue:String = "37"
    init( filterKey:String,filterValue:String)
    {
        
        //print("CallListFilteredView  filterKey \(filterKey), filterValue \(filterValue)")
        if(filterKey.isEmpty || filterValue.isEmpty)
        {
            _callList = FetchRequest<Call>(entity: Call.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \Call.callNo,
                                                                              ascending: true)])
            
        }
        else
        {
            _callList = FetchRequest<Call>(entity: Call.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \Call.callNo,
                                                                              ascending: true)],
                                           predicate: NSPredicate(format: "%K CONTAINS %@",
                                                                  filterKey,
                                                                  filterValue)
            )
        }
    }
    
    
    
    var body: some View {
        List  {
            ForEach(callList, id:\.self) { call in
                if let call = call {
                    let _ = print("CallListFilteredView \(call.callNo) call.callExtraStatus \(call.callExtraStatus ?? "**")")
                }
                
                
                HStack {
                    
                    NavigationLink(value: MenuChoice(call: call,
                                                     menuItem: call.callExtraStatus == CallStatusEnum.Accepted.rawValue ?   .callMenu : .callAccept )){
                        
                        
                        
                        StdText(label: "No", text: call.callNo)
                        StdText(label: "acc", text: call.accountcode)
                        StdText(label: "name", text: call.shortname)
                        
                        StdText(label: "Open?", text: call.callExtraStatus)
                        
                        
                    }.background(backgroundColor(for: call.callExtraStatus ))
                }
                
                
                
                
                
                
                
            }
            //.frame(height: 50)
        }
        .environment(\.defaultMinListRowHeight, 20)
    }
    //CallStatusEnum.Open.rawValue
    private func backgroundColor(for callExtra: String?) -> Color {
        switch (callExtra) {
        case CallStatusEnum.Open.rawValue: return .orange
        case CallStatusEnum.Accepted.rawValue: return .green
        case CallStatusEnum.Rejected.rawValue: return .red
        default : return .gray
            
        }
    }
}
