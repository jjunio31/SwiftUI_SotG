//
//  ReportDetailView.swift
//  SotG
//
//  Created by Barry Hunter on 17/1/2023.
//

import SwiftUI
import CoreData

struct ReportEditView: View {
    @State var call:Call
    @ObservedObject var device:MeaDevice
    let titleBase = "Report Edit"
    @State var title:String = ""
    @State var accountcode = ""
    @State var reportNumber = ""
    @State var selection:Int32 = 0
    //@State val meaInstrumentResolution1 = ""
    //  @Environment(\.managedObjectContext) var managedObjectContext
    let managedObjectContext :NSManagedObjectContext
    
    var sotgProvider: SotgProvider = .shared
    
   
    
    
    var body: some View {
        
        VStack {
            body2
        }
        .navigationTitle(title)
        .onAppear(){
            accountcode = "\(device.meaAccount ?? "")"
            reportNumber = "\(device.meaReportNo ?? "")"
            title = "\(titleBase) \(accountcode) \(reportNumber)"
        }
        Spacer()
        
       
    }
    //var colors = ["Red", "Green", "Blue", "Tartan"]
   //@State private var selectedColor = "Red"
    var body2: some View {
        VStack {
            
            StdTextField("On",  $device.meaOn)
            //StdTextField("Base Make",  $device.meaBaseMake)
            BaseMakesPickerView($device.meaBaseMake)
            StdTextField("Type",  $device.meaType)
            StdTextField("Capacity",  $device.meaBaseCapacity)
            StdTextField("Address",  $device.meaAddress)
            //StdTextField("meaInstrumentResolution1",  $device.meaInstrumentResolution1)
            ResolutionPickerView($device.meaInstrumentResolution1)
            // StdTextField("Resolution",  )
            /*let count = resolutionList.count
             Picker(selection: $meaInstrumentResolution1,
             label: Text("Instrument Resolution")) {
             ForEach(0 ..< count) {
             Text(self.resolutionList[$0].meaResolution ?? "nil" ).tag($0)
             }
             
             }
             */
            StdButton(onPress: onSave, text: "Save")
            
            
        }
    }
    func onSave() {
        do {
            try managedObjectContext.save()
            //print("onSave \(device.meaInstrumentResolution1)")
        } catch {
            print ("Error onSave \(error.localizedDescription)")
        }
    }
}


class Settings: ObservableObject {
    
    //var didChange = PassthroughSubject<void, never="">()

    var meaInstrumentResolutionChoice: String = "" {
        willSet {
            print("Favorite Food Choice will be \(newValue)")
            //didChange.send()
            print("Favorite Food Choice: \(meaInstrumentResolutionChoice)") // never changes when I select a different food.
        }
        didSet {
            print("Favorite Food Choice was \(oldValue)")
            //didChange.send()
            print("Favorite Food Choice: \(meaInstrumentResolutionChoice)") // never changes when I select a different food.
        }
    }

}

