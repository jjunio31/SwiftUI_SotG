//
//  CallReportsList.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import SwiftUI
import CoreData

struct CallReportsList: View {
    @State var call:Call
    @State var reportFilterValue = ""
    @State var reportFIlterField = "meaReportNo"
    @State var title:String = "Call Reports"
    @State var accountcode = ""
    
    var body: some View {
        
        HStack {
            Text("Filter \(reportFIlterField)")
            TextField("Enter report number", text:$reportFilterValue)
            
        }
        
        .navigationTitle(title)
        .onAppear(){
            accountcode = "\(call.accountcode ?? "")"
            title = "Call Reports \(accountcode)"
        }
        //Spacer()
        
        ReportListFilteredView(call:call,accountcode:accountcode, filterKey: reportFIlterField, filterValue: reportFilterValue)
    }
        
}
struct ReportListFilteredView: View {
    let call:Call
    @FetchRequest var deviceList: FetchedResults<MeaDevice>
    let accountcode:String
    //var filterKey:String = "callNo"
    //@State var filterValue:String = "37"
    
    //let layout = [
        //GridItem(.adaptive(minimum: 30, maximum: 120))
    //]
    
    init( call:Call,
          accountcode:String,
          filterKey:String,
          filterValue:String)
    {
        self.call = call
        //let accountcode =
        //print("CallListFilteredView  filterKey \(filterKey), filterValue \(filterValue)")
        self.accountcode = accountcode
        let predicateAccount = NSPredicate(format: "meaAccount == %@",accountcode )
      
        if(filterKey.isEmpty || filterValue.isEmpty)
        {
            _deviceList = FetchRequest<MeaDevice>(entity: MeaDevice.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \MeaDevice.meaReportNo,
                                                                              ascending: true)],
                                                  predicate:predicateAccount)
            
        }
        else
        {
            let filter = NSPredicate(format: "%K CONTAINS %@",
                                     filterKey,
                                     filterValue)
            let andPredicate = NSCompoundPredicate(type: .and, subpredicates: [predicateAccount, filter])
            
            _deviceList = FetchRequest<MeaDevice>(entity: MeaDevice.entity(),
                                                  sortDescriptors: [NSSortDescriptor(keyPath: \MeaDevice.meaReportNo,
                                                                              ascending: true)],
                                           predicate:andPredicate
            )
        }
    }
    
    
    
    var body: some View {
        List {
            ForEach(deviceList, id:\.self) { device in
                
                
                
                HStack {
                    
                    NavigationLink(value: MenuChoice(call: call,
                                                     device: device,
                                                     menuItem:  .reportDetails)){
                        
                        StdTexts( text: device.meaAccount)
                        StdTexts( text: device.meaReportNo)
                        StdTexts( text: device.meaOn)
                        
                        
                        
                        
                    }
                }
                
                
            }
            //.frame(height: 50)
        }
        .listStyle(SidebarListStyle())
        //.environment(\.defaultMinListRowHeight, 0)
        
    }
    
/*
 var body: some View {
     
     ScrollView(.horizontal){
         LazyHGrid(rows: layout){
             ForEach(deviceList, id:\.self) { device in
                 
                 
                 
                 HStack {
                     
                     NavigationLink(value: MenuChoice(call: call,
                                                      device: device,
                                                      menuItem:  .reportDetails)){
                         
                         StdTexts( text: device.meaAccount)
                         StdTexts( text: device.meaReportNo)
                         StdTexts( text: device.meaOn)
                         
                         
                         
                         
                     }
                 }
                 
                 
                 
                 
                 
                 
                 
             }
             //.frame(height: 50)
         }
         .environment(\.defaultMinListRowHeight, 20)
     }
 }
 
 */
    
    //CallStatusEnum.Open.rawValue
    private func backgroundColor(for callExtra: String?) -> Color {
        switch (callExtra) {
        case CallStatusEnum.Open.rawValue: return .orange
        case CallStatusEnum.Accepted.rawValue: return .green
        case CallStatusEnum.Rejected.rawValue: return .red
        default : return .gray
            
        }
    }
}
/*struct CallReportsList_Previews: PreviewProvider {
    static var previews: some View {
        CallReportsList()
    }
}*/
