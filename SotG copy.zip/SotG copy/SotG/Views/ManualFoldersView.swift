//
//  ManualsView.swift
//  SotG
//
//  Created by Barry Hunter on 12/1/2023.
//

import SwiftUI

struct ManualFoldersView: View {
    
    @State var filterValue:String = ""
    
    var sotgProvider: SotgProvider = .shared
    
    var body: some View {
        VStack {
           
            HStack {
                //Text("Filter \(filterKey)")
                TextField("Filter", text:$filterValue)
                
            }
            Spacer()
            
            ManualFoldersFilteredView( filterValue: filterValue)
            
            
            
        }
        //.alert(isPresented: $hasError, error: error) { }
        .navigationTitle("Manual Folders")
    }
}

struct ManualFoldersFilteredView: View {
    @FetchRequest var manualFolders: FetchedResults<ManualFolders>
    
    
    init( filterValue:String)
    {
        let filterKey:String = "name"
        //print("CallListFilteredView  filterKey \(filterKey), filterValue \(filterValue)")
        if(filterKey.isEmpty || filterValue.isEmpty)
        {
            _manualFolders = FetchRequest<ManualFolders>(entity: ManualFolders.entity(),
                                                    sortDescriptors: [NSSortDescriptor(keyPath: \ManualFolders.name,
                                                                              ascending: true)])
            
        }
        else
        {
            _manualFolders = FetchRequest<ManualFolders>(entity: ManualFolders.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \ManualFolders.name,
                                                                              ascending: true)],
                                           predicate: NSPredicate(format: "%K CONTAINS %@",
                                                                  filterKey,
                                                                  filterValue)
            )
        }
    }
    
    
    
    var body: some View {
        List  {
            ForEach(manualFolders, id:\.self) { manualFolder in
               // if let manualFolder = manualFolder {
                    //let _ = print("CallListFilteredView \(manualFolder.name) call.callExtraStatus \(call.callExtraStatus ?? "**")")
                //}
                
                
                HStack {
                    //let name = "name
                    if let manualFolder = manualFolder {
                        NavigationLink(value: MenuChoice(manualFolder: manualFolder, menuItem: .manualList))
                        {
                            
                            
                            
                            StdText(label: "name", text: manualFolder.name)
                            StdText(label: "count", i: manualFolder.count)
                            
                        }
                    }
                        
                    
                }
                
                
                
                
                
                
                
            }
            //.frame(height: 50)
        }
        //.environment(\.defaultMinListRowHeight, 20)
    }
   
}

/*struct ManualsView_Previews: PreviewProvider {
 static var previews: some View {
 // ManualsView()
 }
 }
 */
