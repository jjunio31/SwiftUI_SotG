//
//  MenuView.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//

import SwiftUI

let mainMenuMenuList : [MenuChoice.MenuItem] = [ .sync,
                                                .callCurrent,
                                                .callList,
                                                .manualFolders,
                                                .camera ]

struct MenuView: View {
    @Binding var authCode:String
    @AppStorage("engineerName")
    private var engineerName: String = ""
    
    @Binding var path:[MenuChoice]
    
    var body: some View {
        VStack {
            List {
                ForEach(mainMenuMenuList, id:\.self) { menuItem in
                    let menuChoice = MenuChoice(menuItem: menuItem)
                    NavigationLink(value: menuChoice){
                        //
                        HStack {
                            ShowMenuImage(menuChoice: menuChoice)
                            
                        }
                    }
                }
            }
            
            
            StdButton(onPress:  self.onLogoutButton , text: "Logout" )
            
        }
        .navigationTitle("Main Menu")
        .navigationBarBackButtonHidden(true)
    }
    func onLogoutButton() {
        //print("onLogoutButton path.count \(path.count)")
        authCode = ""
        engineerName = ""
        if(path.count>0)
        {
            path.removeLast()
            
        }
        else
        {
            print("onLogout path \(path.count)")
        }
    }
}


