//
//  LoginView.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//

import SwiftUI

struct LoginView: View {
    //var onLogin: (_:String, _ :String) async -> Bool
    var sotgProvider: SotgProvider = .shared
    @Binding var server:String
    @Binding var engineerCode:String
    @Binding var engineerName:String
    @Binding var engineerSuCode:String
    
    @Binding var authCode:String
    @Binding var path: [MenuChoice]
    //@Binding var path:NavigationPath
    @State var error:SotgCatchError?
    @State var hasError:Bool = false
    @State var password = ""
    @State var loginMessage = ""
    @State var loginError = false
    
    var body: some View {
        
        VStack {
           
            StdButtonSmall(onPress:  self.onLoginSuButton , text: "Login Super User" )
            Spacer()
            HStack {
                Text("User name")
                // TextField("type here", text: $username)
                //Text(newOne.strId)
                //UITextField("User", text: $setting.engineerCode)
                //TextField("User", text: Binding($engineerCode,  "Engineer"))
                TextField("User", text: $engineerCode)
                // SOTest(text: setting.engineerCode)
                
            }.padding()
            
            
            HStack {
                Text("Password")
                SecureField("type password here", text: $password)
                    .textContentType(.password)
            }.padding()
            if loginError {
                
                Text("\(loginMessage)")
                
                    .padding()
            }
            
            StdButton(onPress:  self.onLoginButton , text: "Login" )
            Spacer()
        }
        //.navigationTitle("Login")
        .navigationBarBackButtonHidden(true)
        .alert(isPresented: $hasError, error: error) { }
        .onAppear() {
            engineerSuCode = ""
        }
    }
        
        
        
    func onLoginSuButton() {
        path.append(MenuChoice(menuItem: .loginSu))
    }
    func onLoginButton()  {
        
        Task {
            if await sotgLogin(engineerCode: engineerCode, password: password) {
                //engineerCode: engineerCode, password: password) {
                
                //if (path.count > 0){
                 //   path.removeLast()
               // }
                
                //popToRootViewController(animated: true)
                //self.presentation.wrappedValue.dismiss()
            }
        }
        
        
    }
    private func sotgLogin(engineerCode:String, password:String) async -> Bool {
        //print("sotgLogin path.count \(path.count)")
        //isLoading = true
              
        var ret = false
        do {
            let (aCode,aEngineerName) = try await ApiCalls(server: server).login(engineerCode: engineerCode, password: password)
                authCode = aCode
                engineerName = aEngineerName
                path.append(MenuChoice(menuItem: .showMenu))
                ret = true
            
            //lastUpdated = Date().timeIntervalSince1970
        } catch {
            print("Error found")
            self.error = error as? SotgCatchError ?? .unexpectedError(error: error)
            self.hasError = true
        }
       // print ("Path Count: \(path.count)")
       // isLoading = false
        return ret
    }
}



