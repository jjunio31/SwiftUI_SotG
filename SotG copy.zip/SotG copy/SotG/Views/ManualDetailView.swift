//
//  ManualsView.swift
//  SotG
//
//  Created by Barry Hunter on 12/1/2023.
//

import SwiftUI

struct ManualDetailView: View {
    let manual:Manuals
    let server:String
    let authCode:String
    @State var image : UIImage? = nil
    @State var progress:String = ""
    var body: some View {
        Text("Manuals")
        Text("Folder \(manual.folder ?? "**")")
        Text("FileName \(manual.fileName ?? "**")")
       
        Text("\(progress)")
        let _ = print("Draw View \(progress)")
        if let uiimage = image {
            let _ = print("Set Image in View")
            Image(uiImage: uiimage)
                .resizable()
                .frame(width: 32.0, height: 32.0)
                .foregroundColor(.accentColor)
        }
        ButtonStd(onPress: onPress, text: "Download")
    }
    func onPress() {
        if let folder = manual.folder {
            if let fileName = manual.fileName {
                let sUrl = "\(server)/api/get_manual?AuthCode=\(authCode)8&folder=\(folder)&file=\(fileName)"
                print ("sUrl \(sUrl)")
                savePdf(urlString: sUrl, fileName: fileName)
            }
        }
    }
    func onPressOld() {
        progress = "OnPress"
        if let folder = manual.folder {
            if let fileName = manual.fileName {
                let sUrl = "\(server)/api/get_manual?AuthCode=\(authCode)8&folder=\(folder)&file=\(fileName)"
                print ("sUrl \(sUrl)")
                if let url = URL(string: sUrl) {
                    progress = "URL Ok"
                    let task = URLSession.shared.dataTask(with: url) { data, response, error in
                        progress = "Task"
                        if let error = error {
                            progress = error.localizedDescription
                            print ("\(error.localizedDescription)")
                            return
                        }
                        guard let data = data else { return }
                        
                        DispatchQueue.main.async { /// execute on main thread
                            //image = UIImage(named: "AWE_Logo.png")
                            
                            image = UIImage(data: data)
                            progress = "Set Image"
                        }
                    }
                    
                    task.resume()
                }
            }
        } else {
            progress = "missing folder"
        }
    }
    
    func savePdf(urlString:String, fileName:String) {
            DispatchQueue.main.async {
                let url = URL(string: urlString)
                let pdfData = try? Data.init(contentsOf: url!)
                let resourceDocPath = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
                let pdfNameFromUrl = "YourAppName-\(fileName).pdf"
                let actualPath = resourceDocPath.appendingPathComponent(pdfNameFromUrl)
                do {
                    try pdfData?.write(to: actualPath, options: .atomic)
                    print("pdf successfully saved!")
                } catch {
                    print("Pdf could not be saved")
                }
            }
        }

        func showSavedPdf(url:String, fileName:String) {
            if #available(iOS 10.0, *) {
                do {
                    let docURL = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                    let contents = try FileManager.default.contentsOfDirectory(at: docURL, includingPropertiesForKeys: [.fileResourceTypeKey], options: .skipsHiddenFiles)
                    for url in contents {
                        if url.description.contains("\(fileName).pdf") {
                           // its your file! do what you want with it!

                    }
                }
            } catch {
                print("could not locate pdf file !!!!!!!")
            }
        }
    }

    // check to avoid saving a file multiple times
    func pdfFileAlreadySaved(url:String, fileName:String)-> Bool {
        var status = false
        if #available(iOS 10.0, *) {
            do {
                let docURL = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                let contents = try FileManager.default.contentsOfDirectory(at: docURL, includingPropertiesForKeys: [.fileResourceTypeKey], options: .skipsHiddenFiles)
                for url in contents {
                    if url.description.contains("YourAppName-\(fileName).pdf") {
                        status = true
                    }
                }
            } catch {
                print("could not locate pdf file !!!!!!!")
            }
        }
        return status
    }
}

/*struct ManualsView_Previews: PreviewProvider {
 static var previews: some View {
 // ManualsView()
 }
 }
 */
