//
//  ContentView.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//

import SwiftUI

struct ContentView: View {
    var sotgProvider: SotgProvider = .shared
    @Environment(\.managedObjectContext) var managedObjectContext
    
    @AppStorage("engineerCode")
    private var engineerCode: String = ""
    @AppStorage("engineerName")
    private var engineerName: String = ""
    @AppStorage("engineerSuCode")
    private var engineerSuCode: String = ""
    @AppStorage("engineerSuName")
    private var engineerSuName: String = ""
    @AppStorage("authCode")
    private var authCode: String = ""
    @AppStorage("lastUpdated")
    private var lastUpdated = Date.distantFuture.timeIntervalSince1970
    
    @AppStorage("server")
    private var server = "http://sotg.awe.com.au:18091"
    
    @State private
    var error: SotgCatchError?
    //SotgCatchError?
    
    @State private
    var hasError = false
    
    @State private
    var isLoading = false
    
    @State private
    var callExtraStatus = ""
    
    
    
   
   
    
    @State
    var path = [MenuChoice(menuItem: .login)]
    
    var body: some View {
        //let _ = print("top path.count \(path.count) authCode \(authCode)")
        VStack {
            HStack {
                let uiimage = UIImage(named: "AWE_Logo.png")
                if let uiimage = uiimage {
                    
                    Image(uiImage: uiimage)
                        .resizable()
                        .frame(width: 32.0, height: 32.0)
                        .foregroundColor(.accentColor)
                }
                
                Text("Service on the GO!")
            }
            let su = engineerSuCode.isEmpty ? "" : "(\(engineerSuCode))"
            
            Text("\(engineerCode) \(engineerName) \(su)")
            
            NavigationStack(path: $path) {
                
                Text("OK")
                
                    .navigationTitle("Service on the Go")
                
                    .navigationDestination(for: MenuChoice.self){ menu in
                        switch(menu.menuItem) {
                            
                            
                            
                        case  .manualFolders :
                            ManualFoldersView()
                        
                        case .manualList:
                            
                            if let manualFolder = menu.manualFolder {
                                
                                ManualsListView(manualFolder: manualFolder)
                            }
                        case  .manualDetail :
                            if let manual = menu.manual {
                                
                                ManualDetailView(
                                    manual: manual,
                                    server: server,
                                    authCode: authCode
                                )
                            }
                            // let manual = menu.manual {
                            //     ManualDetailView(manual:manual)
                            // }
                        case .callList :
                            CallListView()
                            
                        case  .sync :
                            SyncView(server:server, authCode: authCode,error: $error,hasError: $hasError)
                            
                        case .camera:
                            Text("CameraView()")
                            
                            
                        case .login:
                            LoginView( server:$server,
                                       engineerCode: $engineerCode,
                                       engineerName:$engineerName ,
                                       engineerSuCode: $engineerSuCode,
                                       authCode: $authCode,
                                       
                                       path:$path)
                        case .showMenu:
                            MenuView(authCode: $authCode,
                                     //engineerName: $engineerName,
                                     path: $path)
                        case .loginSu:
                            LoginSuView(server:server,
                                        engineerCode: $engineerCode,
                                        engineerName: $engineerName,
                                        engineerSuCode: $engineerSuCode,
                                        authCode: $authCode,
                                        path: $path)
                        case .callCurrent:
                            CurrentCallView()
                            
                            
                        case .reports:
                            if let call = menu.call {
                                CallReportsList(call: call)
                            }
                        case .callAccept:
                            
                            if let call = menu.call   {
                                CallDetailAskToAccept(call: call,
                                                      server:server,
                                                      authCode: authCode,
                                                      error: $error,hasError: $hasError,
                                                      path: $path)
                            }
                        case .callDetails:
                            
                            if let call = menu.call   {
                                CallDetailView(call: call,
                                               server:server,
                                               
                                               authCode: authCode,
                                               error: $error,hasError: $hasError,
                                               path: $path)
                            }
                            
                        case .callMenu:
                            if let call = menu.call  {
                                CallMenuView(call: call)
                                //,authCode: authCode, error: $error,hasError: $hasError)
                                
                            }
                            
                            
                        case .times:
                            if let call = menu.call {
                                CallTimesView(call: call)
                            }
                        case .notes:
                            if let call = menu.call {
                                CallNotesView(call: call)
                            }
                          
                     
                            
                            
                        case .reportDetails:
                           
                            if let call = menu.call {
                                if let device = menu.device {
                                    ReportDetailView(call: call, device: device)
                                    //, managedObjectContext: managedObjectContext)
                                }
                             }
                        
                        case .reportEdit:
                            if let call = menu.call {
                                if let device = menu.device {
                                    ReportEditView(call: call,
                                                   device: device,
                                                   managedObjectContext: managedObjectContext)
                                }
                               
                            }
                        }
                    }
            
            }
            
            .padding()
            
            
            
            
            
        }
        .onAppear() {
            if !authCode.isEmpty {
                print("authCode \(authCode)")
                path.append(MenuChoice(menuItem: .showMenu))
            }
        }
        .alert(isPresented: $hasError) { () -> Alert in
            // rawCallNo?.description ?? "nil"
            Alert(title: Text("Error"),
                  message: Text("\(error?.localizedDescription ?? "nil")"),
                  primaryButton: .default(Text("Okay"),
                                          action: {
                                            print("Okay Click")
                                        }),
                  secondaryButton: .default(Text("")))
            
        }
        /*.alert(title: "title",
               message: "message",
               primaryButton: CustomAlertButton,
               isPresented: $hasError) {
            
        }*/
        //.alert(isPresented: $hasError, error: error) {
          //  if let error = error {
            //    let _ = print("error is //\(error.localizedDescription)")
            //}
        //}
        
            
        
    }
    
}

struct CustomAlertButton: View {

    // MARK: - Value
    // MARK: Public
    let title: LocalizedStringKey
    var action: (() -> Void)? = nil
    
    
    // MARK: - View
    // MARK: Public
    var body: some View {
        Button {
          action?()
        
        } label: {
            Text(title)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white)
                .padding(.horizontal, 10)
        }
        .frame(height: 30)
        .background(Color.purple)
        .cornerRadius(15)
    }
}
// MARK: Core Data

 
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}










