//
//  SothError.swift
//  SotG
//
//  Created by Barry Hunter on 31/12/2022.
//

import Foundation

enum SotgCatchError: Error {
    case wrongDataFormat(error: Error)
    case missingData(data:String)
    case invalidAuthCode(data:String)
    case creationError
    case batchInsertError
    case batchDeleteError
    case persistentHistoryChangeError
    case loginFail(msg:String)
    case httpPostFail(msg:String)
    case urlError(msg:String,url:String)
    case unexpectedError(error: Error)
}

extension SotgCatchError: LocalizedError , Identifiable{
    var errorDescription: String? {
        switch self {
        case .wrongDataFormat(let error):
            return NSLocalizedString("Could not digest the fetched data. \(error.localizedDescription)", comment: "")
        case .missingData(let data):
            return NSLocalizedString("Error in Data \(data)", comment: "")
        case .creationError:
            return NSLocalizedString("Failed to create a new Quake object.", comment: "")
        case .batchInsertError:
            return NSLocalizedString("Failed to execute a batch insert request.", comment: "")
        case .batchDeleteError:
            return NSLocalizedString("Failed to execute a batch delete request.", comment: "")
        case .persistentHistoryChangeError:
            return NSLocalizedString("Failed to execute a persistent history change request.", comment: "")
        case .loginFail(let msg):
            //print("Login Failed")
            return NSLocalizedString("Received Login Error. \(msg)", comment: "")
        case .urlError(let msg, let url):
            return NSLocalizedString("Received http error. \(msg) \(url) ", comment: "")
        case .unexpectedError(let error):
            return NSLocalizedString("Received unexpected error. \(error.localizedDescription)", comment: "")
        case .invalidAuthCode(data: let data):
            return NSLocalizedString("Invalid AuthCode. \(data)", comment: "")
        case .httpPostFail(msg: let msg):
            return NSLocalizedString("Http Post error. \(msg)", comment: "")
      
        }
    }
}

extension SotgCatchError {
    var id: String? {
        errorDescription
    }
}
