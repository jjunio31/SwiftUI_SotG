//
//  CallNoteCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct CallNoteCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:CallNote
/// callNo:Int32:Key
/// noteType:String:Key
/// transNo:Int32:Key
/// sequenceNo:Int32:Key
/// notes:String
/// date:Date
/// engCode:String
/// engName:String
///
    private enum CodingKeys: String, CodingKey {
        case callNo
        case noteType
        case transNo
        case sequenceNo
        case notes
        case date
        case engCode
        case engName
    }

    let callNo:Int32
    let noteType:String
    let transNo:Int32
    let sequenceNo:Int32
    let notes:String
    let date:Date
    let engCode:String
    let engName:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        let rawCallNo = try? values.decode(Int32.self, forKey: .callNo)
        let rawNoteType = try? values.decode(String.self, forKey: .noteType)
        let rawTransNo = try? values.decode(Int32.self, forKey: .transNo)
        let rawSequenceNo = try? values.decode(Int32.self, forKey: .sequenceNo)
        let rawNotes = try? values.decode(String.self, forKey: .notes)
        let rawDate = try? values.decode(Date.self, forKey: .date)
        let rawEngCode = try? values.decode(String.self, forKey: .engCode)
        let rawEngName = try? values.decode(String.self, forKey: .engName)

    guard
        let callNo = rawCallNo,
        let noteType = rawNoteType,
        let transNo = rawTransNo,
        let sequenceNo = rawSequenceNo,
        let notes = rawNotes,
        let date = rawDate,
        let engCode = rawEngCode,
        let engName = rawEngName
     else {
         var strValues = "Error Importing Table: CallNote"
        strValues += "\ncallNo = \(rawCallNo?.description ?? "nil") "
        strValues += "\nnoteType = \(rawNoteType?.description ?? "nil") "
        strValues += "\ntransNo = \(rawTransNo?.description ?? "nil") "
        strValues += "\nsequenceNo = \(rawSequenceNo?.description ?? "nil") "
        if rawNotes == nil {strValues += "\nnotes is nil "}
        if rawDate == nil {
            strValues += "\nError in date:"}
            let s = try? values.decode(String.self, forKey: .date)
            if let s = s {
                strValues += s
            }
        if rawEngCode == nil {strValues += "\nengCode is nil "}
        if rawEngName == nil {strValues += "\nengName is nil "}

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.callNo = callNo
        self.noteType = noteType
        self.transNo = transNo
        self.sequenceNo = sequenceNo
        self.notes = notes
        self.date = date
        self.engCode = engCode
        self.engName = engName
    }

    var dictionaryValue: [String: Any] {
    [
        "callNo" : callNo,
        "noteType" : noteType,
        "transNo" : transNo,
        "sequenceNo" : sequenceNo,
        "notes" : notes,
        "date" : date,
        "engCode" : engCode,
        "engName" : engName,
        ]
    }
}
