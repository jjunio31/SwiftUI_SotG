//
//  MeaResolutionsCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaResolutionsCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaResoutions
/// meaDisplayOrder:Int32:Key
/// meaResolution:String:Key
///
    private enum CodingKeys: String, CodingKey {
        case meaDisplayOrder
        case meaResolution
    }

    let meaDisplayOrder:Int32
    let meaResolution:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaDisplayOrder = try? values.decode(Int32.self, forKey: .meaDisplayOrder)
        let rawMeaResolution = try? values.decode(String.self, forKey: .meaResolution)

    guard
        let meaDisplayOrder = rawMeaDisplayOrder,
        let meaResolution = rawMeaResolution
     else {
         var strValues = "Error Importing Table: MeaResoutions"
        strValues += "\nmeaDisplayOrder = \(rawMeaDisplayOrder?.description ?? "nil") "
        strValues += "\nmeaResolution = \(rawMeaResolution?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaDisplayOrder = meaDisplayOrder
        self.meaResolution = meaResolution
    }

    var dictionaryValue: [String: Any] {
    [
        "meaDisplayOrder" : meaDisplayOrder,
        "meaResolution" : meaResolution,
        ]
    }
}
