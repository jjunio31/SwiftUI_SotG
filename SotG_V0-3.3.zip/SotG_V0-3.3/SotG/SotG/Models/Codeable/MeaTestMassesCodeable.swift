//
//  MeaTestMassesCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaTestMassesCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaTestMasses
/// meaTmGuid:String:Key
/// bfDeviceId:String:Key
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32:Key
/// meaReportNo:String:Key
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaDate:Date
/// meaCalibrationMassesUsed:String
/// meaTester:String
/// meaTempInt:Int32
/// meaEngCode:String
/// meaRecalInterval:Int32
/// meaAuthorised:String
/// meaAuthorisedBy:String
///
    private enum CodingKeys: String, CodingKey {
        case meaTmGuid
        case bfDeviceId
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaDate
        case meaCalibrationMassesUsed
        case meaTester
        case meaTempInt
        case meaEngCode
        case meaRecalInterval
        case meaAuthorised
        case meaAuthorisedBy
    }

    let meaTmGuid:String
    let bfDeviceId:String
    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaDate:Date
    let meaCalibrationMassesUsed:String
    let meaTester:String
    let meaTempInt:Int32
    let meaEngCode:String
    let meaRecalInterval:Int32
    let meaAuthorised:String
    let meaAuthorisedBy:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaTmGuid = try? values.decode(String.self, forKey: .meaTmGuid)
        let rawBfDeviceId = try? values.decode(String.self, forKey: .bfDeviceId)
        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaReportNo = try? values.decode(String.self, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaTempInt = GetNiceInt32(values:values, forKey: .meaTempInt)
        let meaEngCode = GetNiceString(values:values, forKey: .meaEngCode)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)

    guard
        let meaTmGuid = rawMeaTmGuid,
        let bfDeviceId = rawBfDeviceId,
        let meaCalibrationId = rawMeaCalibrationId,
        let meaDeviceId = rawMeaDeviceId,
        let meaReportNo = rawMeaReportNo
     else {
         var strValues = "Error Importing Table: MeaTestMasses"
        strValues += "\nmeaTmGuid = \(rawMeaTmGuid?.description ?? "nil") "
        strValues += "\nbfDeviceId = \(rawBfDeviceId?.description ?? "nil") "
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        strValues += "\nmeaReportNo = \(rawMeaReportNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaTmGuid = meaTmGuid
        self.bfDeviceId = bfDeviceId
        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaDate = meaDate
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaTester = meaTester
        self.meaTempInt = meaTempInt
        self.meaEngCode = meaEngCode
        self.meaRecalInterval = meaRecalInterval
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
    }

    var dictionaryValue: [String: Any] {
    [
        "meaTmGuid" : meaTmGuid,
        "bfDeviceId" : bfDeviceId,
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaDate" : meaDate,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaTester" : meaTester,
        "meaTempInt" : meaTempInt,
        "meaEngCode" : meaEngCode,
        "meaRecalInterval" : meaRecalInterval,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        ]
    }
}
