//
//  CallTimesCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct CallTimesCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:CallTimes
/// callNo:Int32:Key
/// engCode:String:Key
/// periodType:String:Key
/// startTime:Date
/// stopTime:Date
///
    private enum CodingKeys: String, CodingKey {
        case callNo
        case engCode
        case periodType
        case startTime
        case stopTime
    }

    let callNo:Int32
    let engCode:String
    let periodType:String
    let startTime:Date
    let stopTime:Date

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        let rawCallNo = try? values.decode(Int32.self, forKey: .callNo)
        let rawEngCode = try? values.decode(String.self, forKey: .engCode)
        let rawPeriodType = try? values.decode(String.self, forKey: .periodType)
        let rawStartTime = try? values.decode(Date.self, forKey: .startTime)
        let rawStopTime = try? values.decode(Date.self, forKey: .stopTime)

    guard
        let callNo = rawCallNo,
        let engCode = rawEngCode,
        let periodType = rawPeriodType,
        let startTime = rawStartTime,
        let stopTime = rawStopTime
     else {
         var strValues = "Error Importing Table: CallTimes"
        strValues += "\ncallNo = \(rawCallNo?.description ?? "nil") "
        strValues += "\nengCode = \(rawEngCode?.description ?? "nil") "
        strValues += "\nperiodType = \(rawPeriodType?.description ?? "nil") "
        if rawStartTime == nil {
            strValues += "\nError in startTime:"}
            let s0 = try? values.decode(String.self, forKey: .startTime)
            if let s0 = s0 {
                strValues += s0
            }
        if rawStopTime == nil {
            strValues += "\nError in stopTime:"}
            let s1 = try? values.decode(String.self, forKey: .stopTime)
            if let s1 = s1 {
                strValues += s1
            }

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.callNo = callNo
        self.engCode = engCode
        self.periodType = periodType
        self.startTime = startTime
        self.stopTime = stopTime
    }

    var dictionaryValue: [String: Any] {
    [
        "callNo" : callNo,
        "engCode" : engCode,
        "periodType" : periodType,
        "startTime" : startTime,
        "stopTime" : stopTime,
        ]
    }
}
