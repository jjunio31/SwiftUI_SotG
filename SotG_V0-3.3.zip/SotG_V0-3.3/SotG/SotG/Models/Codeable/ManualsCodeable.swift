//
//  ManualsCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct ManualsCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:Manuals
/// name:String:Key
/// fileName:String
/// folder:String
///
    private enum CodingKeys: String, CodingKey {
        case name
        case fileName
        case folder
    }

    let name:String
    let fileName:String
    let folder:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        let rawName = try? values.decode(String.self, forKey: .name)
        let rawFileName = try? values.decode(String.self, forKey: .fileName)
        let rawFolder = try? values.decode(String.self, forKey: .folder)

    guard
        let name = rawName,
        let fileName = rawFileName,
        let folder = rawFolder
     else {
         var strValues = "Error Importing Table: Manuals"
        strValues += "\nname = \(rawName?.description ?? "nil") "
        if rawFileName == nil {strValues += "\nfileName is nil "}
        if rawFolder == nil {strValues += "\nfolder is nil "}

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.name = name
        self.fileName = fileName
        self.folder = folder
    }

    var dictionaryValue: [String: Any] {
    [
        "name" : name,
        "fileName" : fileName,
        "folder" : folder,
        ]
    }
}
