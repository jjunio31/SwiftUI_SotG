//
//  WeighbridgeCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct WeighbridgeCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:Weighbridge
/// meaDeviceId:Int32:Key
/// meaReportNo:String:Key
/// meaReportSubNumber:Int32
/// meaDate:Date
/// meaEngNo:String
/// millivolt1:Float
/// millivolt2:Float
/// millivolt3:Float
/// millivolt4:Float
/// millivolt5:Float
/// millivolt6:Float
/// millivolt7:Float
/// millivolt8:Float
/// millivolt9:Float
/// millivolt10:Float
/// millivolt11:Float
/// millivolt12:Float
/// customer:String
/// noOfLoadcells:Int32
///
    private enum CodingKeys: String, CodingKey {
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaDate
        case meaEngNo
        case millivolt1
        case millivolt2
        case millivolt3
        case millivolt4
        case millivolt5
        case millivolt6
        case millivolt7
        case millivolt8
        case millivolt9
        case millivolt10
        case millivolt11
        case millivolt12
        case customer
        case noOfLoadcells
    }

    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaDate:Date
    let meaEngNo:String
    let millivolt1:Float
    let millivolt2:Float
    let millivolt3:Float
    let millivolt4:Float
    let millivolt5:Float
    let millivolt6:Float
    let millivolt7:Float
    let millivolt8:Float
    let millivolt9:Float
    let millivolt10:Float
    let millivolt11:Float
    let millivolt12:Float
    let customer:String
    let noOfLoadcells:Int32

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaReportNo = try? values.decode(String.self, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaEngNo = GetNiceString(values:values, forKey: .meaEngNo)
        let millivolt1 = GetNiceFloat(values:values, forKey: .millivolt1)
        let millivolt2 = GetNiceFloat(values:values, forKey: .millivolt2)
        let millivolt3 = GetNiceFloat(values:values, forKey: .millivolt3)
        let millivolt4 = GetNiceFloat(values:values, forKey: .millivolt4)
        let millivolt5 = GetNiceFloat(values:values, forKey: .millivolt5)
        let millivolt6 = GetNiceFloat(values:values, forKey: .millivolt6)
        let millivolt7 = GetNiceFloat(values:values, forKey: .millivolt7)
        let millivolt8 = GetNiceFloat(values:values, forKey: .millivolt8)
        let millivolt9 = GetNiceFloat(values:values, forKey: .millivolt9)
        let millivolt10 = GetNiceFloat(values:values, forKey: .millivolt10)
        let millivolt11 = GetNiceFloat(values:values, forKey: .millivolt11)
        let millivolt12 = GetNiceFloat(values:values, forKey: .millivolt12)
        let customer = GetNiceString(values:values, forKey: .customer)
        let noOfLoadcells = GetNiceInt32(values:values, forKey: .noOfLoadcells)

    guard
        let meaDeviceId = rawMeaDeviceId,
        let meaReportNo = rawMeaReportNo
     else {
         var strValues = "Error Importing Table: Weighbridge"
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        strValues += "\nmeaReportNo = \(rawMeaReportNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaDate = meaDate
        self.meaEngNo = meaEngNo
        self.millivolt1 = millivolt1
        self.millivolt2 = millivolt2
        self.millivolt3 = millivolt3
        self.millivolt4 = millivolt4
        self.millivolt5 = millivolt5
        self.millivolt6 = millivolt6
        self.millivolt7 = millivolt7
        self.millivolt8 = millivolt8
        self.millivolt9 = millivolt9
        self.millivolt10 = millivolt10
        self.millivolt11 = millivolt11
        self.millivolt12 = millivolt12
        self.customer = customer
        self.noOfLoadcells = noOfLoadcells
    }

    var dictionaryValue: [String: Any] {
    [
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaDate" : meaDate,
        "meaEngNo" : meaEngNo,
        "millivolt1" : millivolt1,
        "millivolt2" : millivolt2,
        "millivolt3" : millivolt3,
        "millivolt4" : millivolt4,
        "millivolt5" : millivolt5,
        "millivolt6" : millivolt6,
        "millivolt7" : millivolt7,
        "millivolt8" : millivolt8,
        "millivolt9" : millivolt9,
        "millivolt10" : millivolt10,
        "millivolt11" : millivolt11,
        "millivolt12" : millivolt12,
        "customer" : customer,
        "noOfLoadcells" : noOfLoadcells,
        ]
    }
}
