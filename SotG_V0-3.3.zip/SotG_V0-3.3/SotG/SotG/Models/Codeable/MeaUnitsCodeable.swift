//
//  MeaUnitsCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaUnitsCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaUnits
/// meaUnit:String:Key
///
    private enum CodingKeys: String, CodingKey {
        case meaUnit
    }

    let meaUnit:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaUnit = try? values.decode(String.self, forKey: .meaUnit)

    guard
        let meaUnit = rawMeaUnit
     else {
         var strValues = "Error Importing Table: MeaUnits"
        strValues += "\nmeaUnit = \(rawMeaUnit?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaUnit = meaUnit
    }

    var dictionaryValue: [String: Any] {
    [
        "meaUnit" : meaUnit,
        ]
    }
}
