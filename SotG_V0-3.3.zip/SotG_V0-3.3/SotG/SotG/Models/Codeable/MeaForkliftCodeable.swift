//
//  MeaForkliftCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaForkliftCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaForklift
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32
/// meaReportNo:String
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaMassA:String
/// meaMassAReading51:String
/// meaMassAReading52:String
/// meaMassAReading53:String
/// meaMassAReading54:String
/// meaMassAReading55:String
/// meaMassB:String
/// meaMassBReading51:String
/// meaMassBReading52:String
/// meaMassBReading53:String
/// meaMassBReading54:String
/// meaMassBReading55:String
/// meaMassC:String
/// meaMassCReading51:String
/// meaMassCReading52:String
/// meaMassCReading53:String
/// meaMassCReading54:String
/// meaMassCReading55:String
/// meaMassD:String
/// meaMassDReading51:String
/// meaMassDReading52:String
/// meaMassDReading53:String
/// meaMassDReading54:String
/// meaMassDReading55:String
/// meaCalibrationMassesUsed:String
/// meaTester:String
/// meaRemarks1:String
/// meaRemarks2:String
/// meaRemarks3:String
/// meaRemarks4:String
/// meaRemarks5:String
/// meaDate:Date
/// meaTemperature:Float
/// meaRecalInterval:Int32
/// meaTyneA:Float
/// meaTyneB:Float
/// meaFirstCalibration:Bool
/// meaPreCalValues:Bool
/// meaRecalibrated:Bool
/// meaChanged:String
/// meaAuthorised:String
/// meaAuthorisedBy:String
/// meaNominalMassSize:String
///
    private enum CodingKeys: String, CodingKey {
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaMassA
        case meaMassAReading51
        case meaMassAReading52
        case meaMassAReading53
        case meaMassAReading54
        case meaMassAReading55
        case meaMassB
        case meaMassBReading51
        case meaMassBReading52
        case meaMassBReading53
        case meaMassBReading54
        case meaMassBReading55
        case meaMassC
        case meaMassCReading51
        case meaMassCReading52
        case meaMassCReading53
        case meaMassCReading54
        case meaMassCReading55
        case meaMassD
        case meaMassDReading51
        case meaMassDReading52
        case meaMassDReading53
        case meaMassDReading54
        case meaMassDReading55
        case meaCalibrationMassesUsed
        case meaTester
        case meaRemarks1
        case meaRemarks2
        case meaRemarks3
        case meaRemarks4
        case meaRemarks5
        case meaDate
        case meaTemperature
        case meaRecalInterval
        case meaTyneA
        case meaTyneB
        case meaFirstCalibration
        case meaPreCalValues
        case meaRecalibrated
        case meaChanged
        case meaAuthorised
        case meaAuthorisedBy
        case meaNominalMassSize
    }

    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaMassA:String
    let meaMassAReading51:String
    let meaMassAReading52:String
    let meaMassAReading53:String
    let meaMassAReading54:String
    let meaMassAReading55:String
    let meaMassB:String
    let meaMassBReading51:String
    let meaMassBReading52:String
    let meaMassBReading53:String
    let meaMassBReading54:String
    let meaMassBReading55:String
    let meaMassC:String
    let meaMassCReading51:String
    let meaMassCReading52:String
    let meaMassCReading53:String
    let meaMassCReading54:String
    let meaMassCReading55:String
    let meaMassD:String
    let meaMassDReading51:String
    let meaMassDReading52:String
    let meaMassDReading53:String
    let meaMassDReading54:String
    let meaMassDReading55:String
    let meaCalibrationMassesUsed:String
    let meaTester:String
    let meaRemarks1:String
    let meaRemarks2:String
    let meaRemarks3:String
    let meaRemarks4:String
    let meaRemarks5:String
    let meaDate:Date
    let meaTemperature:Float
    let meaRecalInterval:Int32
    let meaTyneA:Float
    let meaTyneB:Float
    let meaFirstCalibration:Bool
    let meaPreCalValues:Bool
    let meaRecalibrated:Bool
    let meaChanged:String
    let meaAuthorised:String
    let meaAuthorisedBy:String
    let meaNominalMassSize:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let meaDeviceId = GetNiceInt32(values:values, forKey: .meaDeviceId)
        let meaReportNo = GetNiceString(values:values, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaMassA = GetNiceString(values:values, forKey: .meaMassA)
        let meaMassAReading51 = GetNiceString(values:values, forKey: .meaMassAReading51)
        let meaMassAReading52 = GetNiceString(values:values, forKey: .meaMassAReading52)
        let meaMassAReading53 = GetNiceString(values:values, forKey: .meaMassAReading53)
        let meaMassAReading54 = GetNiceString(values:values, forKey: .meaMassAReading54)
        let meaMassAReading55 = GetNiceString(values:values, forKey: .meaMassAReading55)
        let meaMassB = GetNiceString(values:values, forKey: .meaMassB)
        let meaMassBReading51 = GetNiceString(values:values, forKey: .meaMassBReading51)
        let meaMassBReading52 = GetNiceString(values:values, forKey: .meaMassBReading52)
        let meaMassBReading53 = GetNiceString(values:values, forKey: .meaMassBReading53)
        let meaMassBReading54 = GetNiceString(values:values, forKey: .meaMassBReading54)
        let meaMassBReading55 = GetNiceString(values:values, forKey: .meaMassBReading55)
        let meaMassC = GetNiceString(values:values, forKey: .meaMassC)
        let meaMassCReading51 = GetNiceString(values:values, forKey: .meaMassCReading51)
        let meaMassCReading52 = GetNiceString(values:values, forKey: .meaMassCReading52)
        let meaMassCReading53 = GetNiceString(values:values, forKey: .meaMassCReading53)
        let meaMassCReading54 = GetNiceString(values:values, forKey: .meaMassCReading54)
        let meaMassCReading55 = GetNiceString(values:values, forKey: .meaMassCReading55)
        let meaMassD = GetNiceString(values:values, forKey: .meaMassD)
        let meaMassDReading51 = GetNiceString(values:values, forKey: .meaMassDReading51)
        let meaMassDReading52 = GetNiceString(values:values, forKey: .meaMassDReading52)
        let meaMassDReading53 = GetNiceString(values:values, forKey: .meaMassDReading53)
        let meaMassDReading54 = GetNiceString(values:values, forKey: .meaMassDReading54)
        let meaMassDReading55 = GetNiceString(values:values, forKey: .meaMassDReading55)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaRemarks1 = GetNiceString(values:values, forKey: .meaRemarks1)
        let meaRemarks2 = GetNiceString(values:values, forKey: .meaRemarks2)
        let meaRemarks3 = GetNiceString(values:values, forKey: .meaRemarks3)
        let meaRemarks4 = GetNiceString(values:values, forKey: .meaRemarks4)
        let meaRemarks5 = GetNiceString(values:values, forKey: .meaRemarks5)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaTemperature = GetNiceFloat(values:values, forKey: .meaTemperature)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaTyneA = GetNiceFloat(values:values, forKey: .meaTyneA)
        let meaTyneB = GetNiceFloat(values:values, forKey: .meaTyneB)
        let meaFirstCalibration = GetNiceBool(values:values, forKey: .meaFirstCalibration)
        let meaPreCalValues = GetNiceBool(values:values, forKey: .meaPreCalValues)
        let meaRecalibrated = GetNiceBool(values:values, forKey: .meaRecalibrated)
        let meaChanged = GetNiceString(values:values, forKey: .meaChanged)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)
        let meaNominalMassSize = GetNiceString(values:values, forKey: .meaNominalMassSize)

    guard
        let meaCalibrationId = rawMeaCalibrationId
     else {
         var strValues = "Error Importing Table: MeaForklift"
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaMassA = meaMassA
        self.meaMassAReading51 = meaMassAReading51
        self.meaMassAReading52 = meaMassAReading52
        self.meaMassAReading53 = meaMassAReading53
        self.meaMassAReading54 = meaMassAReading54
        self.meaMassAReading55 = meaMassAReading55
        self.meaMassB = meaMassB
        self.meaMassBReading51 = meaMassBReading51
        self.meaMassBReading52 = meaMassBReading52
        self.meaMassBReading53 = meaMassBReading53
        self.meaMassBReading54 = meaMassBReading54
        self.meaMassBReading55 = meaMassBReading55
        self.meaMassC = meaMassC
        self.meaMassCReading51 = meaMassCReading51
        self.meaMassCReading52 = meaMassCReading52
        self.meaMassCReading53 = meaMassCReading53
        self.meaMassCReading54 = meaMassCReading54
        self.meaMassCReading55 = meaMassCReading55
        self.meaMassD = meaMassD
        self.meaMassDReading51 = meaMassDReading51
        self.meaMassDReading52 = meaMassDReading52
        self.meaMassDReading53 = meaMassDReading53
        self.meaMassDReading54 = meaMassDReading54
        self.meaMassDReading55 = meaMassDReading55
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaTester = meaTester
        self.meaRemarks1 = meaRemarks1
        self.meaRemarks2 = meaRemarks2
        self.meaRemarks3 = meaRemarks3
        self.meaRemarks4 = meaRemarks4
        self.meaRemarks5 = meaRemarks5
        self.meaDate = meaDate
        self.meaTemperature = meaTemperature
        self.meaRecalInterval = meaRecalInterval
        self.meaTyneA = meaTyneA
        self.meaTyneB = meaTyneB
        self.meaFirstCalibration = meaFirstCalibration
        self.meaPreCalValues = meaPreCalValues
        self.meaRecalibrated = meaRecalibrated
        self.meaChanged = meaChanged
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
        self.meaNominalMassSize = meaNominalMassSize
    }

    var dictionaryValue: [String: Any] {
    [
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaMassA" : meaMassA,
        "meaMassAReading51" : meaMassAReading51,
        "meaMassAReading52" : meaMassAReading52,
        "meaMassAReading53" : meaMassAReading53,
        "meaMassAReading54" : meaMassAReading54,
        "meaMassAReading55" : meaMassAReading55,
        "meaMassB" : meaMassB,
        "meaMassBReading51" : meaMassBReading51,
        "meaMassBReading52" : meaMassBReading52,
        "meaMassBReading53" : meaMassBReading53,
        "meaMassBReading54" : meaMassBReading54,
        "meaMassBReading55" : meaMassBReading55,
        "meaMassC" : meaMassC,
        "meaMassCReading51" : meaMassCReading51,
        "meaMassCReading52" : meaMassCReading52,
        "meaMassCReading53" : meaMassCReading53,
        "meaMassCReading54" : meaMassCReading54,
        "meaMassCReading55" : meaMassCReading55,
        "meaMassD" : meaMassD,
        "meaMassDReading51" : meaMassDReading51,
        "meaMassDReading52" : meaMassDReading52,
        "meaMassDReading53" : meaMassDReading53,
        "meaMassDReading54" : meaMassDReading54,
        "meaMassDReading55" : meaMassDReading55,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaTester" : meaTester,
        "meaRemarks1" : meaRemarks1,
        "meaRemarks2" : meaRemarks2,
        "meaRemarks3" : meaRemarks3,
        "meaRemarks4" : meaRemarks4,
        "meaRemarks5" : meaRemarks5,
        "meaDate" : meaDate,
        "meaTemperature" : meaTemperature,
        "meaRecalInterval" : meaRecalInterval,
        "meaTyneA" : meaTyneA,
        "meaTyneB" : meaTyneB,
        "meaFirstCalibration" : meaFirstCalibration,
        "meaPreCalValues" : meaPreCalValues,
        "meaRecalibrated" : meaRecalibrated,
        "meaChanged" : meaChanged,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        "meaNominalMassSize" : meaNominalMassSize,
        ]
    }
}
