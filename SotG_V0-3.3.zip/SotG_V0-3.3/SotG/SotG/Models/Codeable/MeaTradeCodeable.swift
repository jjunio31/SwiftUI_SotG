//
//  MeaTradeCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaTradeCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaTrade
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32
/// meaReportNo:String
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaIsFirstCalibration:Bool
/// meaIsPreCalibration:Bool
/// meaIsRecalibrated:Bool
/// meaZeroSvtyNomReading1:String
/// meaZeroSvtyNomReading2:String
/// meaZeroSvtyReading1:String
/// meaZeroSvtyReading2:String
/// meaZeroSvtyUp1:String
/// meaZeroSvtyUp2:String
/// meaZeroSvtyDown1:String
/// meaZeroSvtyDown2:String
/// meaZeroSvtyFinal1:String
/// meaZeroSvtyFinal2:String
/// meaZeroSvtyFinalUp1:String
/// meaZeroSvtyFinalUp2:String
/// meaZeroSvtyFinalDown1:String
/// meaZeroSvtyFinalDown2:String
/// meaMpeChgp1Nominal1:String
/// meaMpeChgp1Nominal2:String
/// meaMpeChgp1Nominal3:String
/// meaMpeChgp1PreCal1:String
/// meaMpeChgp1PreCal2:String
/// meaMpeChgp1PreCal3:String
/// meaMpeChgp1PreCalUp1:String
/// meaMpeChgp1PreCalUp2:String
/// meaMpeChgp1PreCalUp3:String
/// meaMpeChgp1PreCalDn1:String
/// meaMpeChgp1PreCalDn2:String
/// meaMpeChgp1PreCalDn3:String
/// meaMpeChgp1Final1:String
/// meaMpeChgp1Final2:String
/// meaMpeChgp1Final3:String
/// meaMpeChgp1FinUp1:String
/// meaMpeChgp1FinUp2:String
/// meaMpeChgp1FinUp3:String
/// meaMpeChgp1FinDown1:String
/// meaMpeChgp1FinDown2:String
/// meaMpeChgp1FinDown3:String
/// meaMpeChgp2Nominal1:String
/// meaMpeChgp2Nominal2:String
/// meaMpeChgp2Nominal3:String
/// meaMpeChgp2PreCal1:String
/// meaMpeChgp2PreCal2:String
/// meaMpeChgp2PreCal3:String
/// meaMpeChgp2PreCalUp1:String
/// meaMpeChgp2PreCalUp2:String
/// meaMpeChgp2PreCalUp3:String
/// meaMpeChgp2PreCalDn1:String
/// meaMpeChgp2PreCalDn2:String
/// meaMpeChgp2PreCalDn3:String
/// meaMpeChgp2Final1:String
/// meaMpeChgp2Final2:String
/// meaMpeChgp2Final3:String
/// meaMpeChgp2FinUp1:String
/// meaMpeChgp2FinUp2:String
/// meaMpeChgp2FinUp3:String
/// meaMpeChgp2FinDn1:String
/// meaMpeChgp2FinDn2:String
/// meaMpeChgp2FinDn3:String
/// meaMaxChgptNominal:String
/// meaMaxChgptPreCal:String
/// meaMaxChgptPreUp:String
/// meaMaxChgptPreDn:String
/// meaMaxChgptFinal:String
/// meaMaxChgptFinUp:String
/// meaMaxChgptFinDn:String
/// meaTradeApproved:Bool
/// meaStamping:String
/// meaManditoryMarkings:Bool
/// meaLevelIndicatingDev:Bool
/// meaCleanAndServicable:Bool
/// meaAdequateProtection:Bool
/// meaNoObstructions:Bool
/// meaClearView:Bool
/// meaNoDamage:Bool
/// meaArmWorking:Bool
/// meaSpecificReqA:Bool
/// meaSpecificReqADesc:String
/// meaSpecificReqB:Bool
/// meaSpecificReqC:Bool
/// meaSpecificReqD:Bool
/// meaSpecificReqE:Bool
/// meaSpecificReqBDesc:String
/// meaSpecificReqCDesc:String
/// meaSpecificReqDDesc:String
/// meaSpecificReqEDesc:String
/// meaAuxDevA:Bool
/// meaAuxDevB:Bool
/// meaAuxDevADesc:String
/// meaAuxDevBDesc:String
/// meaMassA:String
/// meaMassAReading1:String
/// meaMassAReading2:String
/// meaMassAReading3:String
/// meaMassB:String
/// meaMassBReading1:String
/// meaMassBReading2:String
/// meaMassBReading3:String
/// meaDispReadChange1:String
/// meaDispReadChange2:String
/// meaDispReadChange3:String
/// meaDispReadChange4:String
/// meaDispReadChange5:String
/// meaDispReadChange6:String
/// meaDispReadChange7:String
/// meaDispReadChange8:String
/// meaDispReadChange9:String
/// meaDispReadChange10:String
/// meaDispReadChange11:String
/// meaDispReadChange12:String
/// meaDispReadChange13:String
/// meaDispReading1:String
/// meaDispReading2:String
/// meaDispReading3:String
/// meaDispReading4:String
/// meaDispReading5:String
/// meaDispReading6:String
/// meaDispReading7:String
/// meaDispReading8:String
/// meaDispReading9:String
/// meaDispReading10:String
/// meaDispReading11:String
/// meaDispReading12:String
/// meaDispReading13:String
/// meaNominalMassSize:String
/// meaCalibrationMassesUsed:String
/// meaRemarks1:String
/// meaRemarks2:String
/// meaRemarks3:String
/// meaRemarks4:String
/// meaRemarks5:String
/// meaTester:String
/// meaDate:Date
/// meaTemperature:Float
/// meaRecalInterval:Int32
/// meaChanged:String
/// meaAuthorised:String
/// meaAuthorisedBy:String
///
    private enum CodingKeys: String, CodingKey {
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaIsFirstCalibration
        case meaIsPreCalibration
        case meaIsRecalibrated
        case meaZeroSvtyNomReading1
        case meaZeroSvtyNomReading2
        case meaZeroSvtyReading1
        case meaZeroSvtyReading2
        case meaZeroSvtyUp1
        case meaZeroSvtyUp2
        case meaZeroSvtyDown1
        case meaZeroSvtyDown2
        case meaZeroSvtyFinal1
        case meaZeroSvtyFinal2
        case meaZeroSvtyFinalUp1
        case meaZeroSvtyFinalUp2
        case meaZeroSvtyFinalDown1
        case meaZeroSvtyFinalDown2
        case meaMpeChgp1Nominal1
        case meaMpeChgp1Nominal2
        case meaMpeChgp1Nominal3
        case meaMpeChgp1PreCal1
        case meaMpeChgp1PreCal2
        case meaMpeChgp1PreCal3
        case meaMpeChgp1PreCalUp1
        case meaMpeChgp1PreCalUp2
        case meaMpeChgp1PreCalUp3
        case meaMpeChgp1PreCalDn1
        case meaMpeChgp1PreCalDn2
        case meaMpeChgp1PreCalDn3
        case meaMpeChgp1Final1
        case meaMpeChgp1Final2
        case meaMpeChgp1Final3
        case meaMpeChgp1FinUp1
        case meaMpeChgp1FinUp2
        case meaMpeChgp1FinUp3
        case meaMpeChgp1FinDown1
        case meaMpeChgp1FinDown2
        case meaMpeChgp1FinDown3
        case meaMpeChgp2Nominal1
        case meaMpeChgp2Nominal2
        case meaMpeChgp2Nominal3
        case meaMpeChgp2PreCal1
        case meaMpeChgp2PreCal2
        case meaMpeChgp2PreCal3
        case meaMpeChgp2PreCalUp1
        case meaMpeChgp2PreCalUp2
        case meaMpeChgp2PreCalUp3
        case meaMpeChgp2PreCalDn1
        case meaMpeChgp2PreCalDn2
        case meaMpeChgp2PreCalDn3
        case meaMpeChgp2Final1
        case meaMpeChgp2Final2
        case meaMpeChgp2Final3
        case meaMpeChgp2FinUp1
        case meaMpeChgp2FinUp2
        case meaMpeChgp2FinUp3
        case meaMpeChgp2FinDn1
        case meaMpeChgp2FinDn2
        case meaMpeChgp2FinDn3
        case meaMaxChgptNominal
        case meaMaxChgptPreCal
        case meaMaxChgptPreUp
        case meaMaxChgptPreDn
        case meaMaxChgptFinal
        case meaMaxChgptFinUp
        case meaMaxChgptFinDn
        case meaTradeApproved
        case meaStamping
        case meaManditoryMarkings
        case meaLevelIndicatingDev
        case meaCleanAndServicable
        case meaAdequateProtection
        case meaNoObstructions
        case meaClearView
        case meaNoDamage
        case meaArmWorking
        case meaSpecificReqA
        case meaSpecificReqADesc
        case meaSpecificReqB
        case meaSpecificReqC
        case meaSpecificReqD
        case meaSpecificReqE
        case meaSpecificReqBDesc
        case meaSpecificReqCDesc
        case meaSpecificReqDDesc
        case meaSpecificReqEDesc
        case meaAuxDevA
        case meaAuxDevB
        case meaAuxDevADesc
        case meaAuxDevBDesc
        case meaMassA
        case meaMassAReading1
        case meaMassAReading2
        case meaMassAReading3
        case meaMassB
        case meaMassBReading1
        case meaMassBReading2
        case meaMassBReading3
        case meaDispReadChange1
        case meaDispReadChange2
        case meaDispReadChange3
        case meaDispReadChange4
        case meaDispReadChange5
        case meaDispReadChange6
        case meaDispReadChange7
        case meaDispReadChange8
        case meaDispReadChange9
        case meaDispReadChange10
        case meaDispReadChange11
        case meaDispReadChange12
        case meaDispReadChange13
        case meaDispReading1
        case meaDispReading2
        case meaDispReading3
        case meaDispReading4
        case meaDispReading5
        case meaDispReading6
        case meaDispReading7
        case meaDispReading8
        case meaDispReading9
        case meaDispReading10
        case meaDispReading11
        case meaDispReading12
        case meaDispReading13
        case meaNominalMassSize
        case meaCalibrationMassesUsed
        case meaRemarks1
        case meaRemarks2
        case meaRemarks3
        case meaRemarks4
        case meaRemarks5
        case meaTester
        case meaDate
        case meaTemperature
        case meaRecalInterval
        case meaChanged
        case meaAuthorised
        case meaAuthorisedBy
    }

    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaIsFirstCalibration:Bool
    let meaIsPreCalibration:Bool
    let meaIsRecalibrated:Bool
    let meaZeroSvtyNomReading1:String
    let meaZeroSvtyNomReading2:String
    let meaZeroSvtyReading1:String
    let meaZeroSvtyReading2:String
    let meaZeroSvtyUp1:String
    let meaZeroSvtyUp2:String
    let meaZeroSvtyDown1:String
    let meaZeroSvtyDown2:String
    let meaZeroSvtyFinal1:String
    let meaZeroSvtyFinal2:String
    let meaZeroSvtyFinalUp1:String
    let meaZeroSvtyFinalUp2:String
    let meaZeroSvtyFinalDown1:String
    let meaZeroSvtyFinalDown2:String
    let meaMpeChgp1Nominal1:String
    let meaMpeChgp1Nominal2:String
    let meaMpeChgp1Nominal3:String
    let meaMpeChgp1PreCal1:String
    let meaMpeChgp1PreCal2:String
    let meaMpeChgp1PreCal3:String
    let meaMpeChgp1PreCalUp1:String
    let meaMpeChgp1PreCalUp2:String
    let meaMpeChgp1PreCalUp3:String
    let meaMpeChgp1PreCalDn1:String
    let meaMpeChgp1PreCalDn2:String
    let meaMpeChgp1PreCalDn3:String
    let meaMpeChgp1Final1:String
    let meaMpeChgp1Final2:String
    let meaMpeChgp1Final3:String
    let meaMpeChgp1FinUp1:String
    let meaMpeChgp1FinUp2:String
    let meaMpeChgp1FinUp3:String
    let meaMpeChgp1FinDown1:String
    let meaMpeChgp1FinDown2:String
    let meaMpeChgp1FinDown3:String
    let meaMpeChgp2Nominal1:String
    let meaMpeChgp2Nominal2:String
    let meaMpeChgp2Nominal3:String
    let meaMpeChgp2PreCal1:String
    let meaMpeChgp2PreCal2:String
    let meaMpeChgp2PreCal3:String
    let meaMpeChgp2PreCalUp1:String
    let meaMpeChgp2PreCalUp2:String
    let meaMpeChgp2PreCalUp3:String
    let meaMpeChgp2PreCalDn1:String
    let meaMpeChgp2PreCalDn2:String
    let meaMpeChgp2PreCalDn3:String
    let meaMpeChgp2Final1:String
    let meaMpeChgp2Final2:String
    let meaMpeChgp2Final3:String
    let meaMpeChgp2FinUp1:String
    let meaMpeChgp2FinUp2:String
    let meaMpeChgp2FinUp3:String
    let meaMpeChgp2FinDn1:String
    let meaMpeChgp2FinDn2:String
    let meaMpeChgp2FinDn3:String
    let meaMaxChgptNominal:String
    let meaMaxChgptPreCal:String
    let meaMaxChgptPreUp:String
    let meaMaxChgptPreDn:String
    let meaMaxChgptFinal:String
    let meaMaxChgptFinUp:String
    let meaMaxChgptFinDn:String
    let meaTradeApproved:Bool
    let meaStamping:String
    let meaManditoryMarkings:Bool
    let meaLevelIndicatingDev:Bool
    let meaCleanAndServicable:Bool
    let meaAdequateProtection:Bool
    let meaNoObstructions:Bool
    let meaClearView:Bool
    let meaNoDamage:Bool
    let meaArmWorking:Bool
    let meaSpecificReqA:Bool
    let meaSpecificReqADesc:String
    let meaSpecificReqB:Bool
    let meaSpecificReqC:Bool
    let meaSpecificReqD:Bool
    let meaSpecificReqE:Bool
    let meaSpecificReqBDesc:String
    let meaSpecificReqCDesc:String
    let meaSpecificReqDDesc:String
    let meaSpecificReqEDesc:String
    let meaAuxDevA:Bool
    let meaAuxDevB:Bool
    let meaAuxDevADesc:String
    let meaAuxDevBDesc:String
    let meaMassA:String
    let meaMassAReading1:String
    let meaMassAReading2:String
    let meaMassAReading3:String
    let meaMassB:String
    let meaMassBReading1:String
    let meaMassBReading2:String
    let meaMassBReading3:String
    let meaDispReadChange1:String
    let meaDispReadChange2:String
    let meaDispReadChange3:String
    let meaDispReadChange4:String
    let meaDispReadChange5:String
    let meaDispReadChange6:String
    let meaDispReadChange7:String
    let meaDispReadChange8:String
    let meaDispReadChange9:String
    let meaDispReadChange10:String
    let meaDispReadChange11:String
    let meaDispReadChange12:String
    let meaDispReadChange13:String
    let meaDispReading1:String
    let meaDispReading2:String
    let meaDispReading3:String
    let meaDispReading4:String
    let meaDispReading5:String
    let meaDispReading6:String
    let meaDispReading7:String
    let meaDispReading8:String
    let meaDispReading9:String
    let meaDispReading10:String
    let meaDispReading11:String
    let meaDispReading12:String
    let meaDispReading13:String
    let meaNominalMassSize:String
    let meaCalibrationMassesUsed:String
    let meaRemarks1:String
    let meaRemarks2:String
    let meaRemarks3:String
    let meaRemarks4:String
    let meaRemarks5:String
    let meaTester:String
    let meaDate:Date
    let meaTemperature:Float
    let meaRecalInterval:Int32
    let meaChanged:String
    let meaAuthorised:String
    let meaAuthorisedBy:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let meaDeviceId = GetNiceInt32(values:values, forKey: .meaDeviceId)
        let meaReportNo = GetNiceString(values:values, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaIsFirstCalibration = GetNiceBool(values:values, forKey: .meaIsFirstCalibration)
        let meaIsPreCalibration = GetNiceBool(values:values, forKey: .meaIsPreCalibration)
        let meaIsRecalibrated = GetNiceBool(values:values, forKey: .meaIsRecalibrated)
        let meaZeroSvtyNomReading1 = GetNiceString(values:values, forKey: .meaZeroSvtyNomReading1)
        let meaZeroSvtyNomReading2 = GetNiceString(values:values, forKey: .meaZeroSvtyNomReading2)
        let meaZeroSvtyReading1 = GetNiceString(values:values, forKey: .meaZeroSvtyReading1)
        let meaZeroSvtyReading2 = GetNiceString(values:values, forKey: .meaZeroSvtyReading2)
        let meaZeroSvtyUp1 = GetNiceString(values:values, forKey: .meaZeroSvtyUp1)
        let meaZeroSvtyUp2 = GetNiceString(values:values, forKey: .meaZeroSvtyUp2)
        let meaZeroSvtyDown1 = GetNiceString(values:values, forKey: .meaZeroSvtyDown1)
        let meaZeroSvtyDown2 = GetNiceString(values:values, forKey: .meaZeroSvtyDown2)
        let meaZeroSvtyFinal1 = GetNiceString(values:values, forKey: .meaZeroSvtyFinal1)
        let meaZeroSvtyFinal2 = GetNiceString(values:values, forKey: .meaZeroSvtyFinal2)
        let meaZeroSvtyFinalUp1 = GetNiceString(values:values, forKey: .meaZeroSvtyFinalUp1)
        let meaZeroSvtyFinalUp2 = GetNiceString(values:values, forKey: .meaZeroSvtyFinalUp2)
        let meaZeroSvtyFinalDown1 = GetNiceString(values:values, forKey: .meaZeroSvtyFinalDown1)
        let meaZeroSvtyFinalDown2 = GetNiceString(values:values, forKey: .meaZeroSvtyFinalDown2)
        let meaMpeChgp1Nominal1 = GetNiceString(values:values, forKey: .meaMpeChgp1Nominal1)
        let meaMpeChgp1Nominal2 = GetNiceString(values:values, forKey: .meaMpeChgp1Nominal2)
        let meaMpeChgp1Nominal3 = GetNiceString(values:values, forKey: .meaMpeChgp1Nominal3)
        let meaMpeChgp1PreCal1 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCal1)
        let meaMpeChgp1PreCal2 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCal2)
        let meaMpeChgp1PreCal3 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCal3)
        let meaMpeChgp1PreCalUp1 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCalUp1)
        let meaMpeChgp1PreCalUp2 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCalUp2)
        let meaMpeChgp1PreCalUp3 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCalUp3)
        let meaMpeChgp1PreCalDn1 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCalDn1)
        let meaMpeChgp1PreCalDn2 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCalDn2)
        let meaMpeChgp1PreCalDn3 = GetNiceString(values:values, forKey: .meaMpeChgp1PreCalDn3)
        let meaMpeChgp1Final1 = GetNiceString(values:values, forKey: .meaMpeChgp1Final1)
        let meaMpeChgp1Final2 = GetNiceString(values:values, forKey: .meaMpeChgp1Final2)
        let meaMpeChgp1Final3 = GetNiceString(values:values, forKey: .meaMpeChgp1Final3)
        let meaMpeChgp1FinUp1 = GetNiceString(values:values, forKey: .meaMpeChgp1FinUp1)
        let meaMpeChgp1FinUp2 = GetNiceString(values:values, forKey: .meaMpeChgp1FinUp2)
        let meaMpeChgp1FinUp3 = GetNiceString(values:values, forKey: .meaMpeChgp1FinUp3)
        let meaMpeChgp1FinDown1 = GetNiceString(values:values, forKey: .meaMpeChgp1FinDown1)
        let meaMpeChgp1FinDown2 = GetNiceString(values:values, forKey: .meaMpeChgp1FinDown2)
        let meaMpeChgp1FinDown3 = GetNiceString(values:values, forKey: .meaMpeChgp1FinDown3)
        let meaMpeChgp2Nominal1 = GetNiceString(values:values, forKey: .meaMpeChgp2Nominal1)
        let meaMpeChgp2Nominal2 = GetNiceString(values:values, forKey: .meaMpeChgp2Nominal2)
        let meaMpeChgp2Nominal3 = GetNiceString(values:values, forKey: .meaMpeChgp2Nominal3)
        let meaMpeChgp2PreCal1 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCal1)
        let meaMpeChgp2PreCal2 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCal2)
        let meaMpeChgp2PreCal3 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCal3)
        let meaMpeChgp2PreCalUp1 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCalUp1)
        let meaMpeChgp2PreCalUp2 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCalUp2)
        let meaMpeChgp2PreCalUp3 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCalUp3)
        let meaMpeChgp2PreCalDn1 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCalDn1)
        let meaMpeChgp2PreCalDn2 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCalDn2)
        let meaMpeChgp2PreCalDn3 = GetNiceString(values:values, forKey: .meaMpeChgp2PreCalDn3)
        let meaMpeChgp2Final1 = GetNiceString(values:values, forKey: .meaMpeChgp2Final1)
        let meaMpeChgp2Final2 = GetNiceString(values:values, forKey: .meaMpeChgp2Final2)
        let meaMpeChgp2Final3 = GetNiceString(values:values, forKey: .meaMpeChgp2Final3)
        let meaMpeChgp2FinUp1 = GetNiceString(values:values, forKey: .meaMpeChgp2FinUp1)
        let meaMpeChgp2FinUp2 = GetNiceString(values:values, forKey: .meaMpeChgp2FinUp2)
        let meaMpeChgp2FinUp3 = GetNiceString(values:values, forKey: .meaMpeChgp2FinUp3)
        let meaMpeChgp2FinDn1 = GetNiceString(values:values, forKey: .meaMpeChgp2FinDn1)
        let meaMpeChgp2FinDn2 = GetNiceString(values:values, forKey: .meaMpeChgp2FinDn2)
        let meaMpeChgp2FinDn3 = GetNiceString(values:values, forKey: .meaMpeChgp2FinDn3)
        let meaMaxChgptNominal = GetNiceString(values:values, forKey: .meaMaxChgptNominal)
        let meaMaxChgptPreCal = GetNiceString(values:values, forKey: .meaMaxChgptPreCal)
        let meaMaxChgptPreUp = GetNiceString(values:values, forKey: .meaMaxChgptPreUp)
        let meaMaxChgptPreDn = GetNiceString(values:values, forKey: .meaMaxChgptPreDn)
        let meaMaxChgptFinal = GetNiceString(values:values, forKey: .meaMaxChgptFinal)
        let meaMaxChgptFinUp = GetNiceString(values:values, forKey: .meaMaxChgptFinUp)
        let meaMaxChgptFinDn = GetNiceString(values:values, forKey: .meaMaxChgptFinDn)
        let meaTradeApproved = GetNiceBool(values:values, forKey: .meaTradeApproved)
        let meaStamping = GetNiceString(values:values, forKey: .meaStamping)
        let meaManditoryMarkings = GetNiceBool(values:values, forKey: .meaManditoryMarkings)
        let meaLevelIndicatingDev = GetNiceBool(values:values, forKey: .meaLevelIndicatingDev)
        let meaCleanAndServicable = GetNiceBool(values:values, forKey: .meaCleanAndServicable)
        let meaAdequateProtection = GetNiceBool(values:values, forKey: .meaAdequateProtection)
        let meaNoObstructions = GetNiceBool(values:values, forKey: .meaNoObstructions)
        let meaClearView = GetNiceBool(values:values, forKey: .meaClearView)
        let meaNoDamage = GetNiceBool(values:values, forKey: .meaNoDamage)
        let meaArmWorking = GetNiceBool(values:values, forKey: .meaArmWorking)
        let meaSpecificReqA = GetNiceBool(values:values, forKey: .meaSpecificReqA)
        let meaSpecificReqADesc = GetNiceString(values:values, forKey: .meaSpecificReqADesc)
        let meaSpecificReqB = GetNiceBool(values:values, forKey: .meaSpecificReqB)
        let meaSpecificReqC = GetNiceBool(values:values, forKey: .meaSpecificReqC)
        let meaSpecificReqD = GetNiceBool(values:values, forKey: .meaSpecificReqD)
        let meaSpecificReqE = GetNiceBool(values:values, forKey: .meaSpecificReqE)
        let meaSpecificReqBDesc = GetNiceString(values:values, forKey: .meaSpecificReqBDesc)
        let meaSpecificReqCDesc = GetNiceString(values:values, forKey: .meaSpecificReqCDesc)
        let meaSpecificReqDDesc = GetNiceString(values:values, forKey: .meaSpecificReqDDesc)
        let meaSpecificReqEDesc = GetNiceString(values:values, forKey: .meaSpecificReqEDesc)
        let meaAuxDevA = GetNiceBool(values:values, forKey: .meaAuxDevA)
        let meaAuxDevB = GetNiceBool(values:values, forKey: .meaAuxDevB)
        let meaAuxDevADesc = GetNiceString(values:values, forKey: .meaAuxDevADesc)
        let meaAuxDevBDesc = GetNiceString(values:values, forKey: .meaAuxDevBDesc)
        let meaMassA = GetNiceString(values:values, forKey: .meaMassA)
        let meaMassAReading1 = GetNiceString(values:values, forKey: .meaMassAReading1)
        let meaMassAReading2 = GetNiceString(values:values, forKey: .meaMassAReading2)
        let meaMassAReading3 = GetNiceString(values:values, forKey: .meaMassAReading3)
        let meaMassB = GetNiceString(values:values, forKey: .meaMassB)
        let meaMassBReading1 = GetNiceString(values:values, forKey: .meaMassBReading1)
        let meaMassBReading2 = GetNiceString(values:values, forKey: .meaMassBReading2)
        let meaMassBReading3 = GetNiceString(values:values, forKey: .meaMassBReading3)
        let meaDispReadChange1 = GetNiceString(values:values, forKey: .meaDispReadChange1)
        let meaDispReadChange2 = GetNiceString(values:values, forKey: .meaDispReadChange2)
        let meaDispReadChange3 = GetNiceString(values:values, forKey: .meaDispReadChange3)
        let meaDispReadChange4 = GetNiceString(values:values, forKey: .meaDispReadChange4)
        let meaDispReadChange5 = GetNiceString(values:values, forKey: .meaDispReadChange5)
        let meaDispReadChange6 = GetNiceString(values:values, forKey: .meaDispReadChange6)
        let meaDispReadChange7 = GetNiceString(values:values, forKey: .meaDispReadChange7)
        let meaDispReadChange8 = GetNiceString(values:values, forKey: .meaDispReadChange8)
        let meaDispReadChange9 = GetNiceString(values:values, forKey: .meaDispReadChange9)
        let meaDispReadChange10 = GetNiceString(values:values, forKey: .meaDispReadChange10)
        let meaDispReadChange11 = GetNiceString(values:values, forKey: .meaDispReadChange11)
        let meaDispReadChange12 = GetNiceString(values:values, forKey: .meaDispReadChange12)
        let meaDispReadChange13 = GetNiceString(values:values, forKey: .meaDispReadChange13)
        let meaDispReading1 = GetNiceString(values:values, forKey: .meaDispReading1)
        let meaDispReading2 = GetNiceString(values:values, forKey: .meaDispReading2)
        let meaDispReading3 = GetNiceString(values:values, forKey: .meaDispReading3)
        let meaDispReading4 = GetNiceString(values:values, forKey: .meaDispReading4)
        let meaDispReading5 = GetNiceString(values:values, forKey: .meaDispReading5)
        let meaDispReading6 = GetNiceString(values:values, forKey: .meaDispReading6)
        let meaDispReading7 = GetNiceString(values:values, forKey: .meaDispReading7)
        let meaDispReading8 = GetNiceString(values:values, forKey: .meaDispReading8)
        let meaDispReading9 = GetNiceString(values:values, forKey: .meaDispReading9)
        let meaDispReading10 = GetNiceString(values:values, forKey: .meaDispReading10)
        let meaDispReading11 = GetNiceString(values:values, forKey: .meaDispReading11)
        let meaDispReading12 = GetNiceString(values:values, forKey: .meaDispReading12)
        let meaDispReading13 = GetNiceString(values:values, forKey: .meaDispReading13)
        let meaNominalMassSize = GetNiceString(values:values, forKey: .meaNominalMassSize)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaRemarks1 = GetNiceString(values:values, forKey: .meaRemarks1)
        let meaRemarks2 = GetNiceString(values:values, forKey: .meaRemarks2)
        let meaRemarks3 = GetNiceString(values:values, forKey: .meaRemarks3)
        let meaRemarks4 = GetNiceString(values:values, forKey: .meaRemarks4)
        let meaRemarks5 = GetNiceString(values:values, forKey: .meaRemarks5)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaTemperature = GetNiceFloat(values:values, forKey: .meaTemperature)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaChanged = GetNiceString(values:values, forKey: .meaChanged)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)

    guard
        let meaCalibrationId = rawMeaCalibrationId
     else {
         var strValues = "Error Importing Table: MeaTrade"
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaIsFirstCalibration = meaIsFirstCalibration
        self.meaIsPreCalibration = meaIsPreCalibration
        self.meaIsRecalibrated = meaIsRecalibrated
        self.meaZeroSvtyNomReading1 = meaZeroSvtyNomReading1
        self.meaZeroSvtyNomReading2 = meaZeroSvtyNomReading2
        self.meaZeroSvtyReading1 = meaZeroSvtyReading1
        self.meaZeroSvtyReading2 = meaZeroSvtyReading2
        self.meaZeroSvtyUp1 = meaZeroSvtyUp1
        self.meaZeroSvtyUp2 = meaZeroSvtyUp2
        self.meaZeroSvtyDown1 = meaZeroSvtyDown1
        self.meaZeroSvtyDown2 = meaZeroSvtyDown2
        self.meaZeroSvtyFinal1 = meaZeroSvtyFinal1
        self.meaZeroSvtyFinal2 = meaZeroSvtyFinal2
        self.meaZeroSvtyFinalUp1 = meaZeroSvtyFinalUp1
        self.meaZeroSvtyFinalUp2 = meaZeroSvtyFinalUp2
        self.meaZeroSvtyFinalDown1 = meaZeroSvtyFinalDown1
        self.meaZeroSvtyFinalDown2 = meaZeroSvtyFinalDown2
        self.meaMpeChgp1Nominal1 = meaMpeChgp1Nominal1
        self.meaMpeChgp1Nominal2 = meaMpeChgp1Nominal2
        self.meaMpeChgp1Nominal3 = meaMpeChgp1Nominal3
        self.meaMpeChgp1PreCal1 = meaMpeChgp1PreCal1
        self.meaMpeChgp1PreCal2 = meaMpeChgp1PreCal2
        self.meaMpeChgp1PreCal3 = meaMpeChgp1PreCal3
        self.meaMpeChgp1PreCalUp1 = meaMpeChgp1PreCalUp1
        self.meaMpeChgp1PreCalUp2 = meaMpeChgp1PreCalUp2
        self.meaMpeChgp1PreCalUp3 = meaMpeChgp1PreCalUp3
        self.meaMpeChgp1PreCalDn1 = meaMpeChgp1PreCalDn1
        self.meaMpeChgp1PreCalDn2 = meaMpeChgp1PreCalDn2
        self.meaMpeChgp1PreCalDn3 = meaMpeChgp1PreCalDn3
        self.meaMpeChgp1Final1 = meaMpeChgp1Final1
        self.meaMpeChgp1Final2 = meaMpeChgp1Final2
        self.meaMpeChgp1Final3 = meaMpeChgp1Final3
        self.meaMpeChgp1FinUp1 = meaMpeChgp1FinUp1
        self.meaMpeChgp1FinUp2 = meaMpeChgp1FinUp2
        self.meaMpeChgp1FinUp3 = meaMpeChgp1FinUp3
        self.meaMpeChgp1FinDown1 = meaMpeChgp1FinDown1
        self.meaMpeChgp1FinDown2 = meaMpeChgp1FinDown2
        self.meaMpeChgp1FinDown3 = meaMpeChgp1FinDown3
        self.meaMpeChgp2Nominal1 = meaMpeChgp2Nominal1
        self.meaMpeChgp2Nominal2 = meaMpeChgp2Nominal2
        self.meaMpeChgp2Nominal3 = meaMpeChgp2Nominal3
        self.meaMpeChgp2PreCal1 = meaMpeChgp2PreCal1
        self.meaMpeChgp2PreCal2 = meaMpeChgp2PreCal2
        self.meaMpeChgp2PreCal3 = meaMpeChgp2PreCal3
        self.meaMpeChgp2PreCalUp1 = meaMpeChgp2PreCalUp1
        self.meaMpeChgp2PreCalUp2 = meaMpeChgp2PreCalUp2
        self.meaMpeChgp2PreCalUp3 = meaMpeChgp2PreCalUp3
        self.meaMpeChgp2PreCalDn1 = meaMpeChgp2PreCalDn1
        self.meaMpeChgp2PreCalDn2 = meaMpeChgp2PreCalDn2
        self.meaMpeChgp2PreCalDn3 = meaMpeChgp2PreCalDn3
        self.meaMpeChgp2Final1 = meaMpeChgp2Final1
        self.meaMpeChgp2Final2 = meaMpeChgp2Final2
        self.meaMpeChgp2Final3 = meaMpeChgp2Final3
        self.meaMpeChgp2FinUp1 = meaMpeChgp2FinUp1
        self.meaMpeChgp2FinUp2 = meaMpeChgp2FinUp2
        self.meaMpeChgp2FinUp3 = meaMpeChgp2FinUp3
        self.meaMpeChgp2FinDn1 = meaMpeChgp2FinDn1
        self.meaMpeChgp2FinDn2 = meaMpeChgp2FinDn2
        self.meaMpeChgp2FinDn3 = meaMpeChgp2FinDn3
        self.meaMaxChgptNominal = meaMaxChgptNominal
        self.meaMaxChgptPreCal = meaMaxChgptPreCal
        self.meaMaxChgptPreUp = meaMaxChgptPreUp
        self.meaMaxChgptPreDn = meaMaxChgptPreDn
        self.meaMaxChgptFinal = meaMaxChgptFinal
        self.meaMaxChgptFinUp = meaMaxChgptFinUp
        self.meaMaxChgptFinDn = meaMaxChgptFinDn
        self.meaTradeApproved = meaTradeApproved
        self.meaStamping = meaStamping
        self.meaManditoryMarkings = meaManditoryMarkings
        self.meaLevelIndicatingDev = meaLevelIndicatingDev
        self.meaCleanAndServicable = meaCleanAndServicable
        self.meaAdequateProtection = meaAdequateProtection
        self.meaNoObstructions = meaNoObstructions
        self.meaClearView = meaClearView
        self.meaNoDamage = meaNoDamage
        self.meaArmWorking = meaArmWorking
        self.meaSpecificReqA = meaSpecificReqA
        self.meaSpecificReqADesc = meaSpecificReqADesc
        self.meaSpecificReqB = meaSpecificReqB
        self.meaSpecificReqC = meaSpecificReqC
        self.meaSpecificReqD = meaSpecificReqD
        self.meaSpecificReqE = meaSpecificReqE
        self.meaSpecificReqBDesc = meaSpecificReqBDesc
        self.meaSpecificReqCDesc = meaSpecificReqCDesc
        self.meaSpecificReqDDesc = meaSpecificReqDDesc
        self.meaSpecificReqEDesc = meaSpecificReqEDesc
        self.meaAuxDevA = meaAuxDevA
        self.meaAuxDevB = meaAuxDevB
        self.meaAuxDevADesc = meaAuxDevADesc
        self.meaAuxDevBDesc = meaAuxDevBDesc
        self.meaMassA = meaMassA
        self.meaMassAReading1 = meaMassAReading1
        self.meaMassAReading2 = meaMassAReading2
        self.meaMassAReading3 = meaMassAReading3
        self.meaMassB = meaMassB
        self.meaMassBReading1 = meaMassBReading1
        self.meaMassBReading2 = meaMassBReading2
        self.meaMassBReading3 = meaMassBReading3
        self.meaDispReadChange1 = meaDispReadChange1
        self.meaDispReadChange2 = meaDispReadChange2
        self.meaDispReadChange3 = meaDispReadChange3
        self.meaDispReadChange4 = meaDispReadChange4
        self.meaDispReadChange5 = meaDispReadChange5
        self.meaDispReadChange6 = meaDispReadChange6
        self.meaDispReadChange7 = meaDispReadChange7
        self.meaDispReadChange8 = meaDispReadChange8
        self.meaDispReadChange9 = meaDispReadChange9
        self.meaDispReadChange10 = meaDispReadChange10
        self.meaDispReadChange11 = meaDispReadChange11
        self.meaDispReadChange12 = meaDispReadChange12
        self.meaDispReadChange13 = meaDispReadChange13
        self.meaDispReading1 = meaDispReading1
        self.meaDispReading2 = meaDispReading2
        self.meaDispReading3 = meaDispReading3
        self.meaDispReading4 = meaDispReading4
        self.meaDispReading5 = meaDispReading5
        self.meaDispReading6 = meaDispReading6
        self.meaDispReading7 = meaDispReading7
        self.meaDispReading8 = meaDispReading8
        self.meaDispReading9 = meaDispReading9
        self.meaDispReading10 = meaDispReading10
        self.meaDispReading11 = meaDispReading11
        self.meaDispReading12 = meaDispReading12
        self.meaDispReading13 = meaDispReading13
        self.meaNominalMassSize = meaNominalMassSize
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaRemarks1 = meaRemarks1
        self.meaRemarks2 = meaRemarks2
        self.meaRemarks3 = meaRemarks3
        self.meaRemarks4 = meaRemarks4
        self.meaRemarks5 = meaRemarks5
        self.meaTester = meaTester
        self.meaDate = meaDate
        self.meaTemperature = meaTemperature
        self.meaRecalInterval = meaRecalInterval
        self.meaChanged = meaChanged
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
    }

    var dictionaryValue: [String: Any] {
    [
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaIsFirstCalibration" : meaIsFirstCalibration,
        "meaIsPreCalibration" : meaIsPreCalibration,
        "meaIsRecalibrated" : meaIsRecalibrated,
        "meaZeroSvtyNomReading1" : meaZeroSvtyNomReading1,
        "meaZeroSvtyNomReading2" : meaZeroSvtyNomReading2,
        "meaZeroSvtyReading1" : meaZeroSvtyReading1,
        "meaZeroSvtyReading2" : meaZeroSvtyReading2,
        "meaZeroSvtyUp1" : meaZeroSvtyUp1,
        "meaZeroSvtyUp2" : meaZeroSvtyUp2,
        "meaZeroSvtyDown1" : meaZeroSvtyDown1,
        "meaZeroSvtyDown2" : meaZeroSvtyDown2,
        "meaZeroSvtyFinal1" : meaZeroSvtyFinal1,
        "meaZeroSvtyFinal2" : meaZeroSvtyFinal2,
        "meaZeroSvtyFinalUp1" : meaZeroSvtyFinalUp1,
        "meaZeroSvtyFinalUp2" : meaZeroSvtyFinalUp2,
        "meaZeroSvtyFinalDown1" : meaZeroSvtyFinalDown1,
        "meaZeroSvtyFinalDown2" : meaZeroSvtyFinalDown2,
        "meaMpeChgp1Nominal1" : meaMpeChgp1Nominal1,
        "meaMpeChgp1Nominal2" : meaMpeChgp1Nominal2,
        "meaMpeChgp1Nominal3" : meaMpeChgp1Nominal3,
        "meaMpeChgp1PreCal1" : meaMpeChgp1PreCal1,
        "meaMpeChgp1PreCal2" : meaMpeChgp1PreCal2,
        "meaMpeChgp1PreCal3" : meaMpeChgp1PreCal3,
        "meaMpeChgp1PreCalUp1" : meaMpeChgp1PreCalUp1,
        "meaMpeChgp1PreCalUp2" : meaMpeChgp1PreCalUp2,
        "meaMpeChgp1PreCalUp3" : meaMpeChgp1PreCalUp3,
        "meaMpeChgp1PreCalDn1" : meaMpeChgp1PreCalDn1,
        "meaMpeChgp1PreCalDn2" : meaMpeChgp1PreCalDn2,
        "meaMpeChgp1PreCalDn3" : meaMpeChgp1PreCalDn3,
        "meaMpeChgp1Final1" : meaMpeChgp1Final1,
        "meaMpeChgp1Final2" : meaMpeChgp1Final2,
        "meaMpeChgp1Final3" : meaMpeChgp1Final3,
        "meaMpeChgp1FinUp1" : meaMpeChgp1FinUp1,
        "meaMpeChgp1FinUp2" : meaMpeChgp1FinUp2,
        "meaMpeChgp1FinUp3" : meaMpeChgp1FinUp3,
        "meaMpeChgp1FinDown1" : meaMpeChgp1FinDown1,
        "meaMpeChgp1FinDown2" : meaMpeChgp1FinDown2,
        "meaMpeChgp1FinDown3" : meaMpeChgp1FinDown3,
        "meaMpeChgp2Nominal1" : meaMpeChgp2Nominal1,
        "meaMpeChgp2Nominal2" : meaMpeChgp2Nominal2,
        "meaMpeChgp2Nominal3" : meaMpeChgp2Nominal3,
        "meaMpeChgp2PreCal1" : meaMpeChgp2PreCal1,
        "meaMpeChgp2PreCal2" : meaMpeChgp2PreCal2,
        "meaMpeChgp2PreCal3" : meaMpeChgp2PreCal3,
        "meaMpeChgp2PreCalUp1" : meaMpeChgp2PreCalUp1,
        "meaMpeChgp2PreCalUp2" : meaMpeChgp2PreCalUp2,
        "meaMpeChgp2PreCalUp3" : meaMpeChgp2PreCalUp3,
        "meaMpeChgp2PreCalDn1" : meaMpeChgp2PreCalDn1,
        "meaMpeChgp2PreCalDn2" : meaMpeChgp2PreCalDn2,
        "meaMpeChgp2PreCalDn3" : meaMpeChgp2PreCalDn3,
        "meaMpeChgp2Final1" : meaMpeChgp2Final1,
        "meaMpeChgp2Final2" : meaMpeChgp2Final2,
        "meaMpeChgp2Final3" : meaMpeChgp2Final3,
        "meaMpeChgp2FinUp1" : meaMpeChgp2FinUp1,
        "meaMpeChgp2FinUp2" : meaMpeChgp2FinUp2,
        "meaMpeChgp2FinUp3" : meaMpeChgp2FinUp3,
        "meaMpeChgp2FinDn1" : meaMpeChgp2FinDn1,
        "meaMpeChgp2FinDn2" : meaMpeChgp2FinDn2,
        "meaMpeChgp2FinDn3" : meaMpeChgp2FinDn3,
        "meaMaxChgptNominal" : meaMaxChgptNominal,
        "meaMaxChgptPreCal" : meaMaxChgptPreCal,
        "meaMaxChgptPreUp" : meaMaxChgptPreUp,
        "meaMaxChgptPreDn" : meaMaxChgptPreDn,
        "meaMaxChgptFinal" : meaMaxChgptFinal,
        "meaMaxChgptFinUp" : meaMaxChgptFinUp,
        "meaMaxChgptFinDn" : meaMaxChgptFinDn,
        "meaTradeApproved" : meaTradeApproved,
        "meaStamping" : meaStamping,
        "meaManditoryMarkings" : meaManditoryMarkings,
        "meaLevelIndicatingDev" : meaLevelIndicatingDev,
        "meaCleanAndServicable" : meaCleanAndServicable,
        "meaAdequateProtection" : meaAdequateProtection,
        "meaNoObstructions" : meaNoObstructions,
        "meaClearView" : meaClearView,
        "meaNoDamage" : meaNoDamage,
        "meaArmWorking" : meaArmWorking,
        "meaSpecificReqA" : meaSpecificReqA,
        "meaSpecificReqADesc" : meaSpecificReqADesc,
        "meaSpecificReqB" : meaSpecificReqB,
        "meaSpecificReqC" : meaSpecificReqC,
        "meaSpecificReqD" : meaSpecificReqD,
        "meaSpecificReqE" : meaSpecificReqE,
        "meaSpecificReqBDesc" : meaSpecificReqBDesc,
        "meaSpecificReqCDesc" : meaSpecificReqCDesc,
        "meaSpecificReqDDesc" : meaSpecificReqDDesc,
        "meaSpecificReqEDesc" : meaSpecificReqEDesc,
        "meaAuxDevA" : meaAuxDevA,
        "meaAuxDevB" : meaAuxDevB,
        "meaAuxDevADesc" : meaAuxDevADesc,
        "meaAuxDevBDesc" : meaAuxDevBDesc,
        "meaMassA" : meaMassA,
        "meaMassAReading1" : meaMassAReading1,
        "meaMassAReading2" : meaMassAReading2,
        "meaMassAReading3" : meaMassAReading3,
        "meaMassB" : meaMassB,
        "meaMassBReading1" : meaMassBReading1,
        "meaMassBReading2" : meaMassBReading2,
        "meaMassBReading3" : meaMassBReading3,
        "meaDispReadChange1" : meaDispReadChange1,
        "meaDispReadChange2" : meaDispReadChange2,
        "meaDispReadChange3" : meaDispReadChange3,
        "meaDispReadChange4" : meaDispReadChange4,
        "meaDispReadChange5" : meaDispReadChange5,
        "meaDispReadChange6" : meaDispReadChange6,
        "meaDispReadChange7" : meaDispReadChange7,
        "meaDispReadChange8" : meaDispReadChange8,
        "meaDispReadChange9" : meaDispReadChange9,
        "meaDispReadChange10" : meaDispReadChange10,
        "meaDispReadChange11" : meaDispReadChange11,
        "meaDispReadChange12" : meaDispReadChange12,
        "meaDispReadChange13" : meaDispReadChange13,
        "meaDispReading1" : meaDispReading1,
        "meaDispReading2" : meaDispReading2,
        "meaDispReading3" : meaDispReading3,
        "meaDispReading4" : meaDispReading4,
        "meaDispReading5" : meaDispReading5,
        "meaDispReading6" : meaDispReading6,
        "meaDispReading7" : meaDispReading7,
        "meaDispReading8" : meaDispReading8,
        "meaDispReading9" : meaDispReading9,
        "meaDispReading10" : meaDispReading10,
        "meaDispReading11" : meaDispReading11,
        "meaDispReading12" : meaDispReading12,
        "meaDispReading13" : meaDispReading13,
        "meaNominalMassSize" : meaNominalMassSize,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaRemarks1" : meaRemarks1,
        "meaRemarks2" : meaRemarks2,
        "meaRemarks3" : meaRemarks3,
        "meaRemarks4" : meaRemarks4,
        "meaRemarks5" : meaRemarks5,
        "meaTester" : meaTester,
        "meaDate" : meaDate,
        "meaTemperature" : meaTemperature,
        "meaRecalInterval" : meaRecalInterval,
        "meaChanged" : meaChanged,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        ]
    }
}
