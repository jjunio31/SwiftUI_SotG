//
//  MeaMetalDetectorCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct MeaMetalDetectorCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:MeaMetalDetector
/// meaCalibrationId:Int32:Key
/// meaDeviceId:Int32:Key
/// meaReportNo:String:Key
/// meaReportSubNumber:Int32
/// meaCallNo:Int32
/// meaTradeApproved:Bool
/// meaManditoryMarkings:Bool
/// meaLevelIndicatingDev:Bool
/// meaCleanAndServicable:Bool
/// meaAdequateProtection:Bool
/// meaNoObstructions:Bool
/// meaClearView:Bool
/// meaNoDamage:Bool
/// meaArmWorking:Bool
/// meaCalibrationMassesUsed:String
/// meaRemarks1:String
/// meaRemarks2:String
/// meaRemarks3:String
/// meaRemarks4:String
/// meaRemarks5:String
/// meaTester:String
/// meaDate:Date
/// meaTemperature:Float
/// meaRecalInterval:Int32
/// meaFerrous:String
/// meaFerrousDetected1:Bool
/// meaFerrousDetected2:Bool
/// meaFerrousDetected3:Bool
/// meaFerrousDetected4:Bool
/// meaFerrousDetected5:Bool
/// meaFerrousDetected6:Bool
/// meaNonFerrous:String
/// meaNonFerrrousDetected1:Bool
/// meaNonFerrrousDetected2:Bool
/// meaNonFerrrousDetected3:Bool
/// meaNonFerrrousDetected4:Bool
/// meaNonFerrrousDetected5:Bool
/// meaNonFerrrousDetected6:Bool
/// meaStainSteel:String
/// meaStainSteelDetected1:Bool
/// meaStainSteelDetected2:Bool
/// meaStainSteelDetected3:Bool
/// meaStainSteelDetected4:Bool
/// meaStainSteelDetected5:Bool
/// meaStainSteelDetected6:Bool
/// meaOperatingInTollerance:Bool
/// meaChanged:String
/// meaAuthorised:String
/// meaAuthorisedBy:String
///
    private enum CodingKeys: String, CodingKey {
        case meaCalibrationId
        case meaDeviceId
        case meaReportNo
        case meaReportSubNumber
        case meaCallNo
        case meaTradeApproved
        case meaManditoryMarkings
        case meaLevelIndicatingDev
        case meaCleanAndServicable
        case meaAdequateProtection
        case meaNoObstructions
        case meaClearView
        case meaNoDamage
        case meaArmWorking
        case meaCalibrationMassesUsed
        case meaRemarks1
        case meaRemarks2
        case meaRemarks3
        case meaRemarks4
        case meaRemarks5
        case meaTester
        case meaDate
        case meaTemperature
        case meaRecalInterval
        case meaFerrous
        case meaFerrousDetected1
        case meaFerrousDetected2
        case meaFerrousDetected3
        case meaFerrousDetected4
        case meaFerrousDetected5
        case meaFerrousDetected6
        case meaNonFerrous
        case meaNonFerrrousDetected1
        case meaNonFerrrousDetected2
        case meaNonFerrrousDetected3
        case meaNonFerrrousDetected4
        case meaNonFerrrousDetected5
        case meaNonFerrrousDetected6
        case meaStainSteel
        case meaStainSteelDetected1
        case meaStainSteelDetected2
        case meaStainSteelDetected3
        case meaStainSteelDetected4
        case meaStainSteelDetected5
        case meaStainSteelDetected6
        case meaOperatingInTollerance
        case meaChanged
        case meaAuthorised
        case meaAuthorisedBy
    }

    let meaCalibrationId:Int32
    let meaDeviceId:Int32
    let meaReportNo:String
    let meaReportSubNumber:Int32
    let meaCallNo:Int32
    let meaTradeApproved:Bool
    let meaManditoryMarkings:Bool
    let meaLevelIndicatingDev:Bool
    let meaCleanAndServicable:Bool
    let meaAdequateProtection:Bool
    let meaNoObstructions:Bool
    let meaClearView:Bool
    let meaNoDamage:Bool
    let meaArmWorking:Bool
    let meaCalibrationMassesUsed:String
    let meaRemarks1:String
    let meaRemarks2:String
    let meaRemarks3:String
    let meaRemarks4:String
    let meaRemarks5:String
    let meaTester:String
    let meaDate:Date
    let meaTemperature:Float
    let meaRecalInterval:Int32
    let meaFerrous:String
    let meaFerrousDetected1:Bool
    let meaFerrousDetected2:Bool
    let meaFerrousDetected3:Bool
    let meaFerrousDetected4:Bool
    let meaFerrousDetected5:Bool
    let meaFerrousDetected6:Bool
    let meaNonFerrous:String
    let meaNonFerrrousDetected1:Bool
    let meaNonFerrrousDetected2:Bool
    let meaNonFerrrousDetected3:Bool
    let meaNonFerrrousDetected4:Bool
    let meaNonFerrrousDetected5:Bool
    let meaNonFerrrousDetected6:Bool
    let meaStainSteel:String
    let meaStainSteelDetected1:Bool
    let meaStainSteelDetected2:Bool
    let meaStainSteelDetected3:Bool
    let meaStainSteelDetected4:Bool
    let meaStainSteelDetected5:Bool
    let meaStainSteelDetected6:Bool
    let meaOperatingInTollerance:Bool
    let meaChanged:String
    let meaAuthorised:String
    let meaAuthorisedBy:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)

        let rawMeaCalibrationId = try? values.decode(Int32.self, forKey: .meaCalibrationId)
        let rawMeaDeviceId = try? values.decode(Int32.self, forKey: .meaDeviceId)
        let rawMeaReportNo = try? values.decode(String.self, forKey: .meaReportNo)
        let meaReportSubNumber = GetNiceInt32(values:values, forKey: .meaReportSubNumber)
        let meaCallNo = GetNiceInt32(values:values, forKey: .meaCallNo)
        let meaTradeApproved = GetNiceBool(values:values, forKey: .meaTradeApproved)
        let meaManditoryMarkings = GetNiceBool(values:values, forKey: .meaManditoryMarkings)
        let meaLevelIndicatingDev = GetNiceBool(values:values, forKey: .meaLevelIndicatingDev)
        let meaCleanAndServicable = GetNiceBool(values:values, forKey: .meaCleanAndServicable)
        let meaAdequateProtection = GetNiceBool(values:values, forKey: .meaAdequateProtection)
        let meaNoObstructions = GetNiceBool(values:values, forKey: .meaNoObstructions)
        let meaClearView = GetNiceBool(values:values, forKey: .meaClearView)
        let meaNoDamage = GetNiceBool(values:values, forKey: .meaNoDamage)
        let meaArmWorking = GetNiceBool(values:values, forKey: .meaArmWorking)
        let meaCalibrationMassesUsed = GetNiceString(values:values, forKey: .meaCalibrationMassesUsed)
        let meaRemarks1 = GetNiceString(values:values, forKey: .meaRemarks1)
        let meaRemarks2 = GetNiceString(values:values, forKey: .meaRemarks2)
        let meaRemarks3 = GetNiceString(values:values, forKey: .meaRemarks3)
        let meaRemarks4 = GetNiceString(values:values, forKey: .meaRemarks4)
        let meaRemarks5 = GetNiceString(values:values, forKey: .meaRemarks5)
        let meaTester = GetNiceString(values:values, forKey: .meaTester)
        let meaDate = GetNiceDate(dateFormat: "",values:values, forKey: .meaDate)
        let meaTemperature = GetNiceFloat(values:values, forKey: .meaTemperature)
        let meaRecalInterval = GetNiceInt32(values:values, forKey: .meaRecalInterval)
        let meaFerrous = GetNiceString(values:values, forKey: .meaFerrous)
        let meaFerrousDetected1 = GetNiceBool(values:values, forKey: .meaFerrousDetected1)
        let meaFerrousDetected2 = GetNiceBool(values:values, forKey: .meaFerrousDetected2)
        let meaFerrousDetected3 = GetNiceBool(values:values, forKey: .meaFerrousDetected3)
        let meaFerrousDetected4 = GetNiceBool(values:values, forKey: .meaFerrousDetected4)
        let meaFerrousDetected5 = GetNiceBool(values:values, forKey: .meaFerrousDetected5)
        let meaFerrousDetected6 = GetNiceBool(values:values, forKey: .meaFerrousDetected6)
        let meaNonFerrous = GetNiceString(values:values, forKey: .meaNonFerrous)
        let meaNonFerrrousDetected1 = GetNiceBool(values:values, forKey: .meaNonFerrrousDetected1)
        let meaNonFerrrousDetected2 = GetNiceBool(values:values, forKey: .meaNonFerrrousDetected2)
        let meaNonFerrrousDetected3 = GetNiceBool(values:values, forKey: .meaNonFerrrousDetected3)
        let meaNonFerrrousDetected4 = GetNiceBool(values:values, forKey: .meaNonFerrrousDetected4)
        let meaNonFerrrousDetected5 = GetNiceBool(values:values, forKey: .meaNonFerrrousDetected5)
        let meaNonFerrrousDetected6 = GetNiceBool(values:values, forKey: .meaNonFerrrousDetected6)
        let meaStainSteel = GetNiceString(values:values, forKey: .meaStainSteel)
        let meaStainSteelDetected1 = GetNiceBool(values:values, forKey: .meaStainSteelDetected1)
        let meaStainSteelDetected2 = GetNiceBool(values:values, forKey: .meaStainSteelDetected2)
        let meaStainSteelDetected3 = GetNiceBool(values:values, forKey: .meaStainSteelDetected3)
        let meaStainSteelDetected4 = GetNiceBool(values:values, forKey: .meaStainSteelDetected4)
        let meaStainSteelDetected5 = GetNiceBool(values:values, forKey: .meaStainSteelDetected5)
        let meaStainSteelDetected6 = GetNiceBool(values:values, forKey: .meaStainSteelDetected6)
        let meaOperatingInTollerance = GetNiceBool(values:values, forKey: .meaOperatingInTollerance)
        let meaChanged = GetNiceString(values:values, forKey: .meaChanged)
        let meaAuthorised = GetNiceString(values:values, forKey: .meaAuthorised)
        let meaAuthorisedBy = GetNiceString(values:values, forKey: .meaAuthorisedBy)

    guard
        let meaCalibrationId = rawMeaCalibrationId,
        let meaDeviceId = rawMeaDeviceId,
        let meaReportNo = rawMeaReportNo
     else {
         var strValues = "Error Importing Table: MeaMetalDetector"
        strValues += "\nmeaCalibrationId = \(rawMeaCalibrationId?.description ?? "nil") "
        strValues += "\nmeaDeviceId = \(rawMeaDeviceId?.description ?? "nil") "
        strValues += "\nmeaReportNo = \(rawMeaReportNo?.description ?? "nil") "

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.meaCalibrationId = meaCalibrationId
        self.meaDeviceId = meaDeviceId
        self.meaReportNo = meaReportNo
        self.meaReportSubNumber = meaReportSubNumber
        self.meaCallNo = meaCallNo
        self.meaTradeApproved = meaTradeApproved
        self.meaManditoryMarkings = meaManditoryMarkings
        self.meaLevelIndicatingDev = meaLevelIndicatingDev
        self.meaCleanAndServicable = meaCleanAndServicable
        self.meaAdequateProtection = meaAdequateProtection
        self.meaNoObstructions = meaNoObstructions
        self.meaClearView = meaClearView
        self.meaNoDamage = meaNoDamage
        self.meaArmWorking = meaArmWorking
        self.meaCalibrationMassesUsed = meaCalibrationMassesUsed
        self.meaRemarks1 = meaRemarks1
        self.meaRemarks2 = meaRemarks2
        self.meaRemarks3 = meaRemarks3
        self.meaRemarks4 = meaRemarks4
        self.meaRemarks5 = meaRemarks5
        self.meaTester = meaTester
        self.meaDate = meaDate
        self.meaTemperature = meaTemperature
        self.meaRecalInterval = meaRecalInterval
        self.meaFerrous = meaFerrous
        self.meaFerrousDetected1 = meaFerrousDetected1
        self.meaFerrousDetected2 = meaFerrousDetected2
        self.meaFerrousDetected3 = meaFerrousDetected3
        self.meaFerrousDetected4 = meaFerrousDetected4
        self.meaFerrousDetected5 = meaFerrousDetected5
        self.meaFerrousDetected6 = meaFerrousDetected6
        self.meaNonFerrous = meaNonFerrous
        self.meaNonFerrrousDetected1 = meaNonFerrrousDetected1
        self.meaNonFerrrousDetected2 = meaNonFerrrousDetected2
        self.meaNonFerrrousDetected3 = meaNonFerrrousDetected3
        self.meaNonFerrrousDetected4 = meaNonFerrrousDetected4
        self.meaNonFerrrousDetected5 = meaNonFerrrousDetected5
        self.meaNonFerrrousDetected6 = meaNonFerrrousDetected6
        self.meaStainSteel = meaStainSteel
        self.meaStainSteelDetected1 = meaStainSteelDetected1
        self.meaStainSteelDetected2 = meaStainSteelDetected2
        self.meaStainSteelDetected3 = meaStainSteelDetected3
        self.meaStainSteelDetected4 = meaStainSteelDetected4
        self.meaStainSteelDetected5 = meaStainSteelDetected5
        self.meaStainSteelDetected6 = meaStainSteelDetected6
        self.meaOperatingInTollerance = meaOperatingInTollerance
        self.meaChanged = meaChanged
        self.meaAuthorised = meaAuthorised
        self.meaAuthorisedBy = meaAuthorisedBy
    }

    var dictionaryValue: [String: Any] {
    [
        "meaCalibrationId" : meaCalibrationId,
        "meaDeviceId" : meaDeviceId,
        "meaReportNo" : meaReportNo,
        "meaReportSubNumber" : meaReportSubNumber,
        "meaCallNo" : meaCallNo,
        "meaTradeApproved" : meaTradeApproved,
        "meaManditoryMarkings" : meaManditoryMarkings,
        "meaLevelIndicatingDev" : meaLevelIndicatingDev,
        "meaCleanAndServicable" : meaCleanAndServicable,
        "meaAdequateProtection" : meaAdequateProtection,
        "meaNoObstructions" : meaNoObstructions,
        "meaClearView" : meaClearView,
        "meaNoDamage" : meaNoDamage,
        "meaArmWorking" : meaArmWorking,
        "meaCalibrationMassesUsed" : meaCalibrationMassesUsed,
        "meaRemarks1" : meaRemarks1,
        "meaRemarks2" : meaRemarks2,
        "meaRemarks3" : meaRemarks3,
        "meaRemarks4" : meaRemarks4,
        "meaRemarks5" : meaRemarks5,
        "meaTester" : meaTester,
        "meaDate" : meaDate,
        "meaTemperature" : meaTemperature,
        "meaRecalInterval" : meaRecalInterval,
        "meaFerrous" : meaFerrous,
        "meaFerrousDetected1" : meaFerrousDetected1,
        "meaFerrousDetected2" : meaFerrousDetected2,
        "meaFerrousDetected3" : meaFerrousDetected3,
        "meaFerrousDetected4" : meaFerrousDetected4,
        "meaFerrousDetected5" : meaFerrousDetected5,
        "meaFerrousDetected6" : meaFerrousDetected6,
        "meaNonFerrous" : meaNonFerrous,
        "meaNonFerrrousDetected1" : meaNonFerrrousDetected1,
        "meaNonFerrrousDetected2" : meaNonFerrrousDetected2,
        "meaNonFerrrousDetected3" : meaNonFerrrousDetected3,
        "meaNonFerrrousDetected4" : meaNonFerrrousDetected4,
        "meaNonFerrrousDetected5" : meaNonFerrrousDetected5,
        "meaNonFerrrousDetected6" : meaNonFerrrousDetected6,
        "meaStainSteel" : meaStainSteel,
        "meaStainSteelDetected1" : meaStainSteelDetected1,
        "meaStainSteelDetected2" : meaStainSteelDetected2,
        "meaStainSteelDetected3" : meaStainSteelDetected3,
        "meaStainSteelDetected4" : meaStainSteelDetected4,
        "meaStainSteelDetected5" : meaStainSteelDetected5,
        "meaStainSteelDetected6" : meaStainSteelDetected6,
        "meaOperatingInTollerance" : meaOperatingInTollerance,
        "meaChanged" : meaChanged,
        "meaAuthorised" : meaAuthorised,
        "meaAuthorisedBy" : meaAuthorisedBy,
        ]
    }
}
