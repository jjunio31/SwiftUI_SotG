//
//  CallsCodeable.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import Foundation


struct CallsCodeable :Codable ,HasDictionaryValue {
/// http://sotg.awe.com.au:18091/make_code
///
/// TableName:Calls
/// callNo:Int32:String
/// callServiceCentre:String:Key
/// callStatus:String
/// callExtraStatus:String
/// callDateTimeRequired:Date
/// accountcode:String
/// shortname:String
/// callActivityCode:String
/// callActionCode:String
/// callUrgency:String
/// nameOfCaller:String
/// phoneOfCaller:String
/// contractNo:String
/// serviceAccessNo:String
/// stockCode:String
/// mapAddress:String
/// callAddress:String
/// postcode:String
/// customerReference:String
///
    private enum CodingKeys: String, CodingKey {
        case callNo
        
        case callServiceCentre
        case callStatus
        case callExtraStatus
        case callDateTimeRequired
        case accountcode
        case shortname
        case callActivityCode
        case callActionCode
        case callUrgency
        case nameOfCaller
        case phoneOfCaller
        case contractNo
        case serviceAccessNo
        case stockCode
        case mapAddress
        case callAddress
        case postcode
        case customerReference
    }

    let callNo:String
   
    let callServiceCentre:String
    let callStatus:String
    let callExtraStatus:String
    let callDateTimeRequired:Date
    let accountcode:String
    let shortname:String
    let callActivityCode:String
    let callActionCode:String
    let callUrgency:String
    let nameOfCaller:String
    let phoneOfCaller:String
    let contractNo:String
    let serviceAccessNo:String
    let stockCode:String
    let mapAddress:String
    let callAddress:String
    let postcode:String
    let customerReference:String

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        
        let rawCallNo = try? values.decode(String.self, forKey: .callNo)
        let rawCallServiceCentre = try? values.decode(String.self, forKey: .callServiceCentre)
        let rawCallStatus = try? values.decode(String.self, forKey: .callStatus)
        let rawCallExtraStatus = try? values.decode(String.self, forKey: .callExtraStatus)
        let rawCallDateTimeRequired = try? values.decode(Date.self, forKey: .callDateTimeRequired)
        let rawAccountcode = try? values.decode(String.self, forKey: .accountcode)
        let rawShortname = try? values.decode(String.self, forKey: .shortname)
        let rawCallActivityCode = try? values.decode(String.self, forKey: .callActivityCode)
        let rawCallActionCode = try? values.decode(String.self, forKey: .callActionCode)
        let rawCallUrgency = try? values.decode(String.self, forKey: .callUrgency)
        let rawNameOfCaller = try? values.decode(String.self, forKey: .nameOfCaller)
        let rawPhoneOfCaller = try? values.decode(String.self, forKey: .phoneOfCaller)
        let rawContractNo = try? values.decode(String.self, forKey: .contractNo)
        let rawServiceAccessNo = try? values.decode(String.self, forKey: .serviceAccessNo)
        let rawStockCode = try? values.decode(String.self, forKey: .stockCode)
        let rawMapAddress = try? values.decode(String.self, forKey: .mapAddress)
        let rawCallAddress = try? values.decode(String.self, forKey: .callAddress)
        let rawPostcode = try? values.decode(String.self, forKey: .postcode)
        let rawCustomerReference = try? values.decode(String.self, forKey: .customerReference)

    guard
        let callNo = rawCallNo,
        
        let callServiceCentre = rawCallServiceCentre,
        let callStatus = rawCallStatus,
        let callExtraStatus = rawCallExtraStatus,
        let callDateTimeRequired = rawCallDateTimeRequired,
        let accountcode = rawAccountcode,
        let shortname = rawShortname,
        let callActivityCode = rawCallActivityCode,
        let callActionCode = rawCallActionCode,
        let callUrgency = rawCallUrgency,
        let nameOfCaller = rawNameOfCaller,
        let phoneOfCaller = rawPhoneOfCaller,
        let contractNo = rawContractNo,
        let serviceAccessNo = rawServiceAccessNo,
        let stockCode = rawStockCode,
        let mapAddress = rawMapAddress,
        let callAddress = rawCallAddress,
        let postcode = rawPostcode,
        let customerReference = rawCustomerReference
     else {
         var strValues = "Error Importing Table: Calls"
        strValues += "\ncallNo = \(rawCallNo?.description ?? "nil") "
        
        strValues += "\ncallServiceCentre = \(rawCallServiceCentre?.description ?? "nil") "
        if rawCallStatus == nil {strValues += "\ncallStatus is nil "}
        if rawCallExtraStatus == nil {strValues += "\ncallExtraStatus is nil "}
        if rawCallDateTimeRequired == nil {
            strValues += "\nError in callDateTimeRequired:"}
            let s = try? values.decode(String.self, forKey: .callDateTimeRequired)
            if let s = s {
                strValues += s
            }
        if rawAccountcode == nil {strValues += "\naccountcode is nil "}
        if rawShortname == nil {strValues += "\nshortname is nil "}
        if rawCallActivityCode == nil {strValues += "\ncallActivityCode is nil "}
        if rawCallActionCode == nil {strValues += "\ncallActionCode is nil "}
        if rawCallUrgency == nil {strValues += "\ncallUrgency is nil "}
        if rawNameOfCaller == nil {strValues += "\nnameOfCaller is nil "}
        if rawPhoneOfCaller == nil {strValues += "\nphoneOfCaller is nil "}
        if rawContractNo == nil {strValues += "\ncontractNo is nil "}
        if rawServiceAccessNo == nil {strValues += "\nserviceAccessNo is nil "}
        if rawStockCode == nil {strValues += "\nstockCode is nil "}
        if rawMapAddress == nil {strValues += "\nmapAddress is nil "}
        if rawCallAddress == nil {strValues += "\ncallAddress is nil "}
        if rawPostcode == nil {strValues += "\npostcode is nil "}
        if rawCustomerReference == nil {strValues += "\ncustomerReference is nil "}

        print("Ignored: \(strValues)")
        throw SotgCatchError.missingData(data: strValues)
    }

        self.callNo = callNo
        
        self.callServiceCentre = callServiceCentre
        self.callStatus = callStatus
        self.callExtraStatus = callExtraStatus
        self.callDateTimeRequired = callDateTimeRequired
        self.accountcode = accountcode
        self.shortname = shortname
        self.callActivityCode = callActivityCode
        self.callActionCode = callActionCode
        self.callUrgency = callUrgency
        self.nameOfCaller = nameOfCaller
        self.phoneOfCaller = phoneOfCaller
        self.contractNo = contractNo
        self.serviceAccessNo = serviceAccessNo
        self.stockCode = stockCode
        self.mapAddress = mapAddress
        self.callAddress = callAddress
        self.postcode = postcode
        self.customerReference = customerReference
    }

    var dictionaryValue: [String: Any] {
    [
        "callNo" : callNo,
        
        "callServiceCentre" : callServiceCentre,
        "callStatus" : callStatus,
        "callExtraStatus" : callExtraStatus,
        "callDateTimeRequired" : callDateTimeRequired,
        "accountcode" : accountcode,
        "shortname" : shortname,
        "callActivityCode" : callActivityCode,
        "callActionCode" : callActionCode,
        "callUrgency" : callUrgency,
        "nameOfCaller" : nameOfCaller,
        "phoneOfCaller" : phoneOfCaller,
        "contractNo" : contractNo,
        "serviceAccessNo" : serviceAccessNo,
        "stockCode" : stockCode,
        "mapAddress" : mapAddress,
        "callAddress" : callAddress,
        "postcode" : postcode,
        "customerReference" : customerReference,
        ]
    }
}
