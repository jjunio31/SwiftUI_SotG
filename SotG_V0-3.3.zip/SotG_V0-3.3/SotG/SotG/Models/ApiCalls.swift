//
//  ApiCalls.swift
//  SotG
//
//  Created by Barry Hunter on 6/1/2023.
//

import Foundation
import OSLog

struct ApiCalls {
    let server:String
    var sotgProvider: SotgProvider = .shared
    let logger = Logger(subsystem: "au.com.awe.SotG", category: "persistence")
    
    /* *****************************************************************************************************
     *
     * DeleteOne
     *
     * *****************************************************************************************************/
    
    
    
    func login(engineerCode:String, password:String, engineerSuCode:String = "")  async throws -> (String,String) {
        let session = URLSession.shared
        var parameters="Parameter1=\(engineerCode)"
        if password.isEmpty {
            parameters="\(parameters)&Parameter2=_"
        }
        else {
            parameters="\(parameters)&Parameter2=\(password)"
        }
        if !engineerSuCode.isEmpty {
            parameters="\(parameters)&Parameter3=\(engineerSuCode)"
        }
        let sUrl = "\(server)/api/get_api_data?Api=get-auth-key&\(parameters)"
        
        print("sUrl Ok \(sUrl)")
        do {
            if let url = URL(string: sUrl) {
                //print("Url Ok")
                guard let (data, response) = try? await session.data(from: url),
                      let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode)
                else {
                    print("Http Error")
                    logger.debug("Failed to received valid response and/or data.")
                    //throw SotgCatchError.missingData
                    throw SotgCatchError.urlError(msg: "Failed to received valid response and/or data.",url: sUrl)
                    
                }
                
                do {
                    let sData = String(data: data, encoding: .utf8)!
                    print(sData)
                    // Decode the GeoJSON into a data model.
                    let jsonDecoder = JSONDecoder()
                    jsonDecoder.dateDecodingStrategy = .secondsSince1970
                    let loginJSON = try jsonDecoder.decode(ApiData.self, from: data)
                    
                    if let authData = loginJSON.authData {
                        print("authData is OK \(authData.status)")
                        if authData.status == "failed" {
                            print("Error1")
                            throw SotgCatchError.loginFail(msg: authData.error ?? "**")
                            
                        }
                        else
                        {
                            if let authCode = authData.meaAuthCode , let engineerName = authData.mea_eng_name {
                                return (authCode,engineerName)
                                //authCode = authCode
                                //self.authCode = authCode
                                //print ("authCode is \(authCode)")
                            }
                            else {
                                throw SotgCatchError.loginFail(msg: "Login Failure: authCode is empty")
                                
                                
                            }
                        }
                    }
                    else { // missing auth data
                        throw SotgCatchError.loginFail(msg: "Api Failure: Missing AuthData")
                    }
                }
                
                
                catch {
                    let error = error as? SotgCatchError ?? .wrongDataFormat(error: error)
                    
                    throw error
                }
            }
            else{
                print("URL Error")
                throw SotgCatchError.urlError(msg:"Error",url: sUrl)
            }
        }
        catch {
            let error = error as? SotgCatchError ?? .urlError(msg:"Error",url: sUrl)
            
            throw error
            //throw SotgCatchError.urlError(url: sUrl)
            
            
        }
        //  return nil
        
    }
    
    
    /******************************************************************************************************
     *
     * postCallExtra
     *
     * ***************************************************************************************************** */
    func postRequest(api:String, authCode:String, parameters: String) throws {
        //postCallExtra(authCode:String , callNo:Int32, callStatusValue:String) throws {
        
        
        print("****************** postRequest \(api)")
        
        //let parameters=
        let sUrl = "\(server)/api/post_api_data/?Api=\(api)&authCode=\(authCode)"
        
        
        let json:[String:Any] = [
            
            "Parameters": parameters
        ]
        
           
        
        let session = URLSession(configuration: URLSessionConfiguration.default)//URLSession.shared
        let url = URL(string: sUrl)
        if let url = url {
            //print("****************** postRequest url \(sUrl)")
            // now create the URLRequest object using the url object
            var request = URLRequest(url: url)
            request.httpMethod = "PUT" //set http method as POST
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.httpBody = try? JSONSerialization.data(withJSONObject: json)
            
            
            
            // add headers for the request
            //request.addValue("application/json", forHTTPHeaderField: "Content-Type") // change as per server requirements
            //request.addValue("application/json", forHTTPHeaderField: "Accept")
            //print("****************** postRequest do")
           // do {
            //    // convert parameters to Data and assign dictionary to httpBody of request
           //     request.httpBody = try JSONSerialization.data(withJSONObject: json)
           // } catch let error {
           //     print(error.localizedDescription)
           //     throw error
                
            //}
            print("****************** postRequest task")
            let task = session.dataTask(with: request)  { data, response, error in
                if let error = error {
                    print("Post Request Error: \(error.localizedDescription)")
                    return
                }
                
                // ensure there is valid response code returned from this HTTP response
                guard let httpResponse = response as? HTTPURLResponse else {
                   print("Invalid Response received from the server ")
                   return
               }
                
                guard (200...299).contains(httpResponse.statusCode) else {
                    print("Invalid Response received from the server httpResponse: \(httpResponse)")
                    return
                }
            
                      
               
                
                // ensure there is data returned
                guard let data = data else {
                    print("nil Data received from the server")
                    return
                }
                let sData = String(data: data, encoding: .utf8)!
                print("OK \(sData)")
                //do {
                    // create json object from data or use JSONDecoder to convert to Model stuct
                    /*if let jsonResponse = try? JSONSerialization.jsonObject(with: responseData, options: .mutableContainers) as? [String: Any] {
                        print(jsonResponse)
                        // handle json response
                    } else {
                        print("data maybe corrupted or in wrong format")
                        throw URLError(.badServerResponse)
                    }
                     */
                //} catch let error {
                  //  print(error.localizedDescription)
                   // throw error
               // }
                 
            }
            // perform the task
            task.resume()
        }
        
        
        
        
    }
    
    /* *****************************************************************************************************
     *
     * getManuals
     *
     * *****************************************************************************************************/

    func getManuals(authCode:String)  async throws -> String {
        let session = URLSession.shared
        
        let sUrl = "\(server)/api/get_manuals?AuthCode=\(authCode)"
        
        print("sUrl Ok \(sUrl)")
        //var sData = ""
        do {
            if let url = URL(string: sUrl) {
                //print("Url Ok")
                guard let (data, response) = try? await session.data(from: url),
                      let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode)
                else {
                    print("Http Error")
                    logger.debug("Failed to received valid response and/or data.")
                    //throw SotgCatchError.missingData
                    throw SotgCatchError.urlError(msg: "Failed to received valid response and/or data.",url: sUrl)
                    
                }
                
                do {
                    print("getting Data")
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .formatted(dateFormatter)
                    let apiData2 = try decoder.decode(ApiData2.self, from: data)
                    //print("JSON OK: \(apiData2.fileData.Calls)")
                    //let data = JSONSerialization.jsonObject(with: apiData2.fileData.Calls)
                    //    as? [[String : Any]]
                    
                    //print("get Data \(data)")
                    if (apiData2.metadata.message=="InvalidAuthCode")
                    {
                        print("Get Failed")
                        let errorMessage = apiData2.metadata.error.joined(separator:"\r\n")
                        //let sData = String(data: data, encoding: .utf8)!
                        throw SotgCatchError.invalidAuthCode(data: errorMessage)
                    }
                    let apiManuals = try decoder.decode(ApiDataManuals.self, from: data)
                    print("get Data importCalls *******************")
                    //let fileData = apiData2.fileData
                    //if !fileData.isEmpty
                    //{
                    try await sotgProvider.importGeneric(entity: Manuals.entity(),
                                                         propertiesList: apiManuals.data.manuals)
                    
                    try await sotgProvider.importGeneric(entity: ManualFolders.entity(),
                                                         propertiesList: apiManuals.data.manualFolders)
                    
                   
                    
                  
                    
                    return "Done"
                }
                catch {
                    let sData = String(data: data, encoding: .utf8)!
                    print(sData)
                    if let sotgError = error as? SotgCatchError {
                        throw sotgError
                    }
                    else {
                        throw SotgCatchError.unexpectedError(error: error)
                    }
                }
                
            }
            else {
                throw SotgCatchError.urlError(msg:"Error",url: sUrl)
            }
        }
        //return nil
    }
    
    
    /* *****************************************************************************************************
     *
     * getData
     *
     * *****************************************************************************************************/

    func getData(authCode:String)  async throws -> String {
        let session = URLSession.shared
        let api = "get-all-for-eng" //test_data"
        let sUrl = "\(server)/api/get_api_data?Api=\(api)&Parameter1=\(authCode)"
        
        print("sUrl Ok \(sUrl)")
        //var sData = ""
        do {
            if let url = URL(string: sUrl) {
                //print("Url Ok")
                guard let (data, response) = try? await session.data(from: url),
                      let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode)
                else {
                    print("Http Error")
                    logger.debug("Failed to received valid response and/or data.")
                    //throw SotgCatchError.missingData
                    throw SotgCatchError.urlError(msg: "Failed to received valid response and/or data.",url: sUrl)
                    
                }
                
                do {
                    print("getting Data")
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .formatted(dateFormatter)
                    //decoder.dateDecodingStrategyFormatters = [ DateFormatter.standardT,
                     //                                          DateFormatter.standard,
                     //                                          DateFormatter.yearMonthDay ]
                    
                    let apiData2 = try decoder.decode(ApiData2.self, from: data)
                    //print("JSON OK: \(apiData2.fileData.Calls)")
                    //let data = JSONSerialization.jsonObject(with: apiData2.fileData.Calls)
                    //    as? [[String : Any]]
                    
                    //print("get Data \(data)")
                    if (apiData2.metadata.message=="InvalidAuthCode")
                    {
                        print("Get Failed")
                        let errorMessage = apiData2.metadata.error.joined(separator:"\r\n")
                        //let sData = String(data: data, encoding: .utf8)!
                        throw SotgCatchError.invalidAuthCode(data: errorMessage)
                    }
                    let apiData3 = try decoder.decode(ApiData3.self, from: data)
                    print("get Data importCalls *******************")
                    //let fileData = apiData2.fileData
                    //if !fileData.isEmpty
                    //{
                    
                    if let calls = apiData3.fileData.Calls {
                        try await sotgProvider.importGeneric(entity: Call.entity(),
                                                             propertiesList: calls)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON Calls is missing")
                    }
                    if let customers = apiData3.fileData.Customers {
                        try await sotgProvider.importGeneric(entity: Customer.entity(),
                                                             propertiesList: customers)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON Customers is missing")
                    }
                    if let callNotes = apiData3.fileData.CallNotes {
                        try await sotgProvider.importGeneric(entity: CallNote.entity(),
                                                             propertiesList: callNotes)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON CallNotes is missing")
                    }
                    if let engSched = apiData3.fileData.EngSched {
                        try await sotgProvider.importGeneric(entity: EngSched.entity(),
                                                             propertiesList: engSched)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON EngSched is missing")
                    }
                    if let meaDevices = apiData3.fileData.MeaDevices {
                        try await sotgProvider.importGeneric(entity: MeaDevice.entity(),
                                                             propertiesList: meaDevices)
                    } else {
                        throw SotgCatchError.missingData(data: "JSON MeaDevices is missing")
                    }
                    
                    if let meaTrade = apiData3.fileData.MeaTrade {
                        try await sotgProvider.importGeneric(entity: MeaTrade.entity(),
                                                             propertiesList: meaTrade)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaTrade is missing")
                    }
                    
                    if let meaForklift = apiData3.fileData.MeaForklift {
                        try await sotgProvider.importGeneric(entity: MeaForklift.entity(),
                                                             propertiesList: meaForklift)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaForklift is missing")
                    }
                    
                    if let meaHopper = apiData3.fileData.MeaHopper {
                        try await sotgProvider.importGeneric(entity: MeaHopper.entity(),
                                                             propertiesList: meaHopper)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaHopper is missing")
                    }
                    
                    
                    if let d = apiData3.fileData.MeaMisc {
                        try await sotgProvider.importGeneric(entity: MeaMisc.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaMisc is missing")
                    }
                    if let d = apiData3.fileData.MeaMetalDetector {
                        try await sotgProvider.importGeneric(entity: MeaMetal.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaMetalDetector is missing")
                    }
                    
                    if let d = apiData3.fileData.MeaPhTester {
                        try await sotgProvider.importGeneric(entity: MeaPhTester.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaPhTester is missing")
                    }
                    
                    if let d = apiData3.fileData.MeaTemperature {
                        try await sotgProvider.importGeneric(entity: MeaTemperature.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaTemperature is missing")
                    }
                    
                    if let d = apiData3.fileData.MeaTestMasses {
                        try await sotgProvider.importGeneric(entity: MeaTestMasses.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaTestMasses is missing")
                    }
                    
                    if let d = apiData3.fileData.MeaWeighbridge {
                        try await sotgProvider.importGeneric(entity: MeaWeighbridge.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaWeighbridge is missing")
                    }
                    
                    
                    if let d = apiData3.fileData.MeaBaseMakes {
                        try await sotgProvider.importGeneric(entity: MeaBaseMakes.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaBaseMakes is missing")
                    }
                    
                    if let d = apiData3.fileData.MeaResolutions {
                        try await sotgProvider.importGeneric(entity: MeaResolution.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaResolutions is missing")
                    }
                  
                    
                    
                    if let d = apiData3.fileData.MeaStdCalibrations {
                        try await sotgProvider.importGeneric(entity: MeaStdCalibrations.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaStdCalibrations is missing")
                    }
                    if let d = apiData3.fileData.MeaStdRemarks {
                        try await sotgProvider.importGeneric(entity: MeaStdRemarks.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaStdRemarks is missing")
                    }
                    if let d = apiData3.fileData.MeaUnits {
                        try await sotgProvider.importGeneric(entity: MeaUnits.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaUnits is missing")
                    }
                    if let d = apiData3.fileData.MeaWeighbridgeQns {
                        try await sotgProvider.importGeneric(entity: MeaWeighbridgeQns.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaWeighbridgeQns is missing")
                    }
                    
                    if let d = apiData3.fileData.Vehicles {
                        try await sotgProvider.importGeneric(entity: Vehicles.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON Vehicles is missing")
                    }
                    
                    if let d = apiData3.fileData.MeaBaseMakes {
                        try await sotgProvider.importGeneric(entity: MeaBaseMakes.entity(),
                                                             propertiesList: d)
                    }
                    else {
                        throw SotgCatchError.missingData(data: "JSON MeaBaseMake is missing")
                    }
                     
                   
                    
                  
                    
                    return "Done"
                }
                catch {
                    let sData = String(data: data, encoding: .utf8)!
                    print(sData)
                    if let sotgError = error as? SotgCatchError {
                        throw sotgError
                    }
                    else {
                        throw SotgCatchError.unexpectedError(error: error)
                    }
                }
                
            }
            else {
                throw SotgCatchError.urlError(msg:"Error",url: sUrl)
            }
        }
        //return nil
    }
}


