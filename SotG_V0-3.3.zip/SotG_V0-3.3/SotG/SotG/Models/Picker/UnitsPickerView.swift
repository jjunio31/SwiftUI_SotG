//
//  UnitsPickerView.swift
//  SotG
//
//  Created by Administrator on 22/1/2023.
//

import SwiftUI
import CoreData

struct UnitsPickerView: View {
    @Binding var units:String
    
    @FetchRequest(fetchRequest: MeaUnits.allFetchRequest())
    var unitsList: FetchedResults<MeaUnits>
    
    init(_ binding:Binding<String?>){
        
        print("UnitsPickerView init \(binding.wrappedValue ?? "nil")")
        _units = Binding(binding,"")
        
       
    }
    var body: some View {
        HStack {
            Text("Unit: ")
            let _ = print("unit: \(units)")
            //TextField("ok",text: $resolution)
            Picker("Unit", selection: $units) {
                ForEach(0 ..< unitsList.count, id: \.self) { index in
                    let value = self.unitsList[index].meaUnit ?? ""
                    //let _ = print("tag: \(index) \(value)")
                    Text(value).tag(value)
                }
            }
        }
       
    }
}
extension MeaUnits {
    // ❇️ The @FetchRequest property wrapper in the ContentView will call this function
    static func allFetchRequest() -> NSFetchRequest<MeaUnits> {
        let request: NSFetchRequest<MeaUnits> = MeaUnits.fetchRequest()
        //as! NSFetchRequest<MeaResolution>
        
        // ❇️ The @FetchRequest property wrapper in the ContentView requires a sort descriptor
        request.sortDescriptors = [NSSortDescriptor(key: "meaUnit", ascending: true)]
          
        return request
    }
}/*struct UnitsPickerView_Previews: PreviewProvider {
    @State var units = ""
    static var previews: some View {
        UnitsPickerView()
    }
}*/
