//
//  ResolutionPickerView.swift
//  SotG
//
//  Created by Administrator on 19/1/2023.
//

import SwiftUI
import CoreData

struct ResolutionPickerView: View {
    @Binding var resolution:String
    
    @FetchRequest(fetchRequest: MeaResolution.allFetchRequest())
    var resolutionList: FetchedResults<MeaResolution>
    
    init(_ binding:Binding<String?>){
        
        print("ResolutionPickerView init \(binding.wrappedValue ?? "nil")")
        _resolution = Binding(binding,"")
        
       
    }
    var body: some View {
        HStack {
            Text("Resolution: ")
            let _ = print("resolution: \(resolution)")
            //TextField("ok",text: $resolution)
            Picker("Resolution", selection: $resolution ) {
                ForEach(0 ..< resolutionList.count, id: \.self) { index in
                    let value = self.resolutionList[index].meaResolution ?? ""
                    //let _ = print("tag: \(index) \(value)")
                    Text(value).tag(value)
                }
            }
        }
       
    }
}
extension MeaResolution {
    // ❇️ The @FetchRequest property wrapper in the ContentView will call this function
    static func allFetchRequest() -> NSFetchRequest<MeaResolution> {
        let request: NSFetchRequest<MeaResolution> = MeaResolution.fetchRequest()
        //as! NSFetchRequest<MeaResolution>
        
        // ❇️ The @FetchRequest property wrapper in the ContentView requires a sort descriptor
        request.sortDescriptors = [NSSortDescriptor(key: "meaDisplayOrder", ascending: true)]
          
        return request
    }
}/*struct ResolutionPickerView_Previews: PreviewProvider {
    @State var resolution = "1"
    static var previews: some View {
        ResolutionPickerView()
    }
}*/
