//
//  StdRemarksPickerView.swift
//  SotG
//
//  Created by Administrator on 20/1/2023.
//

import SwiftUI
import CoreData

struct StdRemarksPickerView: View {
    @Binding var StdRemarks:String
    
    @FetchRequest(fetchRequest: MeaStdRemarks.allFetchRequest())
    var StdRemarksList: FetchedResults<MeaStdRemarks>
    
    init(_ binding:Binding<String?>){
        
        print("StdRemarksPickerView init \(binding.wrappedValue ?? "nil")")
        _StdRemarks = Binding(binding,"")
        
       
    }
    var body: some View {
        HStack {
            Text("Remarks: ")
            let _ = print("remarks: \(StdRemarks)")
            //TextField("ok",text: $resolution)
            Picker("Remarks", selection: $StdRemarks) {
                ForEach(0 ..< StdRemarksList.count, id: \.self) { index in
                    let value = self.StdRemarksList[index].meaRemark ?? ""
                    //let _ = print("tag: \(index) \(value)")
                    Text(value).tag(value)
                }
            }
        }
       
    }
}
extension MeaStdRemarks {
    // ❇️ The @FetchRequest property wrapper in the ContentView will call this function
    static func allFetchRequest() -> NSFetchRequest<MeaStdRemarks> {
        let request: NSFetchRequest<MeaStdRemarks> = MeaStdRemarks.fetchRequest()
        //as! NSFetchRequest<MeaResolution>
        
        // ❇️ The @FetchRequest property wrapper in the ContentView requires a sort descriptor
        request.sortDescriptors = [NSSortDescriptor(key: "MeaStdRemarks", ascending: true)]
          
        return request
    }
}/*struct ResolutionPickerView_Previews: PreviewProvider {
    @State var resolution = "1"
    static var previews: some View {
        ResolutionPickerView()
    }
}*/

