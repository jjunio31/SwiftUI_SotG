//
//  BaseMakesPickerView.swift
//  SotG
//
//  Created by Administrator on 19/1/2023.
//

import SwiftUI
import CoreData

struct BaseMakesPickerView: View {
    @Binding var baseMake:String
    
    @FetchRequest(fetchRequest: MeaBaseMakes.allFetchRequest())
    var baseMakesList: FetchedResults<MeaBaseMakes>
    
    init(_ binding:Binding<String?>){
        
        print("BaseMakesPickerView init \(binding.wrappedValue ?? "nil")")
        _baseMake = Binding(binding,"")
        
       
    }
    var body: some View {
        HStack {
            Text("baseMake: ")
            let _ = print("baseMake: \(baseMake)")
            //TextField("ok",text: $resolution)
            Picker("baseMake", selection: $baseMake ) {
                ForEach(0 ..< baseMakesList.count, id: \.self) { index in
                    let value = self.baseMakesList[index].meaBaseMake ?? ""
                    //let _ = print("tag: \(index) \(value)")
                    Text(value).tag(value)
                }
            }
        }
       
    }
}
extension MeaBaseMakes {
    // ❇️ The @FetchRequest property wrapper in the ContentView will call this function
    static func allFetchRequest() -> NSFetchRequest<MeaBaseMakes> {
        let request: NSFetchRequest<MeaBaseMakes> = MeaBaseMakes.fetchRequest()
        //as! NSFetchRequest<MeaResolution>
        
        // ❇️ The @FetchRequest property wrapper in the ContentView requires a sort descriptor
        request.sortDescriptors = [NSSortDescriptor(key: "meaBaseMake", ascending: true)]
          
        return request
    }
}/*struct BaseMakesPickerView_Previews: PreviewProvider {
    @State var resolution = "1"
    static var previews: some View {
        ResolutionPickerView()
    }
}*/


