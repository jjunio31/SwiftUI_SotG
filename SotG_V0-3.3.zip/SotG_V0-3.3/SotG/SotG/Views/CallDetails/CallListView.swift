//
//  CallListView.swift
//  SotG
//
//  Created by Barry Hunter on 1/1/2023.
//

import SwiftUI
import CoreData

struct CallListView: View {

    @State var filterKey:String = "callNo"
    @State var filterValue:String = ""
    
    var sotgProvider: SotgProvider = .shared
    
    var body: some View {
        VStack {
           
            HStack {
                Text("Filter \(filterKey)")
                TextField("Filter", text:$filterValue)
                
            }
            Spacer()
            
            CallListFilteredView(filterKey: filterKey, filterValue: filterValue)
            
            
            
        }
        //.alert(isPresented: $hasError, error: error) { }
        .navigationTitle("Call List")
    }
    
    

}
struct CallListFilteredView: View {
    @FetchRequest var callList: FetchedResults<Call>
    
    let layout = [
            GridItem(.adaptive(minimum: 30, maximum: 120))
        ]
        
    
    //var filterKey:String = "callNo"
    //@State var filterValue:String = "37"
    init( filterKey:String,filterValue:String)
    {
        
        //print("CallListFilteredView  filterKey \(filterKey), filterValue \(filterValue)")
        if(filterKey.isEmpty || filterValue.isEmpty)
        {
            _callList = FetchRequest<Call>(entity: Call.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \Call.callNo,
                                                                              ascending: true)])
            
        }
        else
        {
            _callList = FetchRequest<Call>(entity: Call.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \Call.callNo,
                                                                              ascending: true)],
                                           predicate: NSPredicate(format: "%K CONTAINS %@",
                                                                  filterKey,
                                                                  filterValue)
            )
        }
    }
    
    
    
    var body: some View {
        ScrollView(.horizontal){
            LazyHGrid(rows: layout){
                ForEach(callList, id:\.self) { call in
                    //if let call = call {
                        //let _ = print("CallListFilteredView \(call.callNo) call.callExtraStatus \(call.callExtraStatus ?? "**")")
                    //}
                    
                    
                    HStack {
                        
                        NavigationLink(value: MenuChoice(call: call,
                                                         menuItem: call.callExtraStatus == CallStatusEnum.Accepted.rawValue ?   .callMenu : .callAccept )){
                            
                            
                            
                            StdTexts(text: call.callNo)
                            StdTexts(text: call.accountcode)
                            StdTexts( text: call.shortname)
                            
                            StdTexts( text: call.callExtraStatus)
                            
                            
                        }.background(backgroundColor(for: call.callExtraStatus ))
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                //.frame(height: 50)
            }
            .environment(\.defaultMinListRowHeight, 10)
        }
    }
    //CallStatusEnum.Open.rawValue
    private func backgroundColor(for callExtra: String?) -> Color {
        switch (callExtra) {
        case CallStatusEnum.Open.rawValue: return .orange
        case CallStatusEnum.Accepted.rawValue: return .green
        case CallStatusEnum.Rejected.rawValue: return .red
        default : return .gray
            
        }
    }
}
