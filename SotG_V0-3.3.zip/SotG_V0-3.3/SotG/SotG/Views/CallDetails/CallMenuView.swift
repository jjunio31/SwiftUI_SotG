//
//  CallMenuView.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import SwiftUI
import CoreData

let callMenuMenuList : [MenuChoice.MenuItem] = [ .reports,.camera , .callDetails ]
                             
struct CallMenuView: View {
    @State var call:Call
    
    var body: some View {
        VStack {
            List {
                ForEach(callMenuMenuList, id:\.self) { mItem in
                    let menuChoice = MenuChoice(call:call,menuItem: mItem)
                    NavigationLink(value: menuChoice){
                        //
                        HStack {
                            ShowMenuImage(menuChoice: menuChoice)
                           
                        }
                    }
                }
            }
            
            
            
        }
        .navigationTitle("Call Menu ")
        //\(call.callNo ?? "")")
    }
}

/*struct CallMenuView_Previews: PreviewProvider {
    static var previews: some View {
        CallMenuView()
    }
}*/
