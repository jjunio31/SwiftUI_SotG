//
//  CallTimesView.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import SwiftUI
import CoreData

struct CallTimesView: View {
    @State var call:Call
    
    var body: some View {
        Text("Call Times")
    }
}

/*struct CallTimesView_Previews: PreviewProvider {
    static var previews: some View {
        CallTimesView()
    }
}*/
