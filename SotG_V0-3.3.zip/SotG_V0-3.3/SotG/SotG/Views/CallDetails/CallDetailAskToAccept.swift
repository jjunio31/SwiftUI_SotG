//
//  CallDetailAskToAccept.swift
//  SotG
//
//  Created by Barry Hunter on 5/1/2023.
//

import SwiftUI
import CoreData

struct CallDetailAskToAccept: View {
  
    @State var call:Call
    let server :String
    let authCode:String
    @Binding var error:SotgCatchError?
    @Binding var hasError :Bool
    @Binding var path: [MenuChoice]
   // @Binding var refresh:UUID
   // @State var refresh = UUID()

    @Environment(\.managedObjectContext) var managedObjectContext
    

    var body: some View {
        VStack{
            Text("Call Accept / Reject")
            StdTextLabel(  "Call No", text: call.callNo)
            StdTextLabel(  "Customer", text: call.shortname)
            StdTextLabel(  "Address", text: call.callAddress)
            StdTextLabel(  "Accepted?", text: call.callExtraStatus)
            Spacer()
            StdButton(onPress: onPress, text: "Accept")
            
            Spacer()
        }
        
        
    }
    func onPress() {
        //print("****************** onPress ")
        let callNo = call.callNo
        let callExtraStatus = CallStatusEnum.Accepted.rawValue
        call.callExtraStatus = callExtraStatus
        do {
            try managedObjectContext.save()
            
            let parameters  = "\(callNo)|\(callExtraStatus)"
            //print("****************** onPress parameters \(parameters)")
            try ApiCalls(server: server).postRequest(api: "post-call-extra", authCode: authCode, parameters: parameters)
            
            var newPath = path
            newPath.removeLast()
            
            newPath.append(MenuChoice(call: call,menuItem: .callMenu))
            path = newPath
            
        } catch {
            self.hasError = true
            let error = error as? SotgCatchError ?? .unexpectedError(error: error)
            self.error = error
           
            
            
            print(error.localizedDescription)
        }
        //refresh = UUID()
    }
}

/*struct CallDetailAskToAccept_Previews: PreviewProvider {
    static var previews: some View {
        CallDetailAskToAccept()
    }
}*/
