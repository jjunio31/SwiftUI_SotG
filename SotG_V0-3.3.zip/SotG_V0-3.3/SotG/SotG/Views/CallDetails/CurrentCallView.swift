//
//  CurrentCallView.swift
//  SotG
//
//  Created by Barry Hunter on 4/1/2023.
//

import SwiftUI

struct CurrentCallView: View {
    //var body: some View {
    //    Text("Current Call - look in EngSched")
    //}
    
    //@State var filterKey:String = "dateString"
    //@//State var filterValue:String = ""
    
    var sotgProvider: SotgProvider = .shared
    @State private var date = Date()
    @State private var showAll = false
    
    
    var body: some View {
        VStack {
            Toggle(isOn: $showAll) {
                        Text("Show All")
                    }
            //.toggleStyle(CheckboxToggleStyle())
            
            if !showAll {
                DatePicker("Pick a date",
                           selection: $date,
                           displayedComponents: [.date])
                .padding()
            }
        
            Spacer()
            
            CurrentCallFilteredView(date: date,showAll: showAll)
            
            
            
        }
        //.alert(isPresented: $hasError, error: error) { }
        .navigationTitle("Current Call")
    }
}
struct CurrentCallFilteredView: View {
    @FetchRequest var currentList: FetchedResults<EngSched>
    @Environment(\.managedObjectContext) var managedObjectContext
    
    let showAll:Bool
    //var filterKey:String = "callNoString"
    //@State var filterValue:String = "37"
    init(date:Date, showAll:Bool)
    {
        self.showAll = showAll
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        let strDate = dateFormatter.string(from: date).uppercased()
        
        
        //print("CurrentCallFilteredView  strDate \(strDate)")
        if showAll
        {
            _currentList = FetchRequest<EngSched>(entity: EngSched.entity(),
                                                  sortDescriptors: [NSSortDescriptor(keyPath: \EngSched.dateToAttend,
                                                                                     ascending: false)]
            )
            
        }
        else {
            _currentList = FetchRequest<EngSched>(entity: EngSched.entity(),
                                                  sortDescriptors: [NSSortDescriptor(keyPath: \EngSched.dateToAttend,
                                                                                     ascending: true)],
                                                  predicate: NSPredicate(format: "dateString = %@",
                                                                         
                                                                         strDate)
            )
            
        }
    }
    
    
    
    
    
    let layout = [
        GridItem(.adaptive(minimum: 30, maximum: 120))
    ]
    var sotgProvider: SotgProvider = .shared
    
    var body: some View {
        
        ScrollView(.horizontal){
            LazyHGrid(rows: layout){
                
                ForEach(currentList, id:\.self) { engSched in
                    
                    
                    if let engSched = engSched {
                        let call = sotgProvider.GetCall(callNo: "\(engSched.callNo)",
                                                        context: managedObjectContext)
                        if let call = call {
                            
                            
                            
                            NavigationLink(value: MenuChoice(call: call,
                                                             menuItem: call.callExtraStatus == CallStatusEnum.Accepted.rawValue ?   .callMenu : .callAccept )){
                                //NavigationLink(value: MenuChoice(sched: EngSched,
                                //                                 menuItem: EngSched.engCode == CallStatusEnum.Accepted.rawValue ?   .callMenu : .callAccept )){
                                
                                
                                
                                
                                if showAll {
                                    StdDate(engSched.dateToAttend)
                                }
                                else {
                                    StdTexts(text: engSched.timeString)
                                }
                                //TextDateOnly(engSched.dateToAttend)
                                StdTexts( text: call.shortname )
                                //StdTexts( text: engSched.engCode)
                                StdTexts(i: engSched.callNo)
                            }
                            
                            
                        }
                    }
                    
                    
                }
                
                
                //.frame(height: 50)
            }
        }
        .environment(\.defaultMinListRowHeight, 20)
    }
    
}
    
    


