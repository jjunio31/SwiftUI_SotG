//
//  ReportDetailView.swift
//  SotG
//
//  Created by Barry Hunter on 17/1/2023.
//

import SwiftUI
import CoreData

struct ReportDetailView: View {
    @State var call:Call
    @ObservedObject var device:MeaDevice
   
    @State var title:String = "Report Detail"
    @State var accountcode = ""
    @State var reportNumber = ""
    //@State var refresh = ""
    //let callNo:String
    //let  meaDeviceId:Int32
    //let managedObjectContext:NSManagedObjectContext
    /*init(callNo:String, meaDeviceId:Int32 , managedObjectContext:NSManagedObjectContext) {
       
        let sotgProvider: SotgProvider = .shared
        self.call = sotgProvider.GetCall(callNo: callNo, context: managedObjectContext)!
        self.device = sotgProvider.GetDevice(meaDeviceId: meaDeviceId, context: managedObjectContext)!
        self.callNo = callNo
        self.meaDeviceId = meaDeviceId
        self.managedObjectContext = managedObjectContext
       
        
    }*/
    
    var body: some View {
        
        VStack {
            body2
        }
        .navigationTitle(title)
      
        Spacer()
        
       
    }

    var body2: some View {
        VStack {
            let menuChoice = MenuChoice(call: call, device: device, menuItem: .reportEdit)
            NavigationLink(value: menuChoice){
                //
                HStack {
                    Text("Edit")
                        .frame(width:200, height: 50)
                        .background(Color.gray)
                        .font(.system(size:20, weight: .bold))
                        .cornerRadius(10)
                    
                }
            }.isDetailLink(false)
           
            StdTextLabel(  "on", text: device.meaOn )
            StdTextLabel(  "Base Make", text: device.meaBaseMake)
            StdTextLabel(  "Type", text: device.meaType)
            StdTextLabel(  "Capacity", text: device.meaBaseCapacity)
            StdTextLabel(  "Address", text: device.meaAddress)
            StdTextLabel(  "Resolution", text: device.meaInstrumentResolution1)
           // let _ = print ("body2 \(device.meaInstrumentResolution1)")
            Spacer()
            
        }
    }
}


