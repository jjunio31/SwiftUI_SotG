//
//  SyncView.swift
//  SotG
//
//  Created by Barry Hunter on 4/1/2023.
//

import SwiftUI
import CoreData

struct SyncView: View {
    @Environment(\.managedObjectContext) var managedObjectContext
   
    let server:String
    let authCode:String
    
    @State var syncMessage = ""
    @Binding var error:SotgCatchError?
    @Binding var hasError :Bool
    //@State var details=""
    @State var listOfrecordCount = [RecordCount] ()
    /*@State var callCount=0
    @State var engSchedCount=0
    @State var callNotesCount=0
    @State var callTimesCount=0
    @State var customerCount=0
    @State var manualsCount:Int=0
    @State var manualFolderCount:Int=0
    @State var devicesCount:Int=0
    @State var tradeCount:Int=0
    @State var forkliftCount:Int=0
    @State var hopperCount:Int=0
    */
    
    //@FetchRequest var callList: FetchedResults<Call> =
    
    var sotgProvider: SotgProvider = .shared
    
    //@FetchRequest var callList: FetchedResults<Call> = FetchRequest<Call>(entity: Call.entity(),sortDescriptors: [])
    
    //let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Call")
    //let callList2
    
    
    
    
    var body: some View {
        VStack {
            
            
            Text(syncMessage)
            
            Spacer()
            StdButton(onPress: onGetData, text: "Get Data")
            StdButton(onPress: onGetDataForManuals, text: "Get Manuals")
            Spacer()
            List(listOfrecordCount) { recordCount in
                ShowRecordCount(recordCount: recordCount)
            }
            Spacer()
        }
        .navigationTitle("Sync Data")
        
        .onAppear(){
            getAllRecordsCounts()
            
        }
    }
    
    func getAllRecordsCounts(){
        listOfrecordCount.removeAll()
        getRecordsCount(tableName: "Call")
        getRecordsCount(tableName: "CallNote")
         getRecordsCount(tableName: "CallTimes")
         getRecordsCount(tableName: "EngSched")
         getRecordsCount(tableName: "Customer")
         /*
          var Customers: [CustomerCodeable]?
          var MeaDevices: [MeaDeviceCodeable]?
          var MeaTrade: [MeaTradeCodeable]?
          var MeaForklift: [MeaForkliftCodeable]?
          var MeaHopper: [MeaHopperCodeable]?
          var MeaMetalDetector: [MeaMetalDetectorCodeable]?
          var MeaMisc: [MeaMiscCodeable]?
          var MeaPhTester: [MeaPhTesterCodeable]?
          var MeaTemperature: [MeaTemperatureCodeable]?
          var MeaTestMasses: [MeaTestMassesCodeable]?
          var MeaWeighbridge: [WeighbridgeCodeable]?
          var MeaResolutions: [MeaResolutionsCodeable]?
          var MeaStdCalibrations: [MeaStdCalibrationsCodeable]?
          var MeaStdRemarks: [MeaStdRemarksCodeable]?
          var MeaUnits: [MeaUnitsCodeable]?
          var MeaWeighbridgeQns: [WeighbridgeQnCodeable]?
          var Vehicles: [VehiclesCodeable]?
          var MeaBaseMakes: [MeaBaseMakeCodeable]?
          */
        getRecordsCount(tableName: "Vehicles")
         getRecordsCount(tableName: "MeaDevice")
         getRecordsCount(tableName: "MeaTrade")
         getRecordsCount(tableName: "MeaForklift")
         getRecordsCount(tableName: "MeaHopper")
        getRecordsCount(tableName: "MeaMetal" )
        getRecordsCount(tableName: "MeaMisc")
        getRecordsCount(tableName: "MeaPhTester")
        getRecordsCount(tableName: "MeaTemperature")
        getRecordsCount(tableName: "MeaTestMasses")
        getRecordsCount(tableName: "MeaWeighbridge")
        getRecordsCount(tableName: "MeaStdCalibrations")
        getRecordsCount(tableName: "MeaStdRemarks")
        getRecordsCount(tableName: "MeaUnits")
        getRecordsCount(tableName: "MeaWeighbridgeQns")
        
        getRecordsCount(tableName: "MeaBaseMakes")
        
        getRecordsCount(tableName: "Manuals")
        getRecordsCount(tableName: "ManualFolders")
        
    }
    func getRecordsCount(tableName:String)  {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: tableName)
        do {
            let count = try managedObjectContext.count(for: fetchRequest)
            let recordCount=RecordCount(tableName: tableName, noOfRecords: count)
            listOfrecordCount.append(recordCount)
            
        } catch {
            self.hasError = true
            let error = error as? SotgCatchError ?? .unexpectedError(error: error)
            self.error = error
            
            print(error.localizedDescription)
        }
        
    }
    
    func onGetData(){
        print("CallListView::onGetData")
        Task {
            await sotgGetData() 
                
            
        }
    }
    
    private func sotgGetData() async  {
        
              
        //var ret = false
        do {
            syncMessage = "please Wait"
            try await sotgProvider.DeleteAll()
            syncMessage = try await ApiCalls(server:server).getData(authCode: authCode)
            
            
            //print("retval \(code)")
            
            //lastUpdated = Date().timeIntervalSince1970
        } catch {
            self.hasError = true
            if let error = error as? SotgCatchError {
                self.error = error
                print("Error \(error.localizedDescription)")
            }
            else {
                self.error = .unexpectedError(error: error)
                if let error = self.error {
                    print("Unexpected Error \(error.localizedDescription)")
                }
            }
            
            
            
        }
        getAllRecordsCounts()
       
       // print ("Path Count: \(path.count)")
       // isLoading = false
        //return ret
    }
    func onGetDataForManuals(){
        print("CallListView::onGetDataForManuals")
        Task {
            await sotgGetDataForManuals()
                
            
        }
    }
    private func sotgGetDataForManuals() async  {
        
              
        //var ret = false
        do {
            syncMessage = "please Wait"
            try await sotgProvider.DeleteAllManuals()
            syncMessage = try await ApiCalls(server:server).getManuals(authCode: authCode)
            
            
            //print("retval \(code)")
            
            //lastUpdated = Date().timeIntervalSince1970
        } catch {
            self.hasError = true
            if let error = error as? SotgCatchError {
                self.error = error
                print("Error \(error.localizedDescription)")
            }
            else {
                self.error = .unexpectedError(error: error)
                if let error = self.error {
                    print("Unexpected Error \(error.localizedDescription)")
                }
            }
            
            
            
        }
        getAllRecordsCounts()
       
       // print ("Path Count: \(path.count)")
       // isLoading = false
        //return ret
    }
   
    

    
}
struct RecordCount:Identifiable {
    let tableName:String
    let noOfRecords:Int
    var id: String {
        tableName
    }
}
struct ShowRecordCount: View {
    let recordCount:RecordCount
    var body: some View {
        HStack{
            Text("\(recordCount.tableName)")
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("\(recordCount.noOfRecords)")
                .frame(maxWidth: .infinity, alignment: .trailing)
            
        }
        
    }
}




