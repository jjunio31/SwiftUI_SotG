//
//  ManualsView.swift
//  SotG
//
//  Created by Barry Hunter on 12/1/2023.
//

import SwiftUI

struct ManualsListView: View {
    let manualFolder:ManualFolders
    
    @State var progeess:String = ""
    @State var filterValue:String = ""
    
    var sotgProvider: SotgProvider = .shared
    
    var body: some View {
        VStack {
           
            HStack {
                //Text("Filter \(filterKey)")
                TextField("Filter", text:$filterValue)
                
            }
            Spacer()
            
            ManualsFilteredView(folder: "\(manualFolder.name ?? "")", filterValue: filterValue)
            
            
            
        }
        
        .navigationTitle("Manuals in Folder \(manualFolder.name ?? "")")
    }
    
}
struct ManualsFilteredView: View {
    @FetchRequest var manuals: FetchedResults<Manuals>
    
    let layout = [
        GridItem(.adaptive(minimum: 30, maximum: 120))
    ]
    
    init( folder:String, filterValue:String)
    {
        let filterKey:String = "name"
        //print("CallListFilteredView  filterKey \(filterKey), filterValue \(filterValue)")
        let predicateFolder = NSPredicate(format: "folder == %@",folder )
        
        if(filterKey.isEmpty || filterValue.isEmpty)
        {
            _manuals = FetchRequest<Manuals>(entity: Manuals.entity(),
                                                    sortDescriptors: [NSSortDescriptor(keyPath: \Manuals.name,
                                                                              ascending: true)],
                                             predicate: predicateFolder)
            
        }
        else
        {
            let filter = NSPredicate(format: "name CONTAINS %@",
                                     
                                     filterValue)
            let andPredicate = NSCompoundPredicate(type: .and, subpredicates: [predicateFolder, filter])
            
            _manuals = FetchRequest<Manuals>(entity: Manuals.entity(),
                                           sortDescriptors: [NSSortDescriptor(keyPath: \Manuals.name,
                                                                              ascending: true)],
                                           predicate: andPredicate
            )
        }
    }
    
    
    
    var body: some View {
        ScrollView(.horizontal){
            LazyHGrid(rows: layout){
                ForEach(manuals, id:\.self) { manual in
                    // if let manualFolder = manualFolder {
                    //let _ = print("CallListFilteredView \(manualFolder.name) call.callExtraStatus \(call.callExtraStatus ?? "**")")
                    //}
                    
                    
                    HStack {
                        
                        NavigationLink(value: MenuChoice(manual: manual, menuItem: .manualDetail))
                        {
                            
                            
                            
                            StdTexts(text: manual.name)
                            //StdTextLabel(  "count", i: manualFolder.count)
                            
                        }
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                }
                //.frame(height: 50)
            }
        }
        //.environment(\.defaultMinListRowHeight, 20)
    }
   
}
/*struct ManualsView_Previews: PreviewProvider {
 static var previews: some View {
 // ManualsView()
 }
 }
 */
