//
//  CurrentCallView.swift
//  SotG
//
//  Created by Barry Hunter on 4/1/2023.
//

import SwiftUI

struct CurrentCallView: View {
    var body: some View {
        Text("Current Call - look in EngSched")
    }
}


