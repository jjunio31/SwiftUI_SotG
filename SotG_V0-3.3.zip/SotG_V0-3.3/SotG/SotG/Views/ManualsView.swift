//
//  ManualsView.swift
//  SotG
//
//  Created by Barry Hunter on 12/1/2023.
//

import SwiftUI

struct ManualsView: View {
    @State var image : UIImage? = nil
    @State var progress:String = ""
    var body: some View {
        Text("Manuals")
        Text("\(progress)")
        let _ = print("Draw View \(progress)")
        if let uiimage = image {
            let _ = print("Set Image in View")
            Image(uiImage: uiimage)
                .resizable()
                .frame(width: 32.0, height: 32.0)
                .foregroundColor(.accentColor)
        }
        ButtonStd(onPress: onPress, text: "Download")
    }
    func onPress() {
        progress = "OnPress"
        if let url = URL(string: "<a href=") {
            progress = "URL Ok"
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                progress = "Task"
                if let error = error {
                    progress = error.localizedDescription
                    print ("\(error.localizedDescription)")
                    return
                }
                guard let data = data else { return }
                
                DispatchQueue.main.async { /// execute on main thread
                    //image = UIImage(named: "AWE_Logo.png")
                    
                    image = UIImage(data: data)
                    progress = "Set Image"
                }
            }
            
            task.resume()
        }
    }
}

/*struct ManualsView_Previews: PreviewProvider {
 static var previews: some View {
 // ManualsView()
 }
 }
 */
